
import React, { useState, useMemo } from 'react';
import { Audit, AuditStatus, Department, CostCenter, NegotiationStatus, NotifyFn, ActionType, User, Attachment, ComplianceRule, HistoryLog } from '../types';
import { Plus, Search, ArrowDown, Trash2, Calendar, User as UserIcon, Handshake, DollarSign, Upload, FileText, X, Download, TrendingUp, Info } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ItemHistoryModal } from './ItemHistoryModal';

interface NegotiationWorkflowProps {
  user: User;
  audits: Audit[];
  setAudits: (data: Audit[] | ((prev: Audit[]) => Audit[])) => void;
  departments?: Department[];
  costCenters?: CostCenter[];
  complianceRules: ComplianceRule[];
  notify: NotifyFn;
  showConfirmModal: (message: string, onConfirm: () => void) => void;
  logAction: (action: ActionType, target: string, details: string, itemId?: string) => void; 
  historyLogs: HistoryLog[];
}

const MONTHS = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

export const NegotiationWorkflow: React.FC<NegotiationWorkflowProps> = ({ user, audits, setAudits, departments = [], costCenters = [], complianceRules, notify, showConfirmModal, logAction, historyLogs }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAudit, setSelectedAudit] = useState<Partial<Audit> | null>(null);
  
  // History Modal State
  const [historyItemId, setHistoryItemId] = useState<string | null>(null);

  // List Filters
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());

  const availableYears = useMemo(() => {
    const years = new Set<number>();
    // Add years from existing data
    audits.forEach(audit => years.add(new Date(audit.date).getFullYear()));
    
    // Add a wide range (Current Year - 5 to Current Year + 10)
    const currentYear = new Date().getFullYear();
    for (let i = currentYear - 5; i <= currentYear + 10; i++) {
        years.add(i);
    }
    return Array.from(years).sort((a, b) => b - a);
  }, [audits]);

  const filteredAudits = useMemo(() => {
    return audits.filter(audit => {
      const auditYear = new Date(audit.date).getFullYear();
      if (auditYear !== selectedYear) return false;

      const matchesSearch = 
        audit.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        audit.department.toLowerCase().includes(searchTerm.toLowerCase());
      
      // Filter for active negotiations or completed ones, usually all audits can be negotiated
      return matchesSearch;
    });
  }, [audits, searchTerm, selectedYear]);

  const handleOpenModal = (audit?: Audit) => {
    if (audit) {
      setSelectedAudit({ ...audit });
    } else {
      // Allow creating a negotiation from scratch (Ad-hoc)
      const now = new Date();
      // If creating ad-hoc, prefer the currently selected year view for the date
      const defaultDate = `${selectedYear}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
      
      setSelectedAudit({
        title: '',
        department: departments[0]?.name || '',
        costCenter: costCenters[0]?.code || '',
        date: defaultDate, 
        status: AuditStatus.COMPLETED, // Ad-hoc negotiations usually imply execution
        plannedBudget: 0,
        executedBudget: 0,
        initialQuote: 0,
        finalPrice: 0,
        negotiationStatus: 'PENDING',
        negotiationNotes: '',
        savingAmount: 0,
        isRecurring: false,
        complianceRating: 0,
        attachments: []
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!selectedAudit?.title) {
      notify('Preencha o título.', 'error');
      return;
    }

    const auditToSave: Audit = {
      ...selectedAudit as Audit,
      id: selectedAudit.id || Date.now().toString(),
      companyId: user.companyId, // Ensure companyId is set
      // Ensure saving amount is calculated
      savingAmount: (selectedAudit.initialQuote || 0) - (selectedAudit.finalPrice || 0),
      // If executedBudget is not manually set, assume it equals finalPrice for negotiations
      executedBudget: selectedAudit.executedBudget || selectedAudit.finalPrice || 0,
      lastModifiedBy: user.name,
      lastModifiedAt: new Date().toISOString()
    };

    if (selectedAudit.id) {
      setAudits(prev => prev.map(a => a.id === auditToSave.id ? auditToSave : a));
      logAction('UPDATE', `Negociação: ${auditToSave.title}`, `Atualizou negociação. Saving: R$ ${auditToSave.savingAmount}.`, auditToSave.id);
      notify('Negociação atualizada!', 'success');
    } else {
      setAudits(prev => [...prev, auditToSave]);
      logAction('CREATE', `Negociação: ${auditToSave.title}`, 'Nova negociação registrada.', auditToSave.id);
      notify('Negociação criada!', 'success');
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    const itemTitle = audits.find(a => a.id === id)?.title || 'Item';
    showConfirmModal('Tem certeza que deseja remover este registro de negociação?', () => {
      setAudits(prev => prev.filter(a => a.id !== id));
      logAction('DELETE', `Negociação: ${itemTitle}`, 'Removeu registro.', id);
      notify('Registro removido.', 'info');
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        const newAttachment: Attachment = {
          name: file.name,
          url: base64String,
          type: file.type,
          size: file.size
        };
        setSelectedAudit(prev => ({
          ...prev,
          attachments: [...(prev?.attachments || []), newAttachment]
        }));
        notify('Arquivo anexado!', 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  const removeAttachment = (index: number) => {
    setSelectedAudit(prev => ({
      ...prev,
      attachments: prev?.attachments?.filter((_, i) => i !== index)
    }));
  };

  const generatePDF = () => {
    const doc = new jsPDF();
    doc.text(`Relatório de Negociações e Savings - ${selectedYear}`, 14, 15);
    
    const tableColumn = ["Data", "Título", "Proposta", "Final", "Saving", "Status"];
    const tableRows = filteredAudits.map(audit => [
      new Date(audit.date).toLocaleDateString('pt-BR'),
      audit.title,
      `R$ ${audit.initialQuote.toLocaleString()}`,
      `R$ ${audit.finalPrice.toLocaleString()}`,
      `R$ ${audit.savingAmount.toLocaleString()}`,
      audit.negotiationStatus === 'APPROVED' ? 'Aprovada' : audit.negotiationStatus === 'REJECTED' ? 'Recusada' : 'Pendente',
    ]);

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 20,
    });

    doc.save(`negociacoes_${selectedYear}.pdf`);
    notify('Relatório PDF gerado!', 'success');
  };

  return (
    <div className="space-y-6 animate-fade-in pb-10">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Gestão de Negociações</h2>
          <p className="text-slate-500">Acompanhe propostas, registre valores finais e calcule o saving (economia).</p>
        </div>
        <div className="flex gap-2">
           <div className="bg-white border border-slate-300 rounded-lg flex items-center px-3 gap-2">
              <Calendar size={16} className="text-slate-400"/>
              <select 
                value={selectedYear} 
                onChange={(e) => setSelectedYear(Number(e.target.value))}
                className="bg-transparent outline-none text-sm text-slate-700 font-medium py-2"
              >
                 {availableYears.map(y => <option key={y} value={y}>{y}</option>)}
              </select>
           </div>
           <button 
            onClick={generatePDF}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-lg transition-colors flex items-center gap-2 font-medium"
           >
             <Download size={20} /> Baixar Relatório
           </button>
           <button 
            onClick={() => handleOpenModal()} 
            className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg shadow-lg shadow-emerald-200 transition-all flex items-center gap-2 font-medium"
           >
            <Plus size={20} /> Nova Negociação
           </button>
        </div>
      </header>

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex items-center gap-3">
        <Search className="text-slate-400" size={20} />
        <input 
          type="text" 
          placeholder="Buscar negociação..." 
          className="flex-1 outline-none text-slate-700 bg-white"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Cards List */}
      <div className="grid grid-cols-1 gap-4">
        {filteredAudits.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-dashed border-slate-300">
            <Handshake className="mx-auto text-slate-300 mb-3" size={48} />
            <p className="text-slate-500">Nenhuma negociação registrada em {selectedYear}.</p>
          </div>
        ) : (
          filteredAudits.map((audit) => (
            <div key={audit.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 hover:shadow-md transition-shadow relative group">
                <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => setHistoryItemId(audit.id)} className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-700 rounded-lg transition-colors" title="Ver Histórico">
                        <Info size={18} />
                    </button>
                    <button onClick={() => handleOpenModal(audit)} className="p-2 bg-slate-100 hover:bg-emerald-50 text-slate-500 hover:text-emerald-600 rounded-lg transition-colors">
                        <ArrowDown size={18} className="rotate-[-45deg]" />
                    </button>
                    <button onClick={() => handleDelete(audit.id)} className="p-2 bg-slate-100 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors">
                        <Trash2 size={18} />
                    </button>
                </div>

                <div className="flex flex-col md:flex-row gap-6">
                    <div className={`w-2 rounded-full self-stretch shrink-0 
                        ${audit.negotiationStatus === 'APPROVED' ? 'bg-emerald-500' : 
                          audit.negotiationStatus === 'REJECTED' ? 'bg-red-500' : 'bg-amber-400'}`} 
                    />

                    <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                             <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border 
                                ${audit.negotiationStatus === 'APPROVED' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 
                                  audit.negotiationStatus === 'REJECTED' ? 'bg-red-50 text-red-700 border-red-100' : 'bg-amber-50 text-amber-700 border-amber-100'}`}>
                                {audit.negotiationStatus === 'APPROVED' ? 'Aprovada' : audit.negotiationStatus === 'REJECTED' ? 'Recusada' : 'Em Negociação'}
                             </span>
                             <span className="text-xs text-slate-400 flex items-center gap-1">
                                 <Calendar size={12}/> {new Date(audit.date).toLocaleDateString('pt-BR')}
                             </span>
                        </div>
                        
                        <h3 className="text-lg font-bold text-slate-800 mb-1">{audit.title}</h3>
                        <p className="text-sm text-slate-500 mb-4">{audit.department} • {audit.costCenter}</p>

                        {/* Negotiation Financials */}
                        <div className="grid grid-cols-3 gap-4 bg-slate-50 p-3 rounded-lg border border-slate-100">
                             <div>
                                 <span className="text-[10px] uppercase font-bold text-slate-400 block">Proposta Inicial</span>
                                 <span className="text-sm font-bold text-slate-600 strike-through decoration-slate-400">R$ {audit.initialQuote.toLocaleString()}</span>
                             </div>
                             <div>
                                 <span className="text-[10px] uppercase font-bold text-slate-400 block">Valor Final</span>
                                 <span className="text-sm font-bold text-slate-800">R$ {audit.finalPrice.toLocaleString()}</span>
                             </div>
                             <div>
                                 <span className="text-[10px] uppercase font-bold text-slate-400 block">Saving (Economia)</span>
                                 <span className={`text-sm font-bold ${audit.savingAmount > 0 ? 'text-emerald-600' : 'text-slate-400'}`}>
                                     R$ {audit.savingAmount.toLocaleString()}
                                 </span>
                             </div>
                        </div>
                        
                        {audit.attachments && audit.attachments.length > 0 && (
                          <div className="mt-3 flex gap-2">
                             {audit.attachments.map((file, i) => (
                               <span key={i} className="text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded flex items-center gap-1 border border-blue-100">
                                  <FileText size={12}/> {file.name}
                               </span>
                             ))}
                          </div>
                        )}
                    </div>
                </div>
            </div>
          ))
        )}
      </div>

      {/* Item History Modal */}
      <ItemHistoryModal 
        isOpen={!!historyItemId}
        onClose={() => setHistoryItemId(null)}
        itemTitle={audits.find(a => a.id === historyItemId)?.title || 'Item'}
        logs={historyLogs.filter(log => log.itemId === historyItemId)}
      />

      {/* Modal */}
      {isModalOpen && selectedAudit && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto custom-scrollbar animate-scale-in">
                <div className="p-6 border-b border-slate-100 bg-emerald-600 flex justify-between items-center sticky top-0 z-10">
                    <h3 className="text-xl font-bold text-white flex items-center gap-2">
                        <Handshake className="text-emerald-200"/>
                        {selectedAudit.id ? 'Editar Negociação' : 'Nova Negociação'}
                    </h3>
                    <button onClick={() => setIsModalOpen(false)} className="text-emerald-200 hover:text-white"><X size={24} /></button>
                </div>

                <div className="p-6 space-y-6">
                    {/* Basic Info (Simplified for Negotiation) */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="col-span-2">
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Item / Título</label>
                            <input 
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-emerald-500/50 bg-white text-slate-800"
                                value={selectedAudit.title || ''}
                                onChange={e => setSelectedAudit({...selectedAudit, title: e.target.value})}
                                placeholder="O que está sendo negociado?"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Departamento</label>
                            <select 
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800"
                                value={selectedAudit.department}
                                onChange={e => setSelectedAudit({...selectedAudit, department: e.target.value})}
                            >
                                {departments.map(d => <option key={d.id} value={d.name}>{d.name}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Centro de Custo</label>
                            <select 
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800"
                                value={selectedAudit.costCenter}
                                onChange={e => setSelectedAudit({...selectedAudit, costCenter: e.target.value})}
                            >
                                {costCenters.map(cc => <option key={cc.id} value={cc.code}>{cc.code} - {cc.name}</option>)}
                            </select>
                        </div>
                    </div>

                    {/* Negotiation Core */}
                    <div className="bg-emerald-50 p-6 rounded-xl border border-emerald-100">
                        <h4 className="font-bold text-emerald-900 mb-4 flex items-center gap-2">
                             <TrendingUp size={20} /> Valores da Negociação
                        </h4>
                        <div className="grid grid-cols-2 gap-6">
                             <div>
                                <label className="block text-xs font-bold text-emerald-700 uppercase mb-1">Proposta Inicial (Fornecedor)</label>
                                <div className="relative">
                                    <DollarSign className="absolute left-3 top-2.5 text-emerald-400" size={16}/>
                                    <input 
                                        type="number"
                                        className="w-full pl-9 border border-emerald-200 rounded-lg px-3 py-2 outline-none bg-white text-slate-800 font-semibold"
                                        value={selectedAudit.initialQuote}
                                        onChange={e => setSelectedAudit({...selectedAudit, initialQuote: Number(e.target.value)})}
                                    />
                                </div>
                             </div>
                             <div>
                                <label className="block text-xs font-bold text-emerald-700 uppercase mb-1">Valor Fechado (Final)</label>
                                <div className="relative">
                                    <DollarSign className="absolute left-3 top-2.5 text-emerald-400" size={16}/>
                                    <input 
                                        type="number"
                                        className="w-full pl-9 border border-emerald-200 rounded-lg px-3 py-2 outline-none bg-white text-slate-800 font-bold text-lg"
                                        value={selectedAudit.finalPrice}
                                        onChange={e => setSelectedAudit({...selectedAudit, finalPrice: Number(e.target.value)})}
                                    />
                                </div>
                             </div>
                        </div>
                        
                        <div className="mt-4 pt-4 border-t border-emerald-200/50 flex justify-between items-center">
                            <span className="text-sm font-medium text-emerald-800">Saving Estimado (Economia):</span>
                            <span className="text-xl font-bold text-emerald-600">
                                R$ {((selectedAudit.initialQuote || 0) - (selectedAudit.finalPrice || 0)).toLocaleString()}
                            </span>
                        </div>
                    </div>

                    {/* Status & Notes */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                           <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Status da Negociação</label>
                           <select 
                               className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800"
                               value={selectedAudit.negotiationStatus}
                               onChange={e => setSelectedAudit({...selectedAudit, negotiationStatus: e.target.value as NegotiationStatus})}
                           >
                               <option value="PENDING">Em Aberto / Pendente</option>
                               <option value="APPROVED">Aprovada (Fechado)</option>
                               <option value="REJECTED">Recusada</option>
                           </select>
                        </div>
                        <div>
                           <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Status Executivo</label>
                            <select 
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800"
                                value={selectedAudit.status}
                                onChange={e => setSelectedAudit({...selectedAudit, status: e.target.value as AuditStatus})}
                            >
                                <option value={AuditStatus.COMPLETED}>Executado</option>
                                <option value={AuditStatus.PARTIALLY_EXECUTED}>Parcialmente Executado</option>
                                <option value={AuditStatus.IN_PROGRESS}>Em Andamento</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Notas e Observações</label>
                        <textarea 
                            className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none h-24 resize-none bg-white text-slate-800"
                            value={selectedAudit.negotiationNotes}
                            onChange={e => setSelectedAudit({...selectedAudit, negotiationNotes: e.target.value})}
                            placeholder="Detalhes sobre a negociação, fornecedor vencedor, condições de pagamento..."
                        ></textarea>
                    </div>

                    {/* Attachments */}
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Anexos / Propostas</label>
                        <div className="flex gap-2 mb-2">
                             <label className="cursor-pointer bg-slate-100 hover:bg-slate-200 text-slate-600 px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors">
                                <Upload size={16} /> Anexar Arquivo
                                <input type="file" className="hidden" onChange={handleFileUpload} />
                             </label>
                        </div>
                        {selectedAudit.attachments && selectedAudit.attachments.length > 0 && (
                            <ul className="space-y-1">
                                {selectedAudit.attachments.map((file, i) => (
                                    <li key={i} className="flex justify-between items-center bg-slate-50 p-2 rounded border border-slate-200 text-sm">
                                        <div className="flex items-center gap-2 truncate">
                                            <FileText size={14} className="text-slate-400"/>
                                            <span className="text-slate-700 truncate max-w-[200px]">{file.name}</span>
                                        </div>
                                        <button onClick={() => removeAttachment(i)} className="text-red-400 hover:text-red-600">
                                            <X size={14} />
                                        </button>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>

                </div>

                <div className="p-6 border-t border-slate-100 flex justify-end gap-3 sticky bottom-0 bg-white">
                    <button onClick={() => setIsModalOpen(false)} className="px-5 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors">
                        Cancelar
                    </button>
                    <button onClick={handleSave} className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow font-medium transition-colors">
                        Salvar Negociação
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
