import React, { useState } from "react";
import { User, UserRole, NotifyFn, Company } from '../types';
import { ShieldCheck, UserPlus, LogIn, Key, User as UserIcon, Trash2, Zap, Loader2, HelpCircle, AlertTriangle, X, CheckCircle2, Lock } from 'lucide-react';
import { hashPassword, verifyPassword } from '../services/authService';

interface LoginProps {
  users: User[];
  companies: Company[];
  onLogin: (user: User) => void;
  onRegister: (newUser: User) => void;
  onDeleteUser: (userId: string) => void;
  onUpdateUserPassword: (userId: string, newPasswordHash: string) => void; // New prop for password update
  notify: NotifyFn;
  showConfirmModal: (message: string, onConfirm: () => void) => void;
}

export const Login: React.FC<LoginProps> = ({ users, companies, onLogin, onRegister, onDeleteUser, onUpdateUserPassword, notify, showConfirmModal }) => {
  const [activeTab, setActiveTab] = useState<'LOGIN' | 'REGISTER'>('LOGIN');
  
  // Register State
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('EXECUTOR');
  const [newPassword, setNewPassword] = useState('');
  const [selectedCompanyId, setSelectedCompanyId] = useState<string>(companies[0]?.id || ''); // Default to first company
  const [isLoadingRegister, setIsLoadingRegister] = useState(false);

  // Login State
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [passwordInput, setPasswordInput] = useState('');
  const [error, setError] = useState('');
  const [isLoadingLogin, setIsLoadingLogin] = useState(false);

  // Forgot Password Modal
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);

  // Forced Password Change Modal State
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const [changePasswordNew, setChangePasswordNew] = useState('');
  const [changePasswordConfirm, setChangePasswordConfirm] = useState('');
  const [pendingLoginUser, setPendingLoginUser] = useState<User | null>(null);

  // For delete authorization
  const [adminAuthPasswordForDelete, setAdminAuthPasswordForDelete] = useState(''); 
  const [isLoadingDelete, setIsLoadingDelete] = useState(false);

  // --- Utility: Password Validation ---
  const validatePassword = (password: string): string | null => {
    if (password.length < 8) return "A senha deve ter no mínimo 8 caracteres.";
    if (!/[A-Z]/.test(password)) return "A senha deve conter pelo menos uma letra maiúscula.";
    if (!/[a-z]/.test(password)) return "A senha deve conter pelo menos uma letra minúscula.";
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) return "A senha deve conter pelo menos um caractere especial (!@#$...).";
    return null;
  };

  // --- Handlers ---

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoadingRegister(true);
    setError('');
    
    if (!newName || !newPassword) {
      setError("Preencha nome e senha.");
      setIsLoadingRegister(false);
      return;
    }

    // Password Validation
    const passwordError = validatePassword(newPassword);
    if (passwordError) {
        setError(passwordError);
        setIsLoadingRegister(false);
        return;
    }

    if (!selectedCompanyId) {
        setError("Nenhuma empresa disponível para cadastro.");
        setIsLoadingRegister(false);
        return;
    }
    
    const initials = newName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
    const hashedPassword = await hashPassword(newPassword);
    
    const newUser: User = {
      id: `u${Date.now()}`,
      companyId: selectedCompanyId,
      name: newName,
      role: newRole,
      avatar: initials,
      password: hashedPassword,
      status: 'PENDING', // New users start as pending
      mustChangePassword: false
    };

    try {
        await onRegister(newUser);
        notify('Cadastro realizado! Aguarde aprovação do administrador para acessar.', 'success');
        setActiveTab('LOGIN');
        setNewName(''); setNewPassword('');
    } catch (err) {
        console.error("Registration failed:", err);
        setError("Erro ao criar usuário. Tente novamente.");
        notify("Erro ao criar usuário.", 'error');
    } finally {
        setIsLoadingRegister(false);
    }
  };

  const handleLoginAttempt = async () => {
     setIsLoadingLogin(true);
     setError('');

     if (!selectedUser) {
        setError("Selecione um usuário.");
        setIsLoadingLogin(false);
        return;
     }

     // Status Check
     if (selectedUser.status === 'PENDING') {
         setError("Conta em análise. Aguarde aprovação do administrador.");
         setIsLoadingLogin(false);
         return;
     }

     if (selectedUser.status === 'BLOCKED') {
         setError("Acesso bloqueado. Contate o administrador.");
         setIsLoadingLogin(false);
         return;
     }

     const isValid = await verifyPassword(passwordInput, selectedUser.password || '');
     
     if (isValid) {
         try {
             // Simulate a small delay for better UX and brute-force mitigation
             await new Promise(resolve => setTimeout(resolve, 600)); 
             
             // Check if forced password change is required
             if (selectedUser.mustChangePassword) {
                 setPendingLoginUser(selectedUser);
                 setIsChangePasswordOpen(true);
                 setIsLoadingLogin(false);
                 return;
             }

             await onLogin(selectedUser);
         } catch (err) {
             console.error("Login failed:", err);
             setError("Erro ao fazer login. Tente novamente.");
         }
     } else {
         setError("Senha incorreta.");
     }
     setIsLoadingLogin(false);
  };

  const handleChangePasswordSubmit = async () => {
      if (!changePasswordNew || !changePasswordConfirm) {
          setError("Preencha todos os campos.");
          return;
      }
      if (changePasswordNew !== changePasswordConfirm) {
          setError("As senhas não coincidem.");
          return;
      }
      
      // Password Validation
      const passwordError = validatePassword(changePasswordNew);
      if (passwordError) {
          setError(passwordError);
          return;
      }

      setIsLoadingLogin(true); // Re-use loading state
      try {
          const newHash = await hashPassword(changePasswordNew);
          if (pendingLoginUser) {
              await onUpdateUserPassword(pendingLoginUser.id, newHash);
              
              // Proceed with login using updated user object structure (password is handled by app state update)
              // We need to pass the updated user to onLogin, but since onUpdateUserPassword updates parent state,
              // we can rely on passing a modified object to onLogin for immediate session start.
              const updatedUser = { ...pendingLoginUser, password: newHash, mustChangePassword: false };
              await onLogin(updatedUser);
              
              notify("Senha atualizada com sucesso!", "success");
              setIsChangePasswordOpen(false);
              setPendingLoginUser(null);
          }
      } catch (error) {
          console.error("Error changing password:", error);
          setError("Erro ao atualizar senha.");
      } finally {
          setIsLoadingLogin(false);
      }
  };

  const handleQuickLogin = () => {
    const demoUser = users.find(u => u.role === 'DEMO');
    if (demoUser) {
        if (demoUser.status === 'BLOCKED' || demoUser.status === 'PENDING') {
            notify("Usuário Demo está bloqueado.", 'error');
            return;
        }
        onLogin(demoUser);
        notify("Acesso rápido como Usuário Demo (limitado)!", 'info');
    } else {
        notify("Nenhum usuário demo encontrado.", 'error');
        setError("Nenhum usuário demo encontrado para acesso rápido."); 
    }
  };

  const handleRequestDelete = (e: React.MouseEvent, userIdToDelete: string) => {
    e.stopPropagation();
    showConfirmModal("Para remover um usuário, você deve confirmar a senha de um ADMINISTRADOR. Continuar?", () => {
        setAdminAuthPasswordForDelete('');
        setSelectedUser(users.find(u => u.id === userIdToDelete) || null); 
        setError('');
    });
  };

  const handleDeleteAuthSubmit = async () => {
    setIsLoadingDelete(true);
    setError('');
    
    if (!selectedUser) {
        setIsLoadingDelete(false);
        setError("Nenhum usuário selecionado.");
        return;
    }

    // Find an admin and verify password
    let adminAuthenticated = false;
    
    // We need to check against all admins to find one that matches the password
    const admins = users.filter(u => u.role === 'ADMIN');
    for (const admin of admins) {
       if (await verifyPassword(adminAuthPasswordForDelete, admin.password || '')) {
         adminAuthenticated = true;
         break;
       }
    }

    if (!adminAuthenticated) {
      setError("Senha de Administrador inválida.");
      setIsLoadingDelete(false);
      return;
    }

    const adminCount = users.filter(u => u.role === 'ADMIN').length;
    if (selectedUser.role === 'ADMIN' && adminCount <= 1) {
        setError("Não é possível remover o último administrador.");
        setIsLoadingDelete(false);
        return;
    }

    try {
        await onDeleteUser(selectedUser.id);
        notify('Usuário removido com sucesso.', 'info');
        setSelectedUser(null); 
        setAdminAuthPasswordForDelete(''); 
        setError('');
    } catch (err) {
        setError("Erro ao remover usuário.");
        notify("Erro ao remover usuário.", 'error');
    } finally {
        setIsLoadingDelete(false);
    }
  };


  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-slate-900 relative overflow-hidden font-sans">
      {/* Dynamic Background */}
      <div className="absolute top-[-20%] left-[-10%] w-[800px] h-[800px] bg-emerald-500/10 rounded-full blur-[120px] animate-pulse"></div>
      <div className="absolute bottom-[-20%] right-[-10%] w-[800px] h-[800px] bg-indigo-600/10 rounded-full blur-[120px] animate-pulse delay-700"></div>

      <div className="bg-white/95 backdrop-blur-2xl rounded-[32px] shadow-2xl overflow-hidden max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 relative z-10 border border-white/10 ring-1 ring-white/50">
        
        {/* Left Side - Brand & Value Prop */}
        <div className="bg-slate-900 p-16 flex flex-col justify-between text-white relative overflow-hidden">
          {/* Subtle Grid Pattern */}
          <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-5 mix-blend-overlay pointer-events-none"></div>
          
          {/* Background Decorative Icon */}
          <div className="absolute top-10 right-10 opacity-5 transform rotate-12 scale-150 pointer-events-none">
            <ShieldCheck size={400} />
          </div>
          
          <div className="relative z-10">
            {/* BRAND LOGO CONSTRUCTED WITH CODE */}
            <div className="flex flex-col items-start gap-6 mb-10">
                <div className="relative w-20 h-20 flex items-center justify-center bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl shadow-2xl shadow-emerald-500/20">
                    <ShieldCheck className="text-white w-10 h-10" strokeWidth={2} />
                    <div className="absolute -bottom-2 -right-2 bg-slate-800 p-1.5 rounded-lg border border-slate-700">
                        <Lock size={14} className="text-emerald-400" />
                    </div>
                </div>
                
                <div>
                    <h1 className="text-5xl font-bold tracking-tight text-white mb-2 leading-none">
                        Audit<span className="text-emerald-400">Control</span>
                    </h1>
                    <p className="text-slate-400 text-sm font-medium tracking-wide uppercase">Plataforma de Governança Corporativa</p>
                </div>
            </div>

            <div className="space-y-6 max-w-md">
                <p className="text-slate-300 text-lg leading-relaxed font-light">
                  A solução definitiva para auditorias inteligentes, controle orçamentário preciso e negociações estratégicas.
                </p>
                
                <div className="space-y-3 pt-4">
                    <div className="flex items-center gap-3 text-sm text-slate-400">
                        <div className="p-1 rounded-full bg-emerald-500/10 text-emerald-500"><CheckCircle2 size={16}/></div>
                        <span>Criptografia de ponta a ponta (AES-GCM)</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm text-slate-400">
                        <div className="p-1 rounded-full bg-emerald-500/10 text-emerald-500"><CheckCircle2 size={16}/></div>
                        <span>Análise preditiva com Inteligência Artificial</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm text-slate-400">
                        <div className="p-1 rounded-full bg-emerald-500/10 text-emerald-500"><CheckCircle2 size={16}/></div>
                        <span>Gestão de múltiplos orçamentos matriciais</span>
                    </div>
                </div>
            </div>
          </div>

          <div className="relative z-10 mt-12 pt-8 border-t border-slate-800">
             <button 
                onClick={handleQuickLogin}
                className="group w-full bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 text-slate-300 hover:text-white py-4 px-6 rounded-2xl flex items-center justify-between transition-all"
            >
                <div className="flex items-center gap-4">
                    <div className="bg-yellow-500/10 p-2 rounded-xl text-yellow-400 group-hover:scale-110 transition-transform">
                        <Zap size={20} className="fill-current" />
                    </div>
                    <div className="text-left">
                        <span className="block font-bold text-white">Acesso Demonstração</span>
                        <span className="text-xs text-slate-500">Explore sem compromisso</span>
                    </div>
                </div>
                <span className="text-slate-500 group-hover:translate-x-1 transition-transform">→</span>
            </button>
          </div>
        </div>
        
        {/* Right Side - Auth Forms */}
        <div className="p-16 bg-white flex flex-col justify-center h-full relative">
          
          <div className="mb-10 text-center">
             {/* Tabs */}
             <div className="flex justify-center gap-8 border-b border-slate-100 pb-1">
                <button 
                    onClick={() => { setActiveTab('LOGIN'); setError(''); setPasswordInput(''); setSelectedUser(null); setAdminAuthPasswordForDelete(''); }}
                    className={`pb-4 text-sm font-bold transition-all relative ${activeTab === 'LOGIN' ? 'text-slate-800' : 'text-slate-400 hover:text-slate-600'}`}
                >
                    Fazer Login
                    {activeTab === 'LOGIN' && <span className="absolute bottom-[-1px] left-0 w-full h-0.5 bg-slate-800"></span>}
                </button>
                <button 
                    onClick={() => { setActiveTab('REGISTER'); setError(''); setNewName(''); setNewRole('EXECUTOR'); setNewPassword(''); setSelectedUser(null); setAdminAuthPasswordForDelete(''); }}
                    className={`pb-4 text-sm font-bold transition-all relative ${activeTab === 'REGISTER' ? 'text-slate-800' : 'text-slate-400 hover:text-slate-600'}`}
                >
                    Criar Nova Conta
                    {activeTab === 'REGISTER' && <span className="absolute bottom-[-1px] left-0 w-full h-0.5 bg-slate-800"></span>}
                </button>
             </div>
          </div>

          {activeTab === 'LOGIN' ? (
            <div className="animate-fade-in">
              {!selectedUser || (selectedUser && adminAuthPasswordForDelete) ? ( 
                <>
                  {!adminAuthPasswordForDelete && 
                  <>
                    <h2 className="text-3xl font-bold text-slate-800 mb-2">Bem-vindo de volta</h2>
                    <p className="text-slate-500 mb-8">Selecione seu perfil para continuar.</p>
                    
                    <div className="space-y-3 max-h-[400px] overflow-y-auto custom-scrollbar pr-2">
                        {users.length === 0 ? (
                            <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-200 text-slate-400 text-sm">
                                Nenhum usuário encontrado. Crie uma conta.
                            </div>
                        ) : (
                            users.map(user => {
                                // Find company name for this user
                                const compName = companies.find(c => c.id === user.companyId)?.name;
                                const isPending = user.status === 'PENDING';
                                const isBlocked = user.status === 'BLOCKED';

                                return (
                                <div
                                    key={user.id}
                                    onClick={() => {
                                        if (isPending) {
                                            setError("Usuário pendente de aprovação.");
                                            return;
                                        }
                                        if (isBlocked) {
                                            setError("Usuário bloqueado.");
                                            return;
                                        }
                                        setSelectedUser(user); 
                                        setError('');
                                    }}
                                    className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all group cursor-pointer
                                        ${isPending ? 'bg-amber-50 border-amber-200 opacity-80' : 
                                          isBlocked ? 'bg-red-50 border-red-200 opacity-70' :
                                          'border-slate-100 hover:border-emerald-500 hover:bg-emerald-50/50 hover:shadow-lg hover:-translate-y-0.5'}
                                    `}
                                >
                                    <div className="flex items-center gap-4">
                                        <div className="w-14 h-14 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold text-base group-hover:bg-white group-hover:text-emerald-600 transition-colors shadow-sm ring-2 ring-white">
                                            {user.avatar}
                                        </div>
                                        <div>
                                            <div className="font-bold text-slate-800 text-lg flex items-center gap-2">
                                                {user.name}
                                                {isPending && <span className="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full uppercase tracking-wider">Pendente</span>}
                                                {isBlocked && <span className="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded-full uppercase tracking-wider">Bloqueado</span>}
                                            </div>
                                            <div className="text-xs text-slate-500 font-medium flex gap-2 mt-0.5">
                                                <span className="bg-slate-100 px-2 py-0.5 rounded uppercase tracking-wide group-hover:bg-white/80">{user.role}</span>
                                                {compName && <span className="text-slate-400 flex items-center gap-1"> {compName}</span>}
                                            </div>
                                        </div>
                                    </div>
                                    <button 
                                        onClick={(e) => handleRequestDelete(e, user.id)}
                                        className="opacity-0 group-hover:opacity-100 p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                                        title="Remover usuário"
                                    >
                                        <Trash2 size={18} />
                                    </button>
                                </div>
                            )})
                        )}
                    </div>
                    {error && <p className="mt-4 text-red-600 text-sm font-medium bg-red-50 p-3 rounded-lg flex items-center gap-2 animate-slide-in"><AlertTriangle size={16}/> {error}</p>}
                  </>}

                  {adminAuthPasswordForDelete && selectedUser && ( 
                      <div className="animate-fade-in">
                          <button onClick={() => { setAdminAuthPasswordForDelete(''); setError(''); }} className="text-sm text-slate-500 hover:text-slate-800 mb-6 flex items-center gap-2 font-medium transition-colors">
                              ← Voltar para lista
                          </button>
                          
                          <div className="bg-red-50 p-6 rounded-2xl border border-red-100 text-center mb-6">
                            <div className="w-16 h-16 mx-auto bg-red-100 rounded-full flex items-center justify-center text-red-600 mb-3">
                                <Trash2 size={28} />
                            </div>
                            <h3 className="font-bold text-red-900 text-lg">Remover {selectedUser.name}?</h3>
                            <p className="text-red-700 text-sm mt-1">Esta ação não pode ser desfeita. Autorização de Admin necessária.</p>
                          </div>

                          <div className="space-y-4">
                              <div>
                                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Senha de Administrador</label>
                                  <div className="relative">
                                      <Key className="absolute left-4 top-3.5 text-slate-400" size={18} />
                                      <input 
                                          type="password" 
                                          autoFocus
                                          className="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-red-500/20 focus:border-red-500 outline-none transition-all text-slate-800"
                                          placeholder="Senha do Admin..."
                                          value={adminAuthPasswordForDelete}
                                          onChange={e => { setAdminAuthPasswordForDelete(e.target.value); setError(''); }}
                                          onKeyDown={e => e.key === 'Enter' && handleDeleteAuthSubmit()}
                                          disabled={isLoadingDelete}
                                      />
                                  </div>
                              </div>
                              {error && <p className="text-red-600 text-sm font-medium bg-red-50 p-3 rounded-lg flex items-center gap-2 animate-slide-in"><AlertTriangle size={16}/> {error}</p>}
                              
                              <button 
                                  onClick={handleDeleteAuthSubmit}
                                  className="w-full bg-red-600 hover:bg-red-700 text-white py-3.5 rounded-xl font-bold shadow-lg shadow-red-200/50 transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                                  disabled={isLoadingDelete}
                              >
                                  {isLoadingDelete ? <Loader2 size={20} className="animate-spin" /> : <Trash2 size={20} />}
                                  {isLoadingDelete ? 'Processando...' : 'Confirmar Remoção'}
                              </button>
                          </div>
                      </div>
                  )}
                </>
              ) : ( 
                <div className="animate-fade-in">
                     <button onClick={() => { setSelectedUser(null); setPasswordInput(''); setError(''); }} className="text-sm text-slate-500 hover:text-slate-800 mb-6 flex items-center gap-2 font-medium transition-colors">
                        ← Trocar Usuário
                     </button>
                     
                     <div className="text-center mb-8">
                         <div className="w-24 h-24 mx-auto bg-emerald-100 rounded-full flex items-center justify-center text-emerald-700 font-bold text-3xl mb-4 shadow-inner border-4 border-emerald-50">
                             {selectedUser.avatar}
                         </div>
                         <h3 className="font-bold text-slate-800 text-2xl">{selectedUser.name}</h3>
                         <p className="text-slate-500 mt-1 uppercase tracking-widest text-xs font-bold">{selectedUser.role}</p>
                     </div>

                     <div className="space-y-4">
                         <div>
                             <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Senha</label>
                             <div className="relative">
                                <Key className="absolute left-4 top-3.5 text-slate-400" size={18} />
                                <input 
                                    type="password" 
                                    autoFocus
                                    className="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all text-slate-800"
                                    placeholder="Digite sua senha..."
                                    value={passwordInput}
                                    onChange={e => { setPasswordInput(e.target.value); setError(''); }}
                                    onKeyDown={e => e.key === 'Enter' && handleLoginAttempt()}
                                    disabled={isLoadingLogin}
                                />
                             </div>
                             <div className="flex justify-end mt-2">
                                <button 
                                    onClick={() => setIsForgotModalOpen(true)}
                                    className="text-xs text-indigo-600 hover:text-indigo-800 hover:underline font-medium"
                                >
                                    Esqueci minha senha
                                </button>
                             </div>
                         </div>
                         {error && <p className="text-red-600 text-sm font-medium bg-red-50 p-3 rounded-lg flex items-center gap-2 animate-slide-in"><AlertTriangle size={16}/> {error}</p>}
                         
                         <button 
                            onClick={handleLoginAttempt}
                            className="w-full bg-slate-900 hover:bg-slate-800 text-white py-3.5 rounded-xl font-bold shadow-lg transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                            disabled={isLoadingLogin}
                         >
                            {isLoadingLogin ? <Loader2 size={20} className="animate-spin" /> : <LogIn size={20} />}
                             {isLoadingLogin ? 'Acessar Sistema' : 'Entrar na Plataforma'}
                         </button>
                     </div>
                </div>
              )}
            </div>
          ) : (
            <form onSubmit={handleRegisterSubmit} className="space-y-5 animate-fade-in">
                <h2 className="text-3xl font-bold text-slate-800 mb-6">Criar Conta</h2>
                
                {error && <p className="text-red-600 text-sm font-medium bg-red-50 p-3 rounded-lg flex items-center gap-2 animate-slide-in"><AlertTriangle size={16}/> {error}</p>}

                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Nome Completo</label>
                    <div className="relative">
                        <UserIcon className="absolute left-4 top-3.5 text-slate-400" size={18} />
                        <input 
                            type="text" 
                            required
                            className="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all text-slate-800"
                            placeholder="Ex: João da Silva"
                            value={newName}
                            onChange={e => setNewName(e.target.value)}
                            disabled={isLoadingRegister}
                        />
                    </div>
                </div>

                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Perfil de Acesso</label>
                    <div className="relative">
                         <select 
                            className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none text-slate-800 appearance-none"
                            value={newRole}
                            onChange={e => setNewRole(e.target.value as UserRole)}
                            disabled={isLoadingRegister}
                        >
                            <option value="EXECUTOR">Executor (Operacional)</option>
                            <option value="PLANNER">Planejador (Gestão)</option>
                            <option value="ADMIN">Administrador (Total)</option>
                        </select>
                        <div className="absolute right-4 top-4 pointer-events-none text-slate-500">
                             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                        </div>
                    </div>
                </div>

                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Empresa</label>
                    <div className="relative">
                         <select 
                            className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none text-slate-800 appearance-none"
                            value={selectedCompanyId}
                            onChange={e => setSelectedCompanyId(e.target.value)}
                            disabled={isLoadingRegister}
                        >
                            {companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                        <div className="absolute right-4 top-4 pointer-events-none text-slate-500">
                             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                        </div>
                    </div>
                </div>

                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Definir Senha</label>
                    <div className="relative">
                        <Key className="absolute left-4 top-3.5 text-slate-400" size={18} />
                        <input 
                            type="password"
                            required
                            className="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all text-slate-800"
                            placeholder="******"
                            value={newPassword}
                            onChange={e => setNewPassword(e.target.value)}
                            disabled={isLoadingRegister}
                        />
                    </div>
                    <p className="text-[10px] text-slate-400 mt-2 ml-1">Mín. 8 caracteres, Maiúscula, Minúscula e Símbolo.</p>
                </div>

                <div className="bg-amber-50 border border-amber-100 p-3 rounded-lg text-xs text-amber-800 flex items-start gap-2">
                    <AlertTriangle size={14} className="mt-0.5 shrink-0" />
                    <span>Seu cadastro ficará pendente de aprovação por um administrador antes do primeiro acesso.</span>
                </div>

                <button 
                    type="submit"
                    className="w-full bg-slate-900 hover:bg-slate-800 text-white py-3.5 rounded-xl font-bold transition-all shadow-lg hover:shadow-xl transform active:scale-[0.98] mt-4 flex items-center justify-center gap-2 disabled:opacity-70"
                    disabled={isLoadingRegister}
                >
                    {isLoadingRegister ? <Loader2 size={20} className="animate-spin" /> : <UserPlus size={20} />}
                    {isLoadingRegister ? 'Criando Conta...' : 'Solicitar Cadastro'}
                </button>
            </form>
          )}
        </div>
      </div>
      
      {/* Forced Password Change Modal */}
      {isChangePasswordOpen && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
             <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-6 animate-scale-in">
                 <div className="text-center">
                     <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-600">
                         <Key size={32} />
                     </div>
                     <h3 className="text-xl font-bold text-slate-800 mb-2">Redefinição Obrigatória</h3>
                     <p className="text-slate-600 text-sm mb-6 leading-relaxed">
                         Sua senha foi resetada pelo administrador. Por segurança, você deve definir uma nova senha agora.
                     </p>
                     
                     <div className="space-y-4 text-left">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nova Senha</label>
                            <input 
                                type="password"
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500/50"
                                value={changePasswordNew}
                                onChange={e => setChangePasswordNew(e.target.value)}
                                placeholder="******"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Confirmar Senha</label>
                            <input 
                                type="password"
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500/50"
                                value={changePasswordConfirm}
                                onChange={e => setChangePasswordConfirm(e.target.value)}
                                placeholder="******"
                            />
                        </div>
                        
                        {error && <p className="text-red-600 text-xs font-medium bg-red-50 p-2 rounded">{error}</p>}

                        <button 
                            onClick={handleChangePasswordSubmit}
                            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold transition-colors flex items-center justify-center gap-2"
                            disabled={isLoadingLogin}
                        >
                            {isLoadingLogin ? <Loader2 size={16} className="animate-spin" /> : 'Atualizar e Entrar'}
                        </button>
                     </div>
                 </div>
             </div>
        </div>
      )}

      {/* Forgot Password Modal */}
      {isForgotModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
             <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-6 animate-scale-in">
                 <div className="text-center">
                     <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4 text-amber-600">
                         <HelpCircle size={32} />
                     </div>
                     <h3 className="text-xl font-bold text-slate-800 mb-2">Esqueceu a senha?</h3>
                     <p className="text-slate-600 text-sm mb-6 leading-relaxed">
                         Como esta é uma plataforma segura local, não enviamos e-mails de recuperação.
                         <br/><br/>
                         Entre em contato com um <span className="font-bold text-slate-800">Administrador</span> do sistema. Eles podem redefinir sua senha no painel de Configurações.
                     </p>
                     <button 
                        onClick={() => setIsForgotModalOpen(false)}
                        className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 rounded-lg font-bold transition-colors"
                     >
                         Entendi, vou contatar o Admin
                     </button>
                 </div>
             </div>
        </div>
      )}

      <div className="fixed bottom-6 text-slate-500 text-xs opacity-60 font-medium">
        AuditControl v4.2 • Secured by SHA-256 & AES-GCM
      </div>
    </div>
  );
};