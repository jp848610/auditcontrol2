
import React, { useState } from 'react';
import { Department, CostCenter, NotifyFn, ComplianceRule, PartnerSegment, ActionType, User, UserRole, HistoryLog, Company, UserStatus } from '../types';
import { Plus, Trash2, Building, Layers, ListChecks, Users, RotateCcw, Info, Building2, Edit, X, Save, CheckCircle, Ban, Shield, FilePlus, Handshake, Eye } from 'lucide-react';
import { hashPassword } from '../services/authService';
import { ItemHistoryModal } from './ItemHistoryModal';

interface SettingsProps {
  departments: Department[];
  setDepartments: (data: Department[] | ((prev: Department[]) => Department[])) => void;
  costCenters: CostCenter[];
  setCostCenters: (data: CostCenter[] | ((prev: CostCenter[]) => CostCenter[])) => void;
  complianceRules: ComplianceRule[]; 
  setComplianceRules: (data: ComplianceRule[] | ((prev: ComplianceRule[]) => ComplianceRule[])) => void; 
  partnerSegments: PartnerSegment[]; 
  setPartnerSegments: (data: PartnerSegment[] | ((prev: PartnerSegment[]) => PartnerSegment[])) => void; 
  
  users: User[]; 
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  companies: Company[];
  setCompanies: React.Dispatch<React.SetStateAction<Company[]>>;
  currentUser: User;

  userRole?: UserRole; 
  notify: NotifyFn;
  showConfirmModal: (message: string, onConfirm: () => void) => void; 
  logAction: (action: ActionType, target: string, details: string, itemId?: string) => void; 
  historyLogs: HistoryLog[];
}

export const Settings: React.FC<SettingsProps> = ({ 
    departments, setDepartments, costCenters, setCostCenters, complianceRules, setComplianceRules, partnerSegments, setPartnerSegments, 
    users, setUsers, companies, setCompanies, currentUser, userRole,
    notify, showConfirmModal, logAction, historyLogs 
}) => {
  const [activeTab, setActiveTab] = useState<'GENERAL' | 'USERS' | 'COMPANIES'>('GENERAL');
  
  // History Modal State
  const [historyItemId, setHistoryItemId] = useState<string | null>(null);

  // General Settings State
  const [newDept, setNewDept] = useState('');
  const [newCC, setNewCC] = useState({ code: '', name: '', deptId: '' });
  const [newComplianceRule, setNewComplianceRule] = useState('');
  const [newPartnerSegment, setNewPartnerSegment] = useState(''); 
  const [newCompanyName, setNewCompanyName] = useState('');

  // User Management State
  const [isEditUserModalOpen, setIsEditUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<Partial<User> | null>(null);

  // Approval Modal State
  const [isApprovalModalOpen, setIsApprovalModalOpen] = useState(false);
  const [approvingUser, setApprovingUser] = useState<User | null>(null);
  const [approvalRole, setApprovalRole] = useState<UserRole>('EXECUTOR');

  // --- Helpers ---
  // Sort users so pending ones appear first for visibility
  const visibleUsers = users.filter(u => u.companyId === currentUser.companyId)
    .sort((a, b) => {
        if (a.status === 'PENDING' && b.status !== 'PENDING') return -1;
        if (a.status !== 'PENDING' && b.status === 'PENDING') return 1;
        return 0;
    });

  // --- Handlers ---

  const handleAddDept = () => {
    if (!newDept.trim()) {
      notify('O nome do departamento não pode ser vazio.', 'error');
      return;
    }
    const dept: Department = { id: `d${Date.now()}`, companyId: currentUser.companyId, name: newDept.trim() };
    setDepartments(prev => [...prev, dept]);
    setNewDept('');
    logAction('CREATE', `Departamento: ${dept.name}`, 'Novo departamento adicionado.', dept.id);
    notify('Departamento adicionado com sucesso!', 'success');
  };

  const handleDeleteDept = (id: string) => {
    const deptName = departments.find(d => d.id === id)?.name || 'Desconhecido';
    showConfirmModal('Tem certeza? Isso também removerá os Centros de Custo vinculados.', () => {
      setDepartments(prev => prev.filter(d => d.id !== id));
      setCostCenters(prev => prev.filter(cc => cc.departmentId !== id)); 
      logAction('DELETE', `Departamento: ${deptName}`, 'Departamento e centros de custo vinculados removidos.', id);
      notify('Departamento removido.', 'info');
    });
  };

  const handleAddCC = () => {
    if (!newCC.code.trim() || !newCC.name.trim() || !newCC.deptId) {
      notify('Preencha código, nome e vincule um departamento para o Centro de Custo.', 'error');
      return;
    }
    const cc: CostCenter = {
      id: `cc${Date.now()}`,
      companyId: currentUser.companyId,
      code: newCC.code.trim(),
      name: newCC.name.trim(),
      departmentId: newCC.deptId
    };
    setCostCenters(prev => [...prev, cc]);
    setNewCC({ code: '', name: '', deptId: '' });
    logAction('CREATE', `Centro de Custo: ${cc.code}`, `Novo centro de custo adicionado: ${cc.name}`, cc.id);
    notify('Centro de custo adicionado com sucesso!', 'success');
  };

  const handleDeleteCC = (id: string) => {
    const ccName = costCenters.find(c => c.id === id)?.name || 'Desconhecido';
    showConfirmModal('Tem certeza que deseja remover este Centro de Custo?', () => {
      setCostCenters(prev => prev.filter(c => c.id !== id));
      logAction('DELETE', `Centro de Custo: ${ccName}`, 'Centro de custo removido.', id);
      notify('Centro de custo removido.', 'info');
    });
  };

  const handleAddComplianceRule = () => {
    if (!newComplianceRule.trim()) {
      notify('A descrição da regra de compliance não pode ser vazio.', 'error');
      return;
    }
    const rule: ComplianceRule = { id: `cr${Date.now()}`, companyId: currentUser.companyId, description: newComplianceRule.trim() };
    setComplianceRules(prev => [...prev, rule]);
    setNewComplianceRule('');
    logAction('CREATE', `Regra Compliance: ${rule.description.substring(0, 20)}...`, 'Nova regra de conformidade adicionada.', rule.id);
    notify('Regra de Compliance adicionada!', 'success');
  };

  const handleDeleteComplianceRule = (id: string) => {
    const ruleDesc = complianceRules.find(r => r.id === id)?.description || 'Desconhecida';
    showConfirmModal('Tem certeza que deseja remover esta regra de Compliance?', () => {
      setComplianceRules(prev => prev.filter(r => r.id !== id));
      logAction('DELETE', `Regra Compliance: ${ruleDesc.substring(0, 20)}...`, 'Regra de conformidade removida.', id);
      notify('Regra de Compliance removida.', 'info');
    });
  };

  const handleAddPartnerSegment = () => {
    if (!newPartnerSegment.trim()) {
      notify('O nome do segmento de parceiro não pode ser vazio.', 'error');
      return;
    }
    const segment: PartnerSegment = { id: `ps${Date.now()}`, companyId: currentUser.companyId, name: newPartnerSegment.trim() };
    setPartnerSegments(prev => [...prev, segment]);
    setNewPartnerSegment('');
    logAction('CREATE', `Segmento: ${segment.name}`, 'Novo segmento de parceiro adicionado.', segment.id);
    notify('Segmento de parceiro adicionado com sucesso!', 'success');
  };

  const handleDeletePartnerSegment = (id: string) => {
    const segmentName = partnerSegments.find(s => s.id === id)?.name || 'Desconhecido';
    showConfirmModal('Tem certeza que deseja remover este segmento de parceiro?', () => {
      setPartnerSegments(prev => prev.filter(s => s.id !== id));
      logAction('DELETE', `Segmento: ${segmentName}`, 'Segmento de parceiro removido.', id);
      notify('Segmento de parceiro removido.', 'info');
    });
  };

  const handleAddCompany = () => {
     if (!newCompanyName.trim()) {
        notify('Nome da empresa é obrigatório.', 'error');
        return;
     }
     const newCompany: Company = {
        id: `c${Date.now()}`,
        name: newCompanyName.trim(),
        createdAt: new Date().toISOString()
     };
     setCompanies(prev => [...prev, newCompany]);
     setNewCompanyName('');
     notify('Empresa cadastrada com sucesso!', 'success');
  };

  // User Management
  const handleOpenEditUser = (user: User) => {
      setEditingUser({...user});
      setIsEditUserModalOpen(true);
  };

  const handleSaveUser = async () => {
      if (!editingUser || !editingUser.id || !editingUser.name || !editingUser.role || !editingUser.companyId) {
          notify('Preencha todos os campos do usuário.', 'error');
          return;
      }
      
      setUsers(prev => prev.map(u => u.id === editingUser.id ? { ...u, ...editingUser } as User : u));
      setIsEditUserModalOpen(false);
      logAction('UPDATE', `Usuário: ${editingUser.name}`, 'Dados de usuário atualizados pelo Admin.', editingUser.id);
      notify('Usuário atualizado com sucesso.', 'success');
  };

  const handleResetPassword = async (userId: string, userName: string) => {
     showConfirmModal(`Deseja resetar a senha de ${userName} para o padrão 'Mudar123'? O usuário será forçado a trocar a senha no próximo login.`, async () => {
         try {
             const defaultHash = await hashPassword('Mudar123');
             // Set mustChangePassword to true
             setUsers(prev => prev.map(u => u.id === userId ? { ...u, password: defaultHash, mustChangePassword: true } : u));
             logAction('UPDATE', `Usuário: ${userName}`, 'Senha resetada e troca forçada ativada.', userId);
             notify('Senha resetada com sucesso para "Mudar123".', 'success');
         } catch (error) {
             console.error("Error resetting password:", error);
             notify('Erro ao resetar senha.', 'error');
         }
     });
  };

  // --- APPROVAL FLOW ---
  const handleOpenApproval = (user: User) => {
      setApprovingUser(user);
      setApprovalRole(user.role); // Default to what they requested
      setIsApprovalModalOpen(true);
  };

  const handleConfirmApproval = () => {
      if (!approvingUser) return;

      // Update the user state
      setUsers(prev => prev.map(u => u.id === approvingUser.id ? { ...u, status: 'APPROVED', role: approvalRole } : u));
      
      logAction('APPROVE', `Usuário: ${approvingUser.name}`, `Usuário aprovado com perfil ${approvalRole}.`, approvingUser.id);
      notify(`Usuário ${approvingUser.name} aprovado com sucesso!`, 'success');
      
      setIsApprovalModalOpen(false);
      setApprovingUser(null);
  };

  const handleBlockUser = (userId: string, userName: string) => {
      showConfirmModal(`Deseja BLOQUEAR o acesso de ${userName}? O usuário não poderá mais entrar no sistema.`, () => {
          setUsers(prev => prev.map(u => u.id === userId ? { ...u, status: 'BLOCKED' } : u));
          logAction('BLOCK', `Usuário: ${userName}`, 'Usuário bloqueado pelo administrador.', userId);
          notify('Usuário bloqueado.', 'info');
      });
  };

  const handleUnblockUser = (userId: string, userName: string) => {
      showConfirmModal(`Deseja DESBLOQUEAR o acesso de ${userName}?`, () => {
          setUsers(prev => prev.map(u => u.id === userId ? { ...u, status: 'APPROVED' } : u));
          logAction('APPROVE', `Usuário: ${userName}`, 'Usuário desbloqueado.', userId);
          notify('Usuário desbloqueado.', 'success');
      });
  };

  const getHistoryItemTitle = () => {
      if (!historyItemId) return 'Item';
      const user = users.find(u => u.id === historyItemId);
      if (user) return `Usuário: ${user.name}`;
      return 'Configuração'; 
  };

  return (
    <div className="space-y-6 animate-fade-in pb-20 relative">
      <header className="flex items-center justify-between">
        <div>
           <h2 className="text-2xl font-bold text-slate-800">Configurações</h2>
           <p className="text-slate-500">Gerencie cadastros base, empresas e usuários.</p>
        </div>
        
        {userRole === 'ADMIN' && (
            <div className="bg-slate-100 p-1 rounded-lg flex gap-1">
                <button 
                    onClick={() => setActiveTab('GENERAL')}
                    className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'GENERAL' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    Cadastros Gerais
                </button>
                <button 
                    onClick={() => setActiveTab('USERS')}
                    className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'USERS' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    Gestão de Usuários
                </button>
                <button 
                    onClick={() => setActiveTab('COMPANIES')}
                    className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'COMPANIES' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    Gestão de Empresas
                </button>
            </div>
        )}
      </header>

      {/* Item History Modal */}
      <ItemHistoryModal 
        isOpen={!!historyItemId}
        onClose={() => setHistoryItemId(null)}
        itemTitle={getHistoryItemTitle()}
        logs={historyLogs.filter(log => log.itemId === historyItemId)}
      />

      {activeTab === 'GENERAL' ? (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Departments Column */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 flex flex-col">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50 rounded-t-xl">
             <div className="flex items-center gap-3 mb-4">
               <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg"><Building size={20} /></div>
               <h3 className="font-bold text-slate-700">Departamentos</h3>
             </div>
             <div className="flex gap-2">
               <input 
                 type="text" 
                 placeholder="Novo Departamento..." 
                 className="flex-1 border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none bg-white text-slate-800"
                 value={newDept}
                 onChange={e => setNewDept(e.target.value)}
               />
               <button onClick={handleAddDept} className="bg-indigo-600 text-white px-3 rounded-lg hover:bg-indigo-700 transition-colors">
                 <Plus size={20} />
               </button>
             </div>
          </div>
          <div className="p-2 flex-1 overflow-y-auto max-h-96 custom-scrollbar">
            {departments.length === 0 && <p className="text-center text-slate-400 py-4 text-sm">Nenhum departamento cadastrado.</p>}
            <ul className="space-y-1">
              {departments.map(dept => (
                <li key={dept.id} className="flex justify-between items-center p-3 hover:bg-slate-50 rounded-lg group transition-colors">
                  <span className="text-slate-700 font-medium">{dept.name}</span>
                  <button onClick={() => handleDeleteDept(dept.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                    <Trash2 size={16} />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Cost Centers Column */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 flex flex-col">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50 rounded-t-xl">
             <div className="flex items-center gap-3 mb-4">
               <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg"><Layers size={20} /></div>
               <h3 className="font-bold text-slate-700">Centros de Custo</h3>
             </div>
             <div className="grid grid-cols-2 gap-2 mb-2">
               <input 
                 type="text" 
                 placeholder="Código (ex: CC-01)" 
                 className="border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500/50 outline-none bg-white text-slate-800"
                 value={newCC.code}
                 onChange={e => setNewCC({...newCC, code: e.target.value})}
               />
               <select
                  className="border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500/50 outline-none bg-white text-slate-800 text-slate-800"
                  value={newCC.deptId}
                  onChange={e => setNewCC({...newCC, deptId: e.target.value})}
               >
                 <option value="">Vincular Depto...</option>
                 {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
               </select>
             </div>
             <div className="flex gap-2">
                <input 
                  type="text" 
                  placeholder="Nome do Centro de Custo..." 
                  className="flex-1 border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500/50 outline-none bg-white text-slate-800"
                  value={newCC.name}
                  onChange={e => setNewCC({...newCC, name: e.target.value})}
                />
                <button onClick={handleAddCC} className="bg-emerald-600 text-white px-3 rounded-lg hover:bg-emerald-700 transition-colors">
                  <Plus size={20} />
                </button>
             </div>
          </div>
          <div className="p-2 flex-1 overflow-y-auto max-h-96 custom-scrollbar">
             {costCenters.length === 0 && <p className="text-center text-slate-400 py-4 text-sm">Nenhum centro de custo cadastrado.</p>}
             <ul className="space-y-1">
              {costCenters.map(cc => {
                const deptName = departments.find(d => d.id === cc.departmentId)?.name || 'Desconhecido';
                return (
                  <li key={cc.id} className="flex justify-between items-center p-3 hover:bg-slate-50 rounded-lg group transition-colors">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold bg-slate-200 text-slate-600 px-1.5 rounded">{cc.code}</span>
                        <span className="text-slate-700 font-medium">{cc.name}</span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">{deptName}</p>
                    </div>
                    <button onClick={() => handleDeleteCC(cc.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                      <Trash2 size={16} />
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>

        {/* Compliance Rules Column */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 flex flex-col">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50 rounded-t-xl">
             <div className="flex items-center gap-3 mb-4">
               <div className="p-2 bg-yellow-100 text-yellow-600 rounded-lg"><ListChecks size={20} /></div>
               <h3 className="font-bold text-slate-700">Critérios de Compliance</h3>
             </div>
             <div className="flex gap-2">
               <input 
                 type="text" 
                 placeholder="Nova regra de compliance..." 
                 className="flex-1 border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-yellow-500/50 outline-none bg-white text-slate-800"
                 value={newComplianceRule}
                 onChange={e => setNewComplianceRule(e.target.value)}
               />
               <button onClick={handleAddComplianceRule} className="bg-yellow-600 text-white px-3 rounded-lg hover:bg-yellow-700 transition-colors">
                 <Plus size={20} />
               </button>
             </div>
          </div>
          <div className="p-2 flex-1 overflow-y-auto max-h-96 custom-scrollbar">
            {complianceRules.length === 0 && <p className="text-center text-slate-400 py-4 text-sm">Nenhuma regra cadastrada.</p>}
            <ul className="space-y-1">
              {complianceRules.map(rule => (
                <li key={rule.id} className="flex justify-between items-center p-3 hover:bg-slate-50 rounded-lg group transition-colors">
                  <span className="text-slate-700 font-medium">{rule.description}</span>
                  <button onClick={() => handleDeleteComplianceRule(rule.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                    <Trash2 size={16} />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      ) : activeTab === 'USERS' ? (
          <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
              <div className="p-6 border-b border-slate-100 bg-slate-50/50">
                  <div className="flex items-center gap-3">
                      <div className="p-2 bg-slate-800 text-white rounded-lg"><Users size={20} /></div>
                      <div>
                          <h3 className="font-bold text-slate-700">Gestão de Usuários</h3>
                          <p className="text-xs text-slate-500">Aprovação de cadastros e gestão de acessos.</p>
                      </div>
                  </div>
              </div>
              
              <div className="p-6">
                  <table className="w-full text-left text-sm">
                      <thead className="bg-slate-50 border-b border-slate-100">
                          <tr>
                              <th className="px-6 py-4 font-semibold text-slate-600">Usuário</th>
                              <th className="px-6 py-4 font-semibold text-slate-600">Status</th>
                              <th className="px-6 py-4 font-semibold text-slate-600">Perfil</th>
                              <th className="px-6 py-4 font-semibold text-slate-600">Empresa</th>
                              <th className="px-6 py-4 font-semibold text-slate-600 text-right">Ações</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {visibleUsers.map(u => (
                              <tr key={u.id} className={`hover:bg-slate-50 ${u.status === 'PENDING' ? 'bg-amber-50/50' : ''}`}>
                                  <td className="px-6 py-4 flex items-center gap-3">
                                      <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-600">
                                          {u.avatar}
                                      </div>
                                      <span className="font-medium text-slate-800">{u.name}</span>
                                  </td>
                                  <td className="px-6 py-4">
                                      <span className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wider
                                        ${u.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' : 
                                          u.status === 'BLOCKED' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}
                                      `}>
                                          {u.status === 'APPROVED' ? 'Ativo' : u.status === 'BLOCKED' ? 'Bloqueado' : 'Pendente'}
                                      </span>
                                  </td>
                                  <td className="px-6 py-4">
                                      <span className="bg-slate-100 px-2 py-1 rounded text-xs font-bold text-slate-600 uppercase tracking-wider">{u.role}</span>
                                  </td>
                                  <td className="px-6 py-4 text-slate-500">
                                      {companies.find(c => c.id === u.companyId)?.name || 'Sem Empresa'}
                                  </td>
                                  <td className="px-6 py-4 text-right flex justify-end gap-2">
                                      {/* Approval Actions */}
                                      {u.status === 'PENDING' && (
                                          <button 
                                            onClick={() => handleOpenApproval(u)}
                                            className="bg-emerald-600 hover:bg-emerald-700 text-white px-2 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1"
                                            title="Revisar e Aprovar"
                                          >
                                              <CheckCircle size={14} /> Aprovar
                                          </button>
                                      )}
                                      {u.status !== 'BLOCKED' ? (
                                          <button 
                                            onClick={() => handleBlockUser(u.id, u.name)}
                                            className="text-red-500 hover:text-red-700 hover:bg-red-50 px-2 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1"
                                            title="Bloquear Acesso"
                                          >
                                              <Ban size={14} />
                                          </button>
                                      ) : (
                                          <button 
                                            onClick={() => handleUnblockUser(u.id, u.name)}
                                            className="text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 px-2 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1"
                                            title="Desbloquear"
                                          >
                                              <CheckCircle size={14} />
                                          </button>
                                      )}

                                      <div className="w-px h-6 bg-slate-200 mx-1"></div>

                                      <button 
                                          onClick={() => setHistoryItemId(u.id)} 
                                          className="text-slate-400 hover:text-slate-600 hover:bg-slate-50 px-2 py-1.5 rounded-lg text-xs font-medium transition-colors"
                                          title="Histórico"
                                      >
                                          <Info size={14} />
                                      </button>
                                      <button 
                                        onClick={() => handleOpenEditUser(u)}
                                        className="text-blue-600 hover:text-blue-800 hover:bg-blue-50 px-2 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1"
                                        title="Editar"
                                      >
                                          <Edit size={14} />
                                      </button>
                                      <button 
                                        onClick={() => handleResetPassword(u.id, u.name)}
                                        className="text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 px-2 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1"
                                        title="Resetar Senha"
                                      >
                                          <RotateCcw size={14} />
                                      </button>
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          </div>
      ) : (
          <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
             <div className="p-6 border-b border-slate-100 bg-slate-50/50">
                  <div className="flex items-center gap-3">
                      <div className="p-2 bg-indigo-800 text-white rounded-lg"><Building2 size={20} /></div>
                      <div>
                          <h3 className="font-bold text-slate-700">Gestão de Empresas (Multi-Tenancy)</h3>
                          <p className="text-xs text-slate-500">Cadastre empresas para isolar dados.</p>
                      </div>
                  </div>
              </div>
              <div className="p-6">
                 <div className="flex gap-2 mb-6 max-w-lg">
                    <input 
                       type="text"
                       placeholder="Nome da Nova Empresa..."
                       className="flex-1 border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none bg-white text-slate-800"
                       value={newCompanyName}
                       onChange={e => setNewCompanyName(e.target.value)}
                    />
                    <button onClick={handleAddCompany} className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-2 text-sm font-medium">
                        <Plus size={16}/> Adicionar
                    </button>
                 </div>

                 <table className="w-full text-left text-sm">
                      <thead className="bg-slate-50 border-b border-slate-100">
                          <tr>
                              <th className="px-6 py-4 font-semibold text-slate-600">ID</th>
                              <th className="px-6 py-4 font-semibold text-slate-600">Nome da Empresa</th>
                              <th className="px-6 py-4 font-semibold text-slate-600">Data Criação</th>
                              <th className="px-6 py-4 font-semibold text-slate-600 text-right">Usuários Vinculados</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {companies.map(c => (
                              <tr key={c.id} className="hover:bg-slate-50">
                                  <td className="px-6 py-4 font-mono text-xs text-slate-400">{c.id}</td>
                                  <td className="px-6 py-4 font-medium text-slate-800">{c.name}</td>
                                  <td className="px-6 py-4 text-slate-500">{new Date(c.createdAt).toLocaleDateString()}</td>
                                  <td className="px-6 py-4 text-right">
                                      <span className="bg-slate-100 px-2 py-1 rounded text-xs font-bold text-slate-600">
                                          {users.filter(u => u.companyId === c.id).length}
                                      </span>
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                 </table>
              </div>
          </div>
      )}

      {/* Partner Segments Section (Visible in General Tab) */}
      {activeTab === 'GENERAL' && (
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 flex flex-col mt-6">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50 rounded-t-xl">
             <div className="flex items-center gap-3 mb-4">
               <div className="p-2 bg-blue-100 text-blue-600 rounded-lg"><Users size={20} /></div>
               <h3 className="font-bold text-slate-700">Segmentos de Parceiros</h3>
             </div>
             <div className="flex gap-2">
               <input 
                 type="text" 
                 placeholder="Novo Segmento (ex: Tecnologia)..." 
                 className="flex-1 border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500/50 outline-none bg-white text-slate-800"
                 value={newPartnerSegment}
                 onChange={e => setNewPartnerSegment(e.target.value)}
               />
               <button onClick={handleAddPartnerSegment} className="bg-blue-600 text-white px-3 rounded-lg hover:bg-blue-700 transition-colors">
                 <Plus size={20} />
               </button>
             </div>
          </div>
          <div className="p-2 flex-1 overflow-y-auto max-h-96 custom-scrollbar">
            {partnerSegments.length === 0 && <p className="text-center text-slate-400 py-4 text-sm">Nenhum segmento cadastrado.</p>}
            <ul className="space-y-1">
              {partnerSegments.map(segment => (
                <li key={segment.id} className="flex justify-between items-center p-3 hover:bg-slate-50 rounded-lg group transition-colors">
                  <span className="text-slate-700 font-medium">{segment.name}</span>
                  <button onClick={() => handleDeletePartnerSegment(segment.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                    <Trash2 size={16} />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
      
      {/* Approval & Role Definition Modal */}
      {isApprovalModalOpen && approvingUser && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-[9999]">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg animate-scale-in">
                <div className="p-6 border-b border-slate-100 bg-emerald-50 rounded-t-2xl flex justify-between items-center">
                    <div>
                        <h3 className="text-xl font-bold text-emerald-900 flex items-center gap-2">
                            <CheckCircle className="text-emerald-600" /> Aprovar Acesso
                        </h3>
                        <p className="text-sm text-emerald-700 mt-1">Defina as permissões para <b>{approvingUser.name}</b></p>
                    </div>
                    <button onClick={() => setIsApprovalModalOpen(false)}><X className="text-emerald-400 hover:text-emerald-700" /></button>
                </div>
                
                <div className="p-6">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-3">Selecione o Perfil de Acesso (Role)</label>
                    
                    <div className="space-y-3">
                        <label className={`flex items-start gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${approvalRole === 'ADMIN' ? 'border-indigo-500 bg-indigo-50' : 'border-slate-200 hover:border-slate-300'}`}>
                            <input 
                                type="radio" 
                                name="role" 
                                value="ADMIN" 
                                checked={approvalRole === 'ADMIN'} 
                                onChange={() => setApprovalRole('ADMIN')}
                                className="mt-1"
                            />
                            <div>
                                <span className="block font-bold text-slate-800 flex items-center gap-2"><Shield size={16} className="text-indigo-600"/> Administrador</span>
                                <p className="text-xs text-slate-500 mt-1">Acesso total ao sistema, incluindo configurações, gestão de usuários, empresas e aprovação de todos os fluxos.</p>
                            </div>
                        </label>

                        <label className={`flex items-start gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${approvalRole === 'PLANNER' ? 'border-blue-500 bg-blue-50' : 'border-slate-200 hover:border-slate-300'}`}>
                            <input 
                                type="radio" 
                                name="role" 
                                value="PLANNER" 
                                checked={approvalRole === 'PLANNER'} 
                                onChange={() => setApprovalRole('PLANNER')}
                                className="mt-1"
                            />
                            <div>
                                <span className="block font-bold text-slate-800 flex items-center gap-2"><FilePlus size={16} className="text-blue-600"/> Planejador</span>
                                <p className="text-xs text-slate-500 mt-1">Acesso ao Dashboard, Portal da Transparência, Planejamento Orçamentário, Orçamento Matricial e Solicitações.</p>
                            </div>
                        </label>

                        <label className={`flex items-start gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${approvalRole === 'EXECUTOR' ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200 hover:border-slate-300'}`}>
                            <input 
                                type="radio" 
                                name="role" 
                                value="EXECUTOR" 
                                checked={approvalRole === 'EXECUTOR'} 
                                onChange={() => setApprovalRole('EXECUTOR')}
                                className="mt-1"
                            />
                            <div>
                                <span className="block font-bold text-slate-800 flex items-center gap-2"><Handshake size={16} className="text-emerald-600"/> Executor</span>
                                <p className="text-xs text-slate-500 mt-1">Acesso ao Dashboard, Transparência, Negociações, Parceiros e Solicitações. Ideal para compras e operacional.</p>
                            </div>
                        </label>
                        
                        <label className={`flex items-start gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${approvalRole === 'DEMO' ? 'border-amber-500 bg-amber-50' : 'border-slate-200 hover:border-slate-300'}`}>
                            <input 
                                type="radio" 
                                name="role" 
                                value="DEMO" 
                                checked={approvalRole === 'DEMO'} 
                                onChange={() => setApprovalRole('DEMO')}
                                className="mt-1"
                            />
                            <div>
                                <span className="block font-bold text-slate-800 flex items-center gap-2"><Eye size={16} className="text-amber-600"/> Demo (Visualização)</span>
                                <p className="text-xs text-slate-500 mt-1">Acesso restrito apenas para visualização do Dashboard e Portal da Transparência (sem dados sensíveis).</p>
                            </div>
                        </label>
                    </div>
                </div>

                <div className="p-6 border-t border-slate-100 flex justify-end gap-3 bg-slate-50 rounded-b-2xl">
                    <button onClick={() => setIsApprovalModalOpen(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-200 rounded-lg font-medium transition-colors">Cancelar</button>
                    <button onClick={handleConfirmApproval} className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-lg shadow-emerald-200 font-bold transition-all flex items-center gap-2">
                        <CheckCircle size={18}/> Confirmar Aprovação
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* Edit User Modal */}
      {isEditUserModalOpen && editingUser && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-md animate-scale-in">
                <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50 rounded-t-2xl">
                    <h3 className="text-xl font-bold text-slate-800">Editar Usuário</h3>
                    <button onClick={() => setIsEditUserModalOpen(false)}><X className="text-slate-400 hover:text-slate-600" /></button>
                </div>
                <div className="p-6 space-y-4">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome</label>
                        <input 
                           className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800"
                           value={editingUser.name}
                           onChange={e => setEditingUser({...editingUser, name: e.target.value})}
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Status</label>
                        <select
                           className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800 text-slate-800"
                           value={editingUser.status}
                           onChange={e => setEditingUser({...editingUser, status: e.target.value as UserStatus})}
                        >
                            <option value="PENDING">Pendente</option>
                            <option value="APPROVED">Ativo / Aprovado</option>
                            <option value="BLOCKED">Bloqueado</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Perfil (Role)</label>
                        <select
                           className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800 text-slate-800"
                           value={editingUser.role}
                           onChange={e => setEditingUser({...editingUser, role: e.target.value as UserRole})}
                        >
                            <option value="EXECUTOR">Executor</option>
                            <option value="PLANNER">Planejador</option>
                            <option value="ADMIN">Administrador</option>
                            <option value="DEMO">Demo</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Vincular Empresa</label>
                        <select
                           className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800 text-slate-800"
                           value={editingUser.companyId}
                           onChange={e => setEditingUser({...editingUser, companyId: e.target.value})}
                        >
                            {companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                </div>
                <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
                    <button onClick={() => setIsEditUserModalOpen(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancelar</button>
                    <button onClick={handleSaveUser} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg flex items-center gap-2">
                        <Save size={16}/> Salvar
                    </button>
                </div>
            </div>
        </div>
      )}

    </div>
  );
};
