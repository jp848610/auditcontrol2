import React, { useMemo } from 'react';
import { Audit, PurchaseRequest, User, ComplianceRule, Partner, HistoryLog, ViewState } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';
import { Globe, Award, TrendingUp, ShieldCheck, CheckCircle, Activity, Building, FileText, Star, Lightbulb, Loader2, Lock, Users, UserPlus, Clock, Plus, Edit, Trash2, XCircle } from 'lucide-react';

interface TransparencyPortalProps {
  audits: Audit[];
  requests: PurchaseRequest[];
  users: User[];
  complianceRules: ComplianceRule[];
  partners: Partner[];
  isLoadingApp: boolean;
  user: User;
  historyLogs: HistoryLog[]; 
  onNavigate: (view: ViewState) => void;
}

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#64748b'];

export const TransparencyPortal: React.FC<TransparencyPortalProps> = ({ audits, requests, users, complianceRules, partners, isLoadingApp, user, historyLogs, onNavigate }) => {

  // --- Macro Calculations ---
  const stats = useMemo(() => {
    const totalBudget = audits.reduce((acc, curr) => acc + curr.plannedBudget, 0);
    const totalExecuted = audits.reduce((acc, curr) => acc + curr.executedBudget, 0);
    const totalSavings = audits.reduce((acc, curr) => {
        // Calculate saving based on Initial vs Final negotiation
        const saving = curr.initialQuote > 0 && curr.finalPrice > 0 ? (curr.initialQuote - curr.finalPrice) : 0;
        return acc + saving;
    }, 0);

    const percentConsumed = totalBudget > 0 ? (totalExecuted / totalBudget) * 100 : 0;
    
    // Compliance Score based on actual ratings
    const ratedAudits = audits.filter(a => a.complianceRating !== undefined && a.complianceRating > 0);
    const totalRatingSum = ratedAudits.reduce((acc, curr) => acc + (curr.complianceRating || 0), 0);
    const avgComplianceRating = ratedAudits.length > 0 ? totalRatingSum / ratedAudits.length : 0;

    // Convert average rating (1-5) to a score (0-100)
    const complianceScore = Math.round((avgComplianceRating / 5) * 100);

    // Supplier Metrics
    const totalPartners = partners.length;
    const currentYear = new Date().getFullYear();
    const newPartnersCount = partners.filter(p => {
        // Assuming ID format is "p" + timestamp
        const timestamp = parseInt(p.id.replace('p', ''));
        const createdDate = new Date(timestamp);
        return !isNaN(createdDate.getTime()) && createdDate.getFullYear() === currentYear;
    }).length;

    return { totalBudget, totalExecuted, totalSavings, percentConsumed, complianceScore, avgComplianceRating, totalPartners, newPartnersCount };
  }, [audits, partners]);

  // --- Department Breakdown ---
  const deptData = useMemo(() => {
    const data: Record<string, number> = {};
    audits.forEach(a => {
        if (!data[a.department]) data[a.department] = 0;
        data[a.department] += a.executedBudget;
    });
    return Object.keys(data)
        .map(key => ({ name: key, value: data[key] }))
        .sort((a, b) => b.value - a.value);
  }, [audits]);

  // --- Savings Ranking by Dept ---
  const savingsData = useMemo(() => {
      const data: Record<string, number> = {};
      audits.forEach(a => {
          if (a.initialQuote > 0 && a.finalPrice > 0 && a.negotiationStatus === 'APPROVED') {
              const saving = a.initialQuote - a.finalPrice;
              if (!data[a.department]) data[a.department] = 0;
              data[a.department] += saving;
          }
      });
      return Object.keys(data)
        .map(key => ({ name: key, value: data[key] }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 5); // Top 5
  }, [audits]);

  // --- Recent Activity Feed (Using HistoryLog) ---
  const activityFeed = useMemo(() => {
      // Filter for significant events for transparency (Create, Approve, Reject)
      return historyLogs
          .filter(log => ['CREATE', 'APPROVE', 'REJECT', 'UPDATE'].includes(log.action))
          .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
          .slice(0, 6);
  }, [historyLogs]);

  const getComplianceGrade = (score: number) => {
    if (score >= 90) return 'A+';
    if (score >= 80) return 'A';
    if (score >= 70) return 'B+';
    if (score >= 60) return 'B';
    if (score >= 50) return 'C+';
    return 'C';
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'CREATE': return <Plus size={18} />;
      case 'UPDATE': return <Edit size={18} />;
      case 'DELETE': return <Trash2 size={18} />;
      case 'APPROVE': return <CheckCircle size={18} />;
      case 'REJECT': return <XCircle size={18} />;
      default: return <Clock size={18} />;
    }
  };

  // Helper for formatting currency with cents
  const formatCurrency = (value: number) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  if (isLoadingApp) {
    return (
      <div className="space-y-8 animate-fade-in pb-20">
        <div className="h-12 bg-slate-200 rounded-lg w-full animate-pulse"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Array(4).fill(0).map((_, i) => (
            <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 h-40 animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  // Restrict content for DEMO user
  if (user.role === 'DEMO') {
    return (
      <div className="flex flex-col items-center justify-center h-[calc(100vh-150px)] text-slate-500 animate-fade-in p-4">
        <Lock size={64} className="text-slate-300 mb-6" />
        <h2 className="text-3xl font-bold text-slate-700 mb-2">Acesso Restrito</h2>
        <p className="text-center text-lg max-w-md">
          Os dados de Transparência não estão disponíveis para o perfil <span className="font-semibold text-indigo-600">Demo</span>.
          Faça login com um perfil completo para acessar todas as informações.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in pb-20">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-200 pb-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 flex items-center gap-3">
             <div className="p-2 bg-emerald-100 rounded-lg text-emerald-600">
                <Globe size={32} />
             </div>
             Portal da Transparência
          </h2>
          <p className="text-slate-500 mt-1 text-lg">
            Governança corporativa, eficiência de gastos e accountability em tempo real.
          </p>
        </div>
        <div className="bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm text-right">
            <span className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Última Atualização</span>
            <span className="font-mono text-slate-700 font-medium">{new Date().toLocaleString('pt-BR')}</span>
        </div>
      </div>

      {/* Hero Stats - Updated Visuals & Navigation */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <MetricCard 
              title="Orçamento Consumido" 
              value={`${stats.percentConsumed.toFixed(1)}%`}
              icon={Activity}
              iconBg="from-blue-500 to-blue-600"
              textColor="text-blue-600"
              subtext="Do total previsto anual"
              onClick={() => onNavigate('PLANNING')}
          />
          
          <MetricCard 
              title="Economia Global (Saving)" 
              value={formatCurrency(stats.totalSavings)}
              icon={TrendingUp}
              iconBg="from-emerald-500 to-emerald-600"
              textColor="text-emerald-600"
              subtext="Recursos otimizados"
              onClick={() => onNavigate('NEGOTIATIONS')}
          />

          <MetricCard 
              title="Score de Compliance" 
              value={`${getComplianceGrade(stats.complianceScore)} / ${stats.complianceScore}`}
              icon={ShieldCheck}
              iconBg="from-indigo-500 to-indigo-600"
              textColor="text-indigo-600"
              subtext={`Média de ${stats.avgComplianceRating.toFixed(1)} estrelas`}
              onClick={() => onNavigate('NEGOTIATIONS')}
          />

           <MetricCard 
              title="Total em Execução" 
              value={formatCurrency(stats.totalExecuted)}
              icon={Building}
              iconBg="from-slate-600 to-slate-700"
              textColor="text-slate-600"
              subtext="Investimento aplicado"
              onClick={() => onNavigate('PLANNING')}
          />

          <MetricCard 
              title="Total de Parceiros" 
              value={stats.totalPartners.toString()}
              icon={Users}
              iconBg="from-purple-500 to-purple-600"
              textColor="text-purple-600"
              subtext="Fornecedores ativos"
              onClick={() => onNavigate('PARTNERS')}
          />

          <MetricCard 
              title="Novos Parceiros (Ano)" 
              value={stats.newPartnersCount.toString()}
              icon={UserPlus}
              iconBg="from-amber-500 to-amber-600"
              textColor="text-amber-600"
              subtext="Cadastrados este ano"
              onClick={() => onNavigate('PARTNERS')}
          />
      </div>

      {/* Visualizations Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Chart 1: Expenses by Dept */}
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex flex-col h-[400px]">
              <div className="flex items-center justify-between mb-6">
                 <h3 className="font-bold text-slate-700 flex items-center gap-2">
                     <Building size={20} className="text-slate-400"/> Distribuição de Despesas
                 </h3>
              </div>
              <div className="flex-1 w-full min-w-0">
                <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                            data={deptData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={100}
                            paddingAngle={5}
                            dataKey="value"
                        >
                            {deptData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip 
                            formatter={(value: number) => formatCurrency(value)}
                            contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                        />
                        <Legend verticalAlign="middle" align="right" layout="vertical" />
                    </PieChart>
                </ResponsiveContainer>
              </div>
          </div>

          {/* Chart 2: Efficiency Ranking */}
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex flex-col h-[400px]">
              <div className="flex items-center justify-between mb-6">
                 <h3 className="font-bold text-slate-700 flex items-center gap-2">
                     <Award size={20} className="text-amber-500"/> Ranking de Eficiência (Savings)
                 </h3>
              </div>
              <div className="flex-1 w-full min-w-0">
                 <ResponsiveContainer width="100%" height="100%">
                     <BarChart data={savingsData} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                        <XAxis type="number" hide />
                        <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} />
                        <Tooltip 
                            cursor={{fill: 'transparent'}} 
                            formatter={(value: number) => [formatCurrency(value), 'Economia']} 
                            contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                        />
                        <Bar dataKey="value" fill="#10b981" radius={[0, 4, 4, 0]} barSize={20} />
                        <Legend />
                     </BarChart>
                 </ResponsiveContainer>
              </div>
              <p className="text-center text-xs text-slate-400 mt-2">
                  Departamentos que geraram maior economia nas negociações.
              </p>
          </div>
      </div>

      {/* Governance Feed (Powered by History Log) */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
              <h3 className="font-bold text-slate-700 flex items-center gap-2">
                  <FileText size={20} className="text-blue-500"/> Feed de Governança
              </h3>
              <span className="text-xs font-bold text-slate-400 uppercase">Últimos Registros (Auditados)</span>
          </div>
          <div className="divide-y divide-slate-100">
              {activityFeed.map((log) => (
                  <div key={log.id} className="p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 
                          ${log.action === 'CREATE' ? 'bg-indigo-100 text-indigo-600' : ''}
                          ${log.action === 'APPROVE' ? 'bg-emerald-100 text-emerald-600' : ''}
                          ${log.action === 'REJECT' ? 'bg-red-100 text-red-600' : ''}
                          ${log.action === 'UPDATE' ? 'bg-blue-100 text-blue-600' : ''}
                          `}>
                          {getActionIcon(log.action)}
                      </div>
                      <div className="flex-1">
                          <h4 className="font-semibold text-slate-800 text-sm">{log.target}</h4>
                          <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                              <span>Por: {log.userName}</span>
                              <span>•</span>
                              <span>{new Date(log.timestamp).toLocaleDateString('pt-BR')} {new Date(log.timestamp).toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}</span>
                          </div>
                      </div>
                      <div className="text-right">
                           <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase
                               ${log.action === 'APPROVE' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                               {log.action === 'CREATE' ? 'Criado' : log.action === 'APPROVE' ? 'Aprovado' : log.action === 'REJECT' ? 'Reprovado' : 'Editado'}
                           </span>
                      </div>
                  </div>
              ))}
              
              {activityFeed.length === 0 && (
                  <div className="p-8 text-center text-slate-400 text-sm">
                      Nenhuma atividade recente registrada no sistema.
                  </div>
              )}
          </div>
      </div>

    </div>
  );
};

// Updated Metric Card with Gradient and Interaction
const MetricCard = ({ title, value, icon: Icon, iconBg, textColor, subtext, onClick }: any) => (
  <div 
    onClick={onClick}
    className={`bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center gap-4 transition-all duration-300 relative overflow-hidden group 
    ${onClick ? 'cursor-pointer hover:shadow-md hover:scale-[1.02]' : ''}`}
  >
    {/* Gradient Background for Icon */}
    <div className={`p-4 rounded-xl bg-gradient-to-br ${iconBg} text-white shadow-sm shrink-0`}>
      <Icon size={24} />
    </div>
    
    <div className="z-10">
      <p className="text-sm text-slate-500 font-medium">{title}</p>
      <h3 className={`text-2xl font-bold ${textColor} mt-1`}>{value}</h3>
      {subtext && <p className="text-[10px] text-slate-400 mt-1">{subtext}</p>}
    </div>

    {/* Subtle Decorative Circle */}
    <div className={`absolute -right-4 -bottom-4 w-24 h-24 rounded-full opacity-5 bg-gradient-to-br ${iconBg} pointer-events-none group-hover:scale-110 transition-transform`}></div>
  </div>
);