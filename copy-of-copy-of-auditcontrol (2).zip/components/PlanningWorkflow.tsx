
import React, { useState, useMemo } from 'react';
import { Audit, AuditStatus, Department, CostCenter, NotifyFn, ActionType, User, HistoryLog } from '../types';
import { suggestBudgetAndCategory } from '../services/geminiService';
import { Plus, Search, ArrowDown, Trash2, Calendar, Repeat, User as UserIcon, DollarSign, Loader2, Sparkles, Box, FileText, Download, Info } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ItemHistoryModal } from './ItemHistoryModal';

interface PlanningWorkflowProps {
  user: User;
  audits: Audit[];
  setAudits: (data: Audit[] | ((prev: Audit[]) => Audit[])) => void;
  departments?: Department[];
  costCenters?: CostCenter[];
  notify: NotifyFn;
  showConfirmModal: (message: string, onConfirm: () => void) => void;
  logAction: (action: ActionType, target: string, details: string, itemId?: string) => void; 
  historyLogs: HistoryLog[];
}

const MONTHS = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

export const PlanningWorkflow: React.FC<PlanningWorkflowProps> = ({ user, audits, setAudits, departments = [], costCenters = [], notify, showConfirmModal, logAction, historyLogs }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [loadingAISuggestion, setLoadingAISuggestion] = useState(false);
  const [selectedAudit, setSelectedAudit] = useState<Partial<Audit> | null>(null);
  
  // History Modal State
  const [historyItemId, setHistoryItemId] = useState<string | null>(null);

  // List Filters
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());

  // Form State for Date Selection
  const [formYear, setFormYear] = useState<number>(new Date().getFullYear());
  const [formPeriod, setFormPeriod] = useState<string>(new Date().getMonth().toString()); // '0'-'11' or 'recurring'

  const availableYears = useMemo(() => {
    const years = new Set<number>();
    
    // Add years from existing data
    audits.forEach(audit => years.add(new Date(audit.date).getFullYear()));
    
    // Add a wide range (Current Year - 5 to Current Year + 10)
    const currentYear = new Date().getFullYear();
    for (let i = currentYear - 5; i <= currentYear + 10; i++) {
        years.add(i);
    }

    return Array.from(years).sort((a, b) => b - a);
  }, [audits]);

  const filteredAudits = useMemo(() => {
    return audits.filter(audit => {
      const auditYear = new Date(audit.date).getFullYear();
      if (auditYear !== selectedYear) return false;

      const matchesSearch = 
        audit.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        audit.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
        audit.costCenter.toLowerCase().includes(searchTerm.toLowerCase());
      
      // Filter primarily for planning statuses, but show all for context if needed
      return matchesSearch;
    });
  }, [audits, searchTerm, selectedYear]);

  const handleOpenModal = (audit?: Audit) => {
    if (audit) {
      const d = new Date(audit.date);
      setSelectedAudit({ ...audit });
      setFormYear(d.getFullYear());
      setFormPeriod(audit.isRecurring ? 'recurring' : d.getMonth().toString());
    } else {
      setSelectedAudit({
        title: '',
        department: departments[0]?.name || '',
        costCenter: costCenters[0]?.code || '',
        status: AuditStatus.PLANNED,
        plannedBudget: 0,
        executedBudget: 0,
        initialQuote: 0,
        finalPrice: 0,
        negotiationStatus: 'PENDING',
        negotiationNotes: '',
        savingAmount: 0,
        isRecurring: false,
        complianceRating: 0,
        attachments: []
      });
      setFormYear(selectedYear); // Default to currently viewed year
      setFormPeriod(new Date().getMonth().toString());
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!selectedAudit?.title || !selectedAudit.department) {
      notify('Preencha os campos obrigatórios.', 'error');
      return;
    }

    // Construct Date
    let finalDate: string;
    let isRecurring = false;

    if (formPeriod === 'recurring') {
      isRecurring = true;
      finalDate = `${formYear}-01-01`; 
    } else {
      const monthIndex = parseInt(formPeriod);
      const monthStr = (monthIndex + 1).toString().padStart(2, '0');
      finalDate = `${formYear}-${monthStr}-15`;
    }

    const auditToSave: Audit = {
      ...selectedAudit as Audit,
      id: selectedAudit.id || Date.now().toString(),
      companyId: user.companyId, // Ensure companyId is set
      date: finalDate,
      isRecurring: isRecurring,
      // Ensure executed fields aren't wiped if they exist, but this is planning focused
      executedBudget: selectedAudit.executedBudget || 0,
      savingAmount: (selectedAudit.initialQuote || 0) - (selectedAudit.finalPrice || 0),
      lastModifiedBy: user.name,
      lastModifiedAt: new Date().toISOString()
    };

    if (selectedAudit.id) {
      setAudits(prev => prev.map(a => a.id === auditToSave.id ? auditToSave : a));
      logAction('UPDATE', `Planejamento: ${auditToSave.title}`, `Atualizou orçamento planejado para R$ ${auditToSave.plannedBudget}.`, auditToSave.id);
      notify('Planejamento atualizado com sucesso!', 'success');
    } else {
      setAudits(prev => [...prev, auditToSave]);
      logAction('CREATE', `Planejamento: ${auditToSave.title}`, `Criou novo item de planejamento: R$ ${auditToSave.plannedBudget}.`, auditToSave.id);
      notify('Item planejado com sucesso!', 'success');
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    const itemTitle = audits.find(a => a.id === id)?.title || 'Item';
    showConfirmModal('Tem certeza que deseja remover este item do planejamento?', () => {
      setAudits(prev => prev.filter(a => a.id !== id));
      logAction('DELETE', `Planejamento: ${itemTitle}`, 'Removeu item do planejamento.', id);
      notify('Item removido.', 'info');
    });
  };

  const generatePDF = () => {
    const doc = new jsPDF();
    doc.text(`Relatório de Planejamento Orçamentário - ${selectedYear}`, 14, 15);
    
    const tableColumn = ["Data", "Título", "Depto", "Status", "Planejado"];
    const tableRows = filteredAudits.map(audit => [
      audit.isRecurring ? 'Recorrente' : new Date(audit.date).toLocaleDateString('pt-BR'),
      audit.title,
      audit.department,
      audit.status,
      `R$ ${audit.plannedBudget.toLocaleString()}`,
    ]);

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 20,
    });

    doc.save(`planejamento_${selectedYear}.pdf`);
    notify('Relatório PDF gerado!', 'success');
  };

  const handleAISuggestion = async () => {
    if (!selectedAudit?.title) {
      notify('Preencha a descrição/título para receber sugestões.', 'info');
      return;
    }
    setLoadingAISuggestion(true);
    const suggestion = await suggestBudgetAndCategory(selectedAudit.title, departments, costCenters);
    
    if (suggestion) {
      setSelectedAudit(prev => ({
        ...prev,
        plannedBudget: suggestion.plannedBudget,
        department: suggestion.department,
        costCenter: suggestion.costCenter
      }));
      notify('Sugestão da IA aplicada!', 'success');
    } else {
      notify('Não foi possível gerar sugestão. Tente novamente.', 'error');
    }
    setLoadingAISuggestion(false);
  };

  return (
    <div className="space-y-6 animate-fade-in pb-10">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Planejamento Orçamentário</h2>
          <p className="text-slate-500">Defina o orçamento previsto para o ano, categorize despesas e preveja gastos.</p>
        </div>
        <div className="flex gap-2">
           <div className="bg-white border border-slate-300 rounded-lg flex items-center px-3 gap-2">
              <Calendar size={16} className="text-slate-400"/>
              <select 
                value={selectedYear} 
                onChange={(e) => setSelectedYear(Number(e.target.value))}
                className="bg-transparent outline-none text-sm text-slate-700 font-medium py-2"
              >
                 {availableYears.map(y => <option key={y} value={y}>{y}</option>)}
              </select>
           </div>
           <button 
            onClick={generatePDF}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-lg transition-colors flex items-center gap-2 font-medium"
           >
             <Download size={20} /> Baixar PDF
           </button>
           <button 
            onClick={() => handleOpenModal()} 
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow-lg shadow-blue-200 transition-all flex items-center gap-2 font-medium"
           >
            <Plus size={20} /> Novo Planejamento
           </button>
        </div>
      </header>

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex items-center gap-3">
        <Search className="text-slate-400" size={20} />
        <input 
          type="text" 
          placeholder="Buscar por título, departamento ou centro de custo..." 
          className="flex-1 outline-none text-slate-700 bg-white"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Cards List */}
      <div className="grid grid-cols-1 gap-4">
        {filteredAudits.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-dashed border-slate-300">
            <Box className="mx-auto text-slate-300 mb-3" size={48} />
            <p className="text-slate-500">Nenhum registro de planejamento para {selectedYear}.</p>
          </div>
        ) : (
          filteredAudits.map((audit) => (
            <div key={audit.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 hover:shadow-md transition-shadow relative group">
                {/* Actions */}
                <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => setHistoryItemId(audit.id)} className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-700 rounded-lg transition-colors" title="Ver Histórico">
                        <Info size={18} />
                    </button>
                    <button onClick={() => handleOpenModal(audit)} className="p-2 bg-slate-100 hover:bg-blue-50 text-slate-500 hover:text-blue-600 rounded-lg transition-colors">
                        <ArrowDown size={18} className="rotate-[-45deg]" />
                    </button>
                    <button onClick={() => handleDelete(audit.id)} className="p-2 bg-slate-100 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors">
                        <Trash2 size={18} />
                    </button>
                </div>

                <div className="flex flex-col md:flex-row gap-6">
                    <div className={`w-2 rounded-full self-stretch shrink-0 
                        ${audit.status === AuditStatus.PLANNED ? 'bg-blue-400' : 'bg-slate-300'}`} 
                    />

                    <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                             <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border bg-blue-50 text-blue-700 border-blue-100`}>
                                {audit.status}
                             </span>
                             {audit.isRecurring ? (
                               <span className="text-xs text-indigo-600 flex items-center gap-1 font-semibold bg-indigo-50 px-2 py-0.5 rounded">
                                 <Repeat size={12}/> Recorrente ({new Date(audit.date).getFullYear()})
                               </span>
                             ) : (
                               <span className="text-xs text-slate-400 flex items-center gap-1">
                                 <Calendar size={12}/> {new Date(audit.date).toLocaleDateString('pt-BR')}
                               </span>
                             )}
                        </div>
                        
                        <h3 className="text-lg font-bold text-slate-800 mb-1">{audit.title}</h3>
                        <div className="flex items-center gap-2 text-sm text-slate-500 mb-4">
                            <span className="bg-slate-100 px-2 py-0.5 rounded">{audit.department}</span>
                            <span>•</span>
                            <span className="font-mono text-xs bg-slate-100 px-2 py-0.5 rounded">{audit.costCenter}</span>
                        </div>

                        {/* Financials - Focus on Planned */}
                        <div className="flex items-center gap-6 bg-slate-50 p-3 rounded-lg border border-slate-100 w-fit">
                             <div>
                                 <span className="text-[10px] uppercase font-bold text-slate-400 block">Orçamento Planejado</span>
                                 <span className="text-lg font-bold text-blue-700">R$ {audit.plannedBudget.toLocaleString()}</span>
                             </div>
                             {audit.executedBudget > 0 && (
                                 <div className="opacity-60">
                                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Executado (Ref.)</span>
                                    <span className="text-sm font-semibold text-slate-600">R$ {audit.executedBudget.toLocaleString()}</span>
                                 </div>
                             )}
                        </div>
                        
                        {audit.lastModifiedBy && (
                           <div className="mt-3 flex items-center gap-1 text-[10px] text-slate-400">
                              <UserIcon size={10} />
                              <span>Editado por <b>{audit.lastModifiedBy}</b> em {new Date(audit.lastModifiedAt!).toLocaleDateString()}</span>
                           </div>
                        )}
                    </div>
                </div>
            </div>
          ))
        )}
      </div>

      {/* Item History Modal */}
      <ItemHistoryModal 
        isOpen={!!historyItemId}
        onClose={() => setHistoryItemId(null)}
        itemTitle={audits.find(a => a.id === historyItemId)?.title || 'Item'}
        logs={historyLogs.filter(log => log.itemId === historyItemId)}
      />

      {/* Modal */}
      {isModalOpen && selectedAudit && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto custom-scrollbar animate-scale-in">
                <div className="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-center sticky top-0 z-10">
                    <h3 className="text-xl font-bold text-slate-800">
                        {selectedAudit.id ? 'Editar Planejamento' : 'Novo Planejamento'}
                    </h3>
                    <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600"><Sparkles size={24} className="opacity-0 w-0" /> <span className="text-xl">×</span></button>
                </div>

                <div className="p-6 space-y-6">
                    <div className="space-y-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Título / Descrição</label>
                            <div className="flex gap-2">
                                <input 
                                    className="flex-1 border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500/50 bg-white text-slate-800"
                                    value={selectedAudit.title || ''}
                                    onChange={e => setSelectedAudit({...selectedAudit, title: e.target.value})}
                                    placeholder="Ex: Renovação Licenças Adobe"
                                />
                                <button 
                                    onClick={handleAISuggestion}
                                    disabled={loadingAISuggestion || !selectedAudit.title}
                                    className="bg-blue-50 text-blue-600 px-3 py-2 rounded-lg hover:bg-blue-100 transition-colors flex items-center gap-1 text-sm font-medium disabled:opacity-50"
                                >
                                    {loadingAISuggestion ? <Loader2 size={16} className="animate-spin"/> : <Sparkles size={16}/>}
                                    IA
                                </button>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Ano de Referência</label>
                                <select 
                                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800"
                                    value={formYear}
                                    onChange={e => setFormYear(Number(e.target.value))}
                                >
                                    {availableYears.map(y => <option key={y} value={y}>{y}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Período / Mês</label>
                                <select 
                                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800"
                                    value={formPeriod}
                                    onChange={e => setFormPeriod(e.target.value)}
                                >
                                    {MONTHS.map((m, i) => <option key={i} value={i}>{m}</option>)}
                                    <option value="recurring">Recorrente / Anual</option>
                                </select>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Departamento</label>
                                <select 
                                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800"
                                    value={selectedAudit.department}
                                    onChange={e => setSelectedAudit({...selectedAudit, department: e.target.value})}
                                >
                                    {departments.map(d => <option key={d.id} value={d.name}>{d.name}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Centro de Custo</label>
                                <select 
                                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800"
                                    value={selectedAudit.costCenter}
                                    onChange={e => setSelectedAudit({...selectedAudit, costCenter: e.target.value})}
                                >
                                    {costCenters.map(cc => <option key={cc.id} value={cc.code}>{cc.code} - {cc.name}</option>)}
                                </select>
                            </div>
                        </div>
                        
                         <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Status</label>
                            <select 
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800"
                                value={selectedAudit.status}
                                onChange={e => setSelectedAudit({...selectedAudit, status: e.target.value as AuditStatus})}
                            >
                                <option value={AuditStatus.PLANNED}>Planejado</option>
                                <option value={AuditStatus.IN_PROGRESS}>Em Andamento</option>
                                <option value={AuditStatus.NOT_EXECUTED}>Não Executado</option>
                                <option value={AuditStatus.CANCELLED}>Cancelado</option>
                            </select>
                        </div>
                    </div>

                    <div className="bg-blue-50 p-6 rounded-xl border border-blue-100 text-center">
                        <h4 className="font-bold text-blue-900 mb-4 flex items-center justify-center gap-2">
                            <DollarSign className="text-blue-600" size={20} /> Definição de Budget
                        </h4>
                        <div>
                           <label className="block text-xs font-bold text-blue-400 uppercase mb-1">Orçamento Planejado (Estimativa)</label>
                           <input 
                               type="number"
                               className="w-full border border-blue-200 rounded-lg px-4 py-3 outline-none focus:border-blue-500 text-center text-xl font-bold text-blue-800 bg-white"
                               value={selectedAudit.plannedBudget}
                               onChange={e => setSelectedAudit({...selectedAudit, plannedBudget: Number(e.target.value)})}
                               placeholder="0.00"
                           />
                        </div>
                    </div>

                </div>

                <div className="p-6 border-t border-slate-100 flex justify-end gap-3 sticky bottom-0 bg-white">
                    <button onClick={() => setIsModalOpen(false)} className="px-5 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors">
                        Cancelar
                    </button>
                    <button onClick={handleSave} className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow font-medium transition-colors">
                        Salvar Planejamento
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
