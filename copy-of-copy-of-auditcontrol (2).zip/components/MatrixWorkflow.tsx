
import React, { useState, useMemo } from 'react';
import { MatrixItem, User, MatrixStatus, CostCenter, NotifyFn, ActionType, HistoryLog } from '../types';
import { suggestMatrixItemValues } from '../services/geminiService'; // Import AI suggestion
import { Plus, Trash2, Box, DollarSign, TrendingDown, TrendingUp, AlertCircle, CheckCircle, PieChart, Target, Wallet, Calendar, Copy, Sparkles, Loader2, Repeat, Info } from 'lucide-react';
import { ItemHistoryModal } from './ItemHistoryModal';

interface MatrixWorkflowProps {
  user: User;
  matrixItems: MatrixItem[];
  setMatrixItems: (data: MatrixItem[] | ((prev: MatrixItem[]) => MatrixItem[])) => void;
  costCenters: CostCenter[];
  notify: NotifyFn;
  showConfirmModal: (message: string, onConfirm: () => void) => void;
  logAction: (action: ActionType, target: string, details: string, itemId?: string) => void; 
  historyLogs: HistoryLog[];
}

const MONTHS = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

export const MatrixWorkflow: React.FC<MatrixWorkflowProps> = ({ user, matrixItems, setMatrixItems, costCenters, notify, showConfirmModal, logAction, historyLogs }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth()); // 0-11
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loadingAISuggestion, setLoadingAISuggestion] = useState(false);
  
  // History Modal State
  const [historyItemId, setHistoryItemId] = useState<string | null>(null);

  // State for new item creation
  const [newItem, setNewItem] = useState<{desc: string, qty: number, unit: number, cc: string}>({
    desc: '', qty: 1, unit: 0, cc: ''
  });
  // State for Date Selection in Modal
  const [formYear, setFormYear] = useState<number>(new Date().getFullYear());
  const [formPeriod, setFormPeriod] = useState<string>('recurring'); // '0'-'11' or 'recurring'

  // Filter items by selected year
  const filteredItems = useMemo(() => {
    return matrixItems.filter(item => (item.year || new Date().getFullYear()) === selectedYear);
  }, [matrixItems, selectedYear]);

  // --- Statistics for the Current Month ---
  const monthStats = useMemo(() => {
    let totalPlanned = 0;
    let totalExecuted = 0;
    
    filteredItems.forEach(item => {
      const data = item.monthlyData[currentMonth];
      totalPlanned += data.planned;
      totalExecuted += data.executed;
    });

    return { totalPlanned, totalExecuted, diff: totalPlanned - totalExecuted };
  }, [filteredItems, currentMonth]);

  // --- Statistics for the Entire Year (Accumulated) ---
  const yearStats = useMemo(() => {
    let totalPlanned = 0;
    let totalExecuted = 0;

    filteredItems.forEach(item => {
      item.monthlyData.forEach(data => {
        totalPlanned += data.planned;
        totalExecuted += data.executed;
      });
    });

    return { 
        totalPlanned, 
        totalExecuted, 
        diff: totalPlanned - totalExecuted,
        percentageUsed: totalPlanned > 0 ? (totalExecuted / totalPlanned) * 100 : 0
    };
  }, [filteredItems]);

  const availableYears = useMemo(() => {
      const years = new Set<number>();
      // Add years from data
      matrixItems.forEach(i => years.add(i.year || new Date().getFullYear()));
      
      // Add a wide range (Current Year - 5 to Current Year + 10)
      const currentYear = new Date().getFullYear();
      for (let i = currentYear - 5; i <= currentYear + 10; i++) {
        years.add(i);
      }

      return Array.from(years).sort((a, b) => b - a);
  }, [matrixItems]);

  // --- Handlers ---

  const handleAddItem = () => {
    if (!newItem.desc.trim() || !newItem.cc) {
      notify('Descrição e Centro de Custo são obrigatórios.', 'error');
      return;
    }

    const monthlyTotal = newItem.qty * newItem.unit;
    const isRecurring = formPeriod === 'recurring';
    
    // Create 12 months of data
    // If recurring, fill all months. If specific month, fill only that index.
    const initialMonthlyData = Array.from({ length: 12 }, (_, i) => ({
      month: i,
      planned: (isRecurring || i === parseInt(formPeriod)) ? monthlyTotal : 0, 
      executed: 0
    }));

    const item: MatrixItem = {
      id: `mx${Date.now()}`,
      companyId: user.companyId, // Ensure companyId is set
      description: newItem.desc.trim(),
      quantity: newItem.qty,
      unitValue: newItem.unit,
      category: newItem.cc,
      year: formYear, // Use the year selected in modal
      isRecurring: isRecurring,
      monthlyData: initialMonthlyData,
      status: 'PENDING',
      lastModifiedBy: user.name,
      lastModifiedAt: new Date().toISOString()
    };

    setMatrixItems(prev => [...prev, item]);
    setNewItem({ desc: '', qty: 1, unit: 0, cc: '' });
    setIsModalOpen(false);
    logAction('CREATE', `Pacote Matricial: ${item.description}`, `Criou novo pacote para ${isRecurring ? 'o ano todo' : MONTHS[parseInt(formPeriod)]} de ${formYear}.`, item.id);
    notify('Pacote matricial criado com sucesso!', 'success');
  };

  const handleDeleteItem = (id: string) => {
    const itemDesc = matrixItems.find(i => i.id === id)?.description || 'Desconhecido';
    console.log(`[MatrixWorkflow] Attempting to delete matrix item with ID: ${id}`);
    showConfirmModal('Tem certeza que deseja excluir este pacote matricial? Todos os dados de todos os meses serão perdidos.', () => {
      console.log(`[MatrixWorkflow] User confirmed deletion for item ID: ${id}`);
      setMatrixItems(prev => prev.filter(i => i.id !== id));
      
      logAction('DELETE', `Pacote Matricial: ${itemDesc}`, 'Pacote e dados mensais removidos.', id);
      notify('Pacote removido com sucesso.', 'info');
    });
  };

  const handleUpdateValue = (itemId: string, field: 'planned' | 'executed', value: string) => {
    const numValue = parseFloat(value) || 0;
    setMatrixItems(prev => prev.map(item => {
      if (item.id !== itemId) return item;
      const newData = [...item.monthlyData];
      newData[currentMonth] = { ...newData[currentMonth], [field]: numValue };
      return { 
          ...item, 
          monthlyData: newData,
          lastModifiedBy: user.name,
          lastModifiedAt: new Date().toISOString()
      };
    }));
  };

  const handleReplicatePlanned = (itemId: string) => {
    const itemDesc = matrixItems.find(i => i.id === itemId)?.description;
    setMatrixItems(prev => prev.map(item => {
      if (item.id !== itemId) return item;
      const currentMonthPlanned = item.monthlyData[currentMonth].planned;
      const updatedMonthlyData = item.monthlyData.map(data => ({
        ...data,
        planned: currentMonthPlanned // Set all months to the current month's planned value
      }));
      notify('Valor planejado replicado para todos os meses!', 'info');
      return { 
          ...item, 
          monthlyData: updatedMonthlyData,
          isRecurring: true, // If we replicate, it effectively becomes recurring
          lastModifiedBy: user.name,
          lastModifiedAt: new Date().toISOString()
      };
    }));
    logAction('UPDATE', `Pacote Matricial: ${itemDesc}`, `Replicou valor planejado do mês ${MONTHS[currentMonth]} para o ano todo.`, itemId);
  };

  const handleAISuggestion = async () => {
    if (!newItem.desc.trim()) {
      notify('Por favor, insira uma descrição para a sugestão da IA.', 'info');
      return;
    }
    setLoadingAISuggestion(true);
    const suggestion = await suggestMatrixItemValues(newItem.desc, costCenters);
    if (suggestion) {
      setNewItem(prev => ({
        ...prev,
        quantity: suggestion.quantity,
        unitValue: suggestion.unitValue,
        cc: suggestion.category,
      }));
      notify('Sugestão da IA aplicada!', 'success');
    } else {
      notify('Não foi possível gerar sugestão. Tente novamente.', 'error');
    }
    setLoadingAISuggestion(false);
  };


  const handleStatusChange = (itemId: string, status: MatrixStatus) => {
    const itemDesc = matrixItems.find(i => i.id === itemId)?.description;
    setMatrixItems(prev => prev.map(item => 
      item.id === itemId ? { 
          ...item, 
          status,
          lastModifiedBy: user.name,
          lastModifiedAt: new Date().toISOString() 
      } : item
    ));
    if (status === 'APPROVED') {
        notify('Pacote aprovado!', 'success');
        logAction('APPROVE', `Pacote Matricial: ${itemDesc}`, 'Aprovou pacote matricial.', itemId);
    }
    if (status === 'REJECTED') {
        notify('Pacote reprovado.', 'error');
        logAction('REJECT', `Pacote Matricial: ${itemDesc}`, 'Reprovou pacote matricial.', itemId);
    }
  };

  const openNewItemModal = () => {
      setIsModalOpen(true);
      setNewItem({ desc: '', qty: 1, unit: 0, cc: costCenters[0]?.code || '' });
      setFormYear(selectedYear); // Default to current view year
      setFormPeriod('recurring'); // Default to recurring
  };

  return (
    <div className="space-y-6 animate-fade-in pb-20">
      {/* Header & Year/Month Selector */}
      <div className="flex flex-col gap-6">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Orçamento Matricial</h2>
            <p className="text-slate-500">Gestão detalhada de pacotes e despesas mensais.</p>
          </div>
          <div className="flex gap-2">
            <div className="bg-white border border-slate-300 rounded-lg flex items-center px-3 gap-2">
               <Calendar size={16} className="text-slate-400"/>
               <select 
                  value={selectedYear} 
                  onChange={(e) => setSelectedYear(Number(e.target.value))}
                  className="bg-transparent outline-none text-sm text-slate-700 font-medium py-2"
               >
                   {availableYears.map(y => <option key={y} value={y}>{y}</option>)}
               </select>
            </div>
            <button 
                onClick={openNewItemModal}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg shadow-lg shadow-indigo-200 transition-all flex items-center gap-2 font-medium"
            >
                <Plus size={20} /> Novo Pacote
            </button>
          </div>
        </div>

        {/* Month Navigation Tabs */}
        <div className="bg-white p-1 rounded-xl shadow-sm border border-slate-200 flex overflow-x-auto custom-scrollbar">
          {MONTHS.map((month, index) => (
            <button
              key={month}
              onClick={() => setCurrentMonth(index)}
              className={`flex-1 min-w-[100px] py-3 text-sm font-medium rounded-lg transition-all whitespace-nowrap relative
                ${currentMonth === index 
                  ? 'bg-indigo-50 text-indigo-700 shadow-sm ring-1 ring-indigo-200' 
                  : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'
                }`}
            >
              {month}
              {/* Small dot indicator if there is data */}
              {filteredItems.some(i => i.monthlyData[index].executed > 0) && (
                  <span className="absolute top-2 right-2 w-1.5 h-1.5 bg-emerald-400 rounded-full"></span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* --- MAIN DASHBOARD SECTION --- */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left: Monthly Context (Selected Month) */}
          <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-3 text-xs font-bold text-slate-400 uppercase tracking-wider mb-[-10px] flex items-center gap-2">
                <Calendar size={14}/> Visão Mensal: {MONTHS[currentMonth]}
            </div>
            
            {/* Metric Card: PLANEJADO */}
            <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm flex items-center gap-4 hover:shadow-md transition-all relative overflow-hidden group">
                <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-sm relative z-10">
                    <Target size={24} />
                </div>
                <div className="relative z-10">
                    <p className="text-sm font-medium text-slate-500 uppercase">Planejado</p>
                    <h3 className="text-2xl font-bold text-blue-600">
                        {monthStats.totalPlanned.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })}
                    </h3>
                </div>
                {/* Decorative BG Circle */}
                <div className="absolute -right-4 -bottom-4 w-24 h-24 rounded-full opacity-5 bg-gradient-to-br from-blue-500 to-blue-600 pointer-events-none group-hover:scale-110 transition-transform"></div>
            </div>

            {/* Metric Card: REALIZADO */}
            <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm flex items-center gap-4 hover:shadow-md transition-all relative overflow-hidden group">
                <div className="p-3 rounded-xl bg-gradient-to-br from-slate-600 to-slate-700 text-white shadow-sm relative z-10">
                    <Wallet size={24} />
                </div>
                <div className="relative z-10">
                    <p className="text-sm font-medium text-slate-500 uppercase">Realizado</p>
                    <h3 className="text-2xl font-bold text-slate-700">
                        {monthStats.totalExecuted.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })}
                    </h3>
                </div>
                {/* Decorative BG Circle */}
                <div className="absolute -right-4 -bottom-4 w-24 h-24 rounded-full opacity-5 bg-gradient-to-br from-slate-600 to-slate-700 pointer-events-none group-hover:scale-110 transition-transform"></div>
            </div>

            {/* Metric Card: SALDO */}
            <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm flex items-center gap-4 hover:shadow-md transition-all relative overflow-hidden group">
                <div className={`p-3 rounded-xl bg-gradient-to-br text-white shadow-sm relative z-10 ${monthStats.diff < 0 ? 'from-red-500 to-red-600' : 'from-emerald-500 to-emerald-600'}`}>
                    {monthStats.diff < 0 ? <TrendingDown size={24}/> : <TrendingUp size={24}/>}
                </div>
                <div className="relative z-10">
                    <p className={`text-sm font-medium uppercase ${monthStats.diff < 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                        Saldo do Mês
                    </p>
                    <h3 className={`text-2xl font-bold ${monthStats.diff < 0 ? 'text-red-700' : 'text-emerald-700'}`}>
                        {Math.abs(monthStats.diff).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })}
                    </h3>
                </div>
                {/* Decorative BG Circle */}
                <div className={`absolute -right-4 -bottom-4 w-24 h-24 rounded-full opacity-5 bg-gradient-to-br pointer-events-none group-hover:scale-110 transition-transform ${monthStats.diff < 0 ? 'from-red-500 to-red-600' : 'from-emerald-500 to-emerald-600'}`}></div>
            </div>
          </div>

          {/* Right: Annual Context (Accumulated) */}
          <div className="lg:col-span-5 bg-slate-900 text-white rounded-xl p-6 shadow-lg relative overflow-hidden">
             <div className="absolute top-0 right-0 p-6 opacity-10">
                 <PieChart size={120} className="text-white" />
             </div>
             
             <div className="relative z-10">
                <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2 mb-4">
                    <Box size={16}/> Resultado Acumulado ({selectedYear})
                </h3>

                <div className="grid grid-cols-2 gap-6 mb-6">
                    <div>
                        <span className="text-xs text-slate-400 block mb-1">Total Planejado</span>
                        <span className="text-lg font-semibold text-white">
                            {yearStats.totalPlanned.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })}
                        </span>
                    </div>
                    <div>
                        <span className="text-xs text-slate-400 block mb-1">Total Executado</span>
                        <span className="text-lg font-semibold text-white">
                            {yearStats.totalExecuted.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })}
                        </span>
                    </div>
                </div>

                <div className="mb-2">
                    <div className="flex justify-between items-end mb-1">
                        <span className="text-xs font-bold text-emerald-400 uppercase">Sobra Total / Saving</span>
                        <span className={`text-2xl font-bold ${yearStats.diff >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                             {yearStats.diff >= 0 ? '+' : ''} {yearStats.diff.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })}
                        </span>
                    </div>
                    {/* Progress Bar */}
                    <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
                        <div 
                            className={`h-full rounded-full transition-all duration-500 ${yearStats.percentageUsed > 100 ? 'bg-red-500' : 'bg-emerald-500'}`}
                            style={{ width: `${Math.min(yearStats.percentageUsed, 100)}%` }}
                        ></div>
                    </div>
                    <div className="flex justify-between mt-1 text-[10px] text-slate-500">
                        <span>0%</span>
                        <span>{yearStats.percentageUsed.toFixed(1)}% do orçamento consumido</span>
                    </div>
                </div>
             </div>
          </div>
      </div>

      {/* List of Items for Selected Month */}
      <div className="space-y-4 mt-8">
        <div className="flex items-center justify-between px-2">
             <h3 className="font-bold text-slate-700">Detalhamento de Pacotes - {MONTHS[currentMonth]} {selectedYear}</h3>
             <span className="text-xs text-slate-500 bg-slate-100 px-2 py-1 rounded-full">{filteredItems.length} itens ativos</span>
        </div>

        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-xl border border-dashed border-slate-300">
            <Box className="mx-auto text-slate-300 mb-3" size={48} />
            <p className="text-slate-500">Nenhum pacote cadastrado para {selectedYear}. Comece criando um novo pacote.</p>
          </div>
        ) : (
            <div className="grid grid-cols-1 gap-4">
                {filteredItems.map(item => {
                    const currentData = item.monthlyData[currentMonth];
                    const diff = currentData.planned - currentData.executed;
                    
                    // Calculate Annual for this specific item
                    const itemAnnualPlanned = item.monthlyData.reduce((acc, cur) => acc + cur.planned, 0);
                    const itemAnnualExecuted = item.monthlyData.reduce((acc, cur) => acc + cur.executed, 0);
                    const itemAnnualDiff = itemAnnualPlanned - itemAnnualExecuted;

                    return (
                        <div key={item.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 hover:shadow-md transition-shadow relative group">
                            {/* Actions Button - Top Right */}
                            <div className="absolute top-4 right-4 flex gap-2">
                                <button onClick={() => setHistoryItemId(item.id)} className="text-slate-300 hover:text-slate-600 hover:bg-slate-100 p-2 rounded-full transition-colors" title="Ver Histórico">
                                    <Info size={18} />
                                </button>
                                <button 
                                    onClick={() => handleDeleteItem(item.id)}
                                    className="text-slate-300 hover:text-red-500 hover:bg-red-50 p-2 rounded-full transition-colors"
                                    title="Excluir este pacote"
                                >
                                    <Trash2 size={18} />
                                </button>
                            </div>

                            <div className="flex flex-col lg:flex-row gap-6 items-start">
                                
                                {/* Info Column */}
                                <div className="flex-1 border-r border-slate-100 pr-6 mr-2">
                                    <div className="flex items-center gap-2 mb-2">
                                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider">{item.category}</span>
                                        {item.status === 'APPROVED' && <span className="text-[10px] font-bold text-emerald-600 flex items-center gap-1 border border-emerald-100 px-2 py-0.5 rounded bg-emerald-50"><CheckCircle size={10}/> Aprovado</span>}
                                        {item.status === 'REJECTED' && <span className="text-[10px] font-bold text-red-600 flex items-center gap-1 border border-red-100 px-2 py-0.5 rounded bg-red-50"><AlertCircle size={10}/> Reprovado</span>}
                                        {item.isRecurring && (
                                            <span className="text-[10px] font-bold text-indigo-600 flex items-center gap-1 border border-indigo-100 px-2 py-0.5 rounded bg-indigo-50" title="Verba recorrente">
                                                <Repeat size={10}/> Recorrente
                                            </span>
                                        )}
                                    </div>
                                    <h3 className="text-lg font-bold text-slate-800 pr-8">{item.description}</h3>
                                    <div className="flex items-center gap-4 mt-2">
                                         <p className="text-xs text-slate-400">
                                            Base: {item.quantity} un. x R$ {item.unitValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                        </p>
                                    </div>

                                    {/* Item Annual Summary Mini-Card */}
                                    <div className="mt-4 p-3 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-between">
                                        <div>
                                            <span className="text-[10px] text-slate-400 uppercase font-bold">Acumulado {selectedYear}</span>
                                            <div className="text-sm font-semibold text-slate-600">R$ {itemAnnualExecuted.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} <span className="text-slate-400 font-normal">/ {itemAnnualPlanned.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span></div>
                                        </div>
                                        <div className="text-right">
                                             <span className="text-[10px] text-slate-400 uppercase font-bold">Sobra Item</span>
                                             <div className={`text-sm font-bold ${itemAnnualDiff >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                                                {itemAnnualDiff >= 0 ? '+' : ''} R$ {itemAnnualDiff.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                             </div>
                                        </div>
                                    </div>

                                    {user.role === 'ADMIN' && (
                                        <div className="flex items-center gap-2 mt-4">
                                            <button onClick={() => handleStatusChange(item.id, 'APPROVED')} className="text-xs text-emerald-600 hover:bg-emerald-50 px-2 py-1 rounded transition-colors font-medium">
                                                Aprovar
                                            </button>
                                            <button onClick={() => handleStatusChange(item.id, 'REJECTED')} className="text-xs text-red-600 hover:bg-red-50 px-2 py-1 rounded transition-colors font-medium">
                                                Reprovar
                                            </button>
                                        </div>
                                    )}
                                </div>

                                {/* Inputs Column - Monthly Focus */}
                                <div className="flex flex-col w-full lg:w-auto gap-4">
                                    <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase mb-1">
                                        <Calendar size={12} /> Edição Mensal ({MONTHS[currentMonth]})
                                    </div>
                                    <div className="flex gap-4 items-end">
                                        {/* Planned Input */}
                                        <div className="flex-1 lg:w-40">
                                            <label className="block text-[10px] font-bold text-blue-600 mb-1 uppercase">Planejado</label>
                                            <div className="relative">
                                                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs">R$</span>
                                                <input 
                                                    type="number"
                                                    disabled={user.role === 'EXECUTOR' && item.status === 'APPROVED'}
                                                    className="w-full pl-7 pr-3 py-2 bg-white border border-blue-200 rounded-lg text-slate-700 font-semibold text-sm focus:ring-2 focus:ring-blue-500/50 outline-none transition-all"
                                                    value={currentData.planned || 0}
                                                    onChange={(e) => handleUpdateValue(item.id, 'planned', e.target.value)}
                                                />
                                                <button 
                                                  onClick={() => handleReplicatePlanned(item.id)}
                                                  className="absolute right-1 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-blue-600 rounded-full hover:bg-blue-50 transition-colors"
                                                  title="Replicar para o Ano Todo"
                                                >
                                                  <Copy size={14} />
                                                </button>
                                            </div>
                                        </div>

                                        {/* Executed Input */}
                                        <div className="flex-1 lg:w-40">
                                            <label className="block text-[10px] font-bold text-emerald-600 mb-1 uppercase">Realizado</label>
                                            <div className="relative">
                                                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs">R$</span>
                                                <input 
                                                    type="number"
                                                    disabled={user.role === 'PLANNER'}
                                                    className="w-full pl-7 pr-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-700 font-semibold text-sm focus:ring-2 focus:ring-emerald-500/50 outline-none focus:border-emerald-500 transition-all"
                                                    value={currentData.executed || 0}
                                                    onChange={(e) => handleUpdateValue(item.id, 'executed', e.target.value)}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                    
                                    {/* Monthly Result Badge */}
                                    <div className={`mt-2 p-2 rounded-lg flex justify-between items-center border
                                        ${diff < 0 ? 'bg-red-50 border-red-100 text-red-700' : 'bg-emerald-50 border-emerald-100 text-emerald-700'}`}>
                                        <span className="text-[10px] font-bold uppercase">Saldo Mês</span>
                                        <span className="text-sm font-bold">{diff < 0 ? '-' : '+'} {Math.abs(diff).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        )}
      </div>

      {/* Item History Modal */}
      <ItemHistoryModal 
        isOpen={!!historyItemId}
        onClose={() => setHistoryItemId(null)}
        itemTitle={matrixItems.find(i => i.id === historyItemId)?.description || 'Pacote Matricial'}
        logs={historyLogs.filter(log => log.itemId === historyItemId)}
      />

      {/* Modal de Cadastro */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-scale-in">
                <div className="bg-indigo-600 p-6">
                    <h3 className="text-xl font-bold text-white flex items-center gap-2">
                        <Box className="text-indigo-200" />
                        Novo Pacote Matricial ({formYear})
                    </h3>
                    <p className="text-indigo-100 text-sm mt-1">Defina o item e a base de cálculo inicial.</p>
                </div>
                
                <div className="p-6 space-y-5">
                    {/* Time Selection */}
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Ano de Referência</label>
                            <select 
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800"
                                value={formYear}
                                onChange={e => setFormYear(Number(e.target.value))}
                            >
                                {availableYears.map(y => <option key={y} value={y}>{y}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Período / Mês</label>
                            <select 
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white text-slate-800"
                                value={formPeriod}
                                onChange={e => setFormPeriod(e.target.value)}
                            >
                                {MONTHS.map((m, i) => <option key={i} value={i}>{m}</option>)}
                                <option value="recurring">Recorrente / Anual</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Descrição do Item</label>
                        <input 
                            className="w-full border border-slate-300 rounded-lg px-4 py-3 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all bg-white"
                            placeholder="Ex: Material de Limpeza, Licenças de Software..."
                            autoFocus
                            value={newItem.desc}
                            onChange={e => setNewItem({...newItem, desc: e.target.value})}
                        />
                    </div>

                    <div>
                         <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Centro de Custo</label>
                         <select 
                            className="w-full border border-slate-300 rounded-lg px-4 py-3 outline-none bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                            value={newItem.cc}
                            onChange={e => setNewItem({...newItem, cc: e.target.value})}
                         >
                           <option value="">Selecione o centro de custo...</option>
                           {costCenters.map(cc => <option key={cc.id} value={cc.code}>{cc.code} - {cc.name}</option>)}
                         </select>
                    </div>

                    <div className="grid grid-cols-2 gap-5">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Qtd Estimada</label>
                            <input 
                                type="number"
                                className="w-full border border-slate-300 rounded-lg px-4 py-3 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all bg-white"
                                value={newItem.qty}
                                onChange={e => setNewItem({...newItem, qty: Number(e.target.value)})}
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Valor Unit. (R$)</label>
                            <input 
                                type="number"
                                className="w-full border border-slate-300 rounded-lg px-4 py-3 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all bg-white"
                                value={newItem.unit}
                                onChange={e => setNewItem({...newItem, unit: Number(e.target.value)})}
                            />
                        </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 text-center relative">
                        <span className="text-xs text-blue-600 uppercase font-bold">Total Planejado (Base Mensal)</span>
                        <div className="text-2xl font-bold text-blue-700 mt-1">
                            {(newItem.qty * newItem.unit).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })}
                        </div>
                        <p className="text-xs text-blue-400 mt-2">
                            {formPeriod === 'recurring' 
                                ? 'Este valor será aplicado a TODOS os meses do ano selecionado.' 
                                : `Este valor será aplicado APENAS em ${MONTHS[parseInt(formPeriod)]}.`}
                        </p>
                        <button 
                            type="button" 
                            onClick={handleAISuggestion} 
                            disabled={loadingAISuggestion || !newItem.desc.trim()}
                            className="absolute top-2 right-2 flex items-center gap-1 text-blue-600 hover:text-blue-800 text-xs font-medium transition-colors disabled:opacity-50"
                        >
                            {loadingAISuggestion ? <Loader2 size={14} className="animate-spin"/> : <Sparkles size={14}/>}
                            {loadingAISuggestion ? 'Gerando...' : 'Sugestão da IA'}
                        </button>
                    </div>
                </div>

                <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
                    <button 
                        onClick={() => setIsModalOpen(false)}
                        className="px-5 py-2.5 text-slate-600 hover:bg-slate-200 rounded-lg font-medium transition-colors"
                    >
                        Cancelar
                    </button>
                    <button 
                        onClick={handleAddItem}
                        disabled={!newItem.desc.trim() || !newItem.cc || loadingAISuggestion}
                        className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-lg shadow-indigo-200 font-medium transition-all disabled:opacity-50 disabled:shadow-none"
                    >
                        Criar Pacote
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
