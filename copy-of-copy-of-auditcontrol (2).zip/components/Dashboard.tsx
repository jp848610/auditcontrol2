import React, { useMemo, useState } from 'react';
import { Audit, InsightResponse, AuditStatus, User, HistoryLog, ViewState } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  Cell, PieChart, Pie, Legend, LineChart, Line
} from 'recharts';
import { DollarSign, TrendingUp, AlertCircle, Sparkles, Calendar, PieChart as PieIcon, Handshake, Loader2, Lock, Clock, CheckCircle, Edit, Plus, Trash2, XCircle } from 'lucide-react';
import { analyzeAudits } from '../services/geminiService';
import { notify } from './Toast'; 


interface DashboardProps {
  audits: Audit[];
  isLoadingApp: boolean; 
  user: User;
  historyLogs: HistoryLog[]; 
  onNavigate: (view: ViewState) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ audits, isLoadingApp, user, historyLogs, onNavigate }) => {
  const [insight, setInsight] = useState<InsightResponse | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  const availableYears = useMemo(() => {
    const years = new Set<number>();
    audits.forEach(audit => years.add(new Date(audit.date).getFullYear()));
    const currentYear = new Date().getFullYear();
    if (!years.has(currentYear)) years.add(currentYear); // Always include current year even if no data yet
    return Array.from(years).sort((a, b) => b - a);
  }, [audits]);

  const filteredAuditsByYear = useMemo(() => {
    return audits.filter(audit => new Date(audit.date).getFullYear() === selectedYear);
  }, [audits, selectedYear]);


  const metrics = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const totalPlanned = filteredAuditsByYear.reduce((acc, curr) => acc + curr.plannedBudget, 0);
    const totalExecuted = filteredAuditsByYear.reduce((acc, curr) => acc + curr.executedBudget, 0);
    const totalSaving = filteredAuditsByYear.reduce((acc, curr) => acc + curr.savingAmount, 0); 
    
    // Negotiation Metrics (Current Month & Year)
    const monthlyNegotiations = audits.filter(a => { 
      const d = new Date(a.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });

    const negotiationsCount = monthlyNegotiations.filter(a => a.negotiationStatus !== 'PENDING' && a.finalPrice > 0).length;
    
    const negotiationsSavings = monthlyNegotiations.reduce((acc, curr) => {
        if (curr.negotiationStatus === 'APPROVED' && curr.initialQuote > 0 && curr.finalPrice > 0) {
            return acc + (curr.initialQuote - curr.finalPrice);
        }
        return acc;
    }, 0);

    return { totalPlanned, totalExecuted, totalSaving, negotiationsCount, negotiationsSavings };
  }, [audits, filteredAuditsByYear]);

  // Prepare Data for Monthly Evolution Line Chart
  const monthlyData = useMemo(() => {
    const data: Record<string, { name: string; Planejado: number; Executado: number }> = {};
    
    // Sort audits by date first
    const sortedAudits = [...filteredAuditsByYear].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    sortedAudits.forEach(audit => {
      const date = new Date(audit.date);
      const key = `${date.getMonth() + 1}/${date.getFullYear()}`; // e.g., 10/2023
      
      if (!data[key]) {
        data[key] = { name: key, Planejado: 0, Executado: 0 };
      }
      data[key].Planejado += audit.plannedBudget;
      data[key].Executado += audit.executedBudget;
    });

    return Object.values(data);
  }, [filteredAuditsByYear]);

  // Prepare Data for Department Allocation (Rateio)
  const departmentData = useMemo(() => {
    const data: Record<string, number> = {};
    filteredAuditsByYear.forEach(audit => {
      if (!data[audit.department]) data[audit.department] = 0;
      data[audit.department] += audit.executedBudget;
    });
    return Object.keys(data).map(key => ({ name: key, value: data[key] }));
  }, [filteredAuditsByYear]);

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

  const handleGenerateInsight = async () => {
    setLoadingInsight(true);
    setInsight(null); // Clear previous insight
    try {
      const result = await analyzeAudits(filteredAuditsByYear); 
      if (result) {
        setInsight(result);
        notify('Análise com IA gerada com sucesso!', 'success');
      } else {
        notify('Falha ao gerar análise com IA. Tente novamente.', 'error');
      }
    } catch (error) {
      console.error("Error generating insight:", error);
      notify('Ocorreu um erro ao gerar a análise com IA.', 'error');
    } finally {
      setLoadingInsight(false);
    }
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'CREATE': return <Plus size={14} className="text-emerald-500" />;
      case 'UPDATE': return <Edit size={14} className="text-blue-500" />;
      case 'DELETE': return <Trash2 size={14} className="text-red-500" />;
      case 'APPROVE': return <CheckCircle size={14} className="text-purple-500" />;
      case 'REJECT': return <XCircle size={14} className="text-orange-500" />;
      default: return <Clock size={14} className="text-slate-400" />;
    }
  };

  const recentActivity = useMemo(() => {
      return historyLogs
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        .slice(0, 5);
  }, [historyLogs]);

  // Helper for formatting currency with cents
  const formatCurrency = (value: number) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  // If app is loading, show skeleton loaders
  if (isLoadingApp) {
    return (
      <div className="space-y-6 animate-fade-in pb-10">
        <div className="h-10 bg-slate-200 rounded-lg w-3/4 animate-pulse"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Array(4).fill(0).map((_, i) => (
            <div key={i} className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center gap-4 h-28 animate-pulse">
              <div className="p-3 rounded-lg bg-slate-200 h-10 w-10"></div>
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-slate-200 rounded w-2/3"></div>
                <div className="h-6 bg-slate-200 rounded w-full"></div>
              </div>
            </div>
          ))}
        </div>
        <div className="h-48 bg-slate-100 rounded-xl shadow-sm animate-pulse"></div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="h-80 bg-slate-100 rounded-xl shadow-sm animate-pulse"></div>
          <div className="h-80 bg-slate-100 rounded-xl shadow-sm animate-pulse"></div>
        </div>
      </div>
    );
  }

  // Restrict content for DEMO user
  if (user.role === 'DEMO') {
    return (
      <div className="flex flex-col items-center justify-center h-[calc(100vh-150px)] text-slate-500 animate-fade-in p-4">
        <Lock size={64} className="text-slate-300 mb-6" />
        <h2 className="text-3xl font-bold text-slate-700 mb-2">Acesso Restrito</h2>
        <p className="text-center text-lg max-w-md">
          Os dados de Auditoria e KPIs não estão disponíveis para o perfil <span className="font-semibold text-indigo-600">Demo</span>.
          Faça login com um perfil completo para acessar todas as informações.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in pb-10">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Visão Geral e KPIs</h2>
          <p className="text-slate-500">Indicadores de performance, evolução mensal e rateio por centro de custo.</p>
        </div>
        <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-slate-200">
                <Calendar size={18} className="text-slate-400" />
                <select
                    value={selectedYear}
                    onChange={(e) => setSelectedYear(Number(e.target.value))}
                    className="bg-transparent outline-none text-sm font-medium text-slate-700"
                >
                    {availableYears.map(year => (
                        <option key={year} value={year}>{year}</option>
                    ))}
                </select>
            </div>
            <button
            onClick={handleGenerateInsight}
            disabled={loadingInsight || filteredAuditsByYear.length === 0} 
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg shadow transition-all disabled:opacity-50"
            >
            {loadingInsight ? <Loader2 size={18} className="animate-spin"/> : <Sparkles size={18} />}
            {loadingInsight ? 'Analisando...' : 'Gerar Análise com IA'}
            </button>
        </div>
      </header>

      {/* Insight Card (still rendered if data exists, but won't be generated) */}
      {insight && (
        <div className="bg-gradient-to-r from-indigo-50 to-blue-50 p-6 rounded-xl border border-indigo-100 shadow-sm">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-indigo-100 rounded-full text-indigo-600">
              <Sparkles size={24} />
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-indigo-900 text-lg">Insight do Auditor Virtual</h3>
              <p className="text-slate-700 leading-relaxed">{insight.summary}</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="bg-white p-4 rounded-lg border border-indigo-100">
                  <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">Melhor Saving</span>
                  <p className="text-slate-800 mt-1 text-sm">{insight.topSaving}</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-indigo-100">
                  <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">Recomendação</span>
                  <p className="text-slate-800 mt-1 text-sm">{insight.recommendation}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Metrics Grid - Clickable & Better Visuals */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard 
          title="Negociações (Mês Atual)" 
          value={metrics.negotiationsCount.toString()} 
          icon={Handshake} 
          iconBg="from-indigo-500 to-indigo-600"
          textColor="text-indigo-600"
          onClick={() => onNavigate('NEGOTIATIONS')}
        />
         <MetricCard 
          title="Economia Gerada (Mês Atual)" 
          value={formatCurrency(metrics.negotiationsSavings)} 
          icon={TrendingUp} 
          iconBg="from-emerald-500 to-emerald-600"
          textColor="text-emerald-600"
          onClick={() => onNavigate('NEGOTIATIONS')}
        />
        <MetricCard 
          title="Total Planejado (Geral)" 
          value={formatCurrency(metrics.totalPlanned)} 
          icon={DollarSign} 
          iconBg="from-blue-500 to-blue-600"
          textColor="text-blue-600"
          onClick={() => onNavigate('PLANNING')}
        />
        <MetricCard 
          title="Total Executado (Geral)" 
          value={formatCurrency(metrics.totalExecuted)} 
          icon={DollarSign} 
          iconBg="from-slate-600 to-slate-700"
          textColor="text-slate-600"
          onClick={() => onNavigate('PLANNING')}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Charts - Taking up 2/3 */}
        <div className="lg:col-span-2 space-y-6">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col h-80 min-w-0 min-w-0">
                <div className="flex items-center gap-2 mb-4">
                    <Calendar className="text-slate-400" size={20} />
                    <h3 className="font-semibold text-slate-700">Evolução Mensal (Planejado vs Real)</h3>
                </div>
                <div className="flex-1 w-full min-w-0">
                    <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={monthlyData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis dataKey="name" tick={{fontSize: 12}} />
                        <YAxis tickFormatter={(val) => `R$${val/1000}k`} tick={{fontSize: 12}} />
                        <Tooltip 
                        formatter={(value: number) => [formatCurrency(value), '']}
                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                        />
                        <Legend />
                        <Line type="monotone" dataKey="Planejado" stroke="#94a3b8" strokeWidth={2} dot={{r: 4}} activeDot={{r: 6}} />
                        <Line type="monotone" dataKey="Executado" stroke="#10b981" strokeWidth={2} dot={{r: 4}} activeDot={{r: 6}} />
                    </LineChart>
                    </ResponsiveContainer>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col h-80 min-w-0">
                <div className="flex items-center gap-2 mb-4">
                    <PieIcon className="text-slate-400" size={20} />
                    <h3 className="font-semibold text-slate-700">Rateio por Departamento (Executado)</h3>
                </div>
                <div className="flex-1 w-full min-w-0">
                    <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                        data={departmentData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                        >
                        {departmentData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                        </Pie>
                        <Tooltip 
                        formatter={(value: number) => formatCurrency(value)} 
                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                        />
                        <Legend verticalAlign="middle" align="right" layout="vertical" />
                    </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>

        {/* Recent Activity Panel - Taking up 1/3 */}
        <div className="lg:col-span-1 bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col h-full min-h-[660px]">
            <div className="flex items-center gap-2 mb-6 border-b border-slate-100 pb-4">
                <Clock className="text-slate-400" size={20} />
                <h3 className="font-semibold text-slate-700">Atividades Recentes</h3>
            </div>
            
            <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pr-2">
                {recentActivity.length === 0 ? (
                    <div className="text-center text-slate-400 text-sm py-10 italic">
                        Nenhuma atividade registrada hoje.
                    </div>
                ) : (
                    recentActivity.map(log => (
                        <div key={log.id} className="flex gap-3 relative pb-4 border-b border-slate-50 last:border-0 last:pb-0">
                            <div className="mt-1 shrink-0">
                                <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-600 shadow-sm border border-slate-200">
                                    {log.userAvatar}
                                </div>
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-start mb-0.5">
                                    <span className="text-xs font-bold text-slate-700 truncate">{log.userName}</span>
                                    <span className="text-[10px] text-slate-400 whitespace-nowrap ml-2">
                                        {new Date(log.timestamp).toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}
                                    </span>
                                </div>
                                <div className="flex items-center gap-1.5 mb-1">
                                    {getActionIcon(log.action)}
                                    <span className="text-xs font-medium text-slate-600 truncate">{log.target}</span>
                                </div>
                                <p className="text-[11px] text-slate-500 leading-tight">
                                    {log.details}
                                </p>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

// Updated Metric Card with Gradient and Interaction
const MetricCard = ({ title, value, icon: Icon, iconBg, textColor, onClick }: any) => (
  <div 
    onClick={onClick}
    className={`bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center gap-4 transition-all duration-300 relative overflow-hidden group 
    ${onClick ? 'cursor-pointer hover:shadow-md hover:scale-[1.02]' : ''}`}
  >
    {/* Gradient Background for Icon */}
    <div className={`p-4 rounded-xl bg-gradient-to-br ${iconBg} text-white shadow-sm shrink-0`}>
      <Icon size={24} />
    </div>
    
    <div className="z-10">
      <p className="text-sm text-slate-500 font-medium">{title}</p>
      <h3 className={`text-xl font-bold ${textColor} mt-1`}>{value}</h3>
    </div>

    {/* Subtle Decorative Circle */}
    <div className={`absolute -right-4 -bottom-4 w-24 h-24 rounded-full opacity-5 bg-gradient-to-br ${iconBg} pointer-events-none group-hover:scale-110 transition-transform`}></div>
  </div>
);