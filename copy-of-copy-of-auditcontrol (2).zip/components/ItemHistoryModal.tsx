import React from 'react';
import { HistoryLog } from '../types';
import { X, Clock, Plus, Edit, Trash2, CheckCircle, XCircle } from 'lucide-react';

interface ItemHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  itemTitle: string;
  logs: HistoryLog[];
}

export const ItemHistoryModal: React.FC<ItemHistoryModalProps> = ({ isOpen, onClose, itemTitle, logs }) => {
  if (!isOpen) return null;

  const sortedLogs = [...logs].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'CREATE': return <Plus size={14} className="text-emerald-600" />;
      case 'UPDATE': return <Edit size={14} className="text-blue-600" />;
      case 'DELETE': return <Trash2 size={14} className="text-red-600" />;
      case 'APPROVE': return <CheckCircle size={14} className="text-purple-600" />;
      case 'REJECT': return <XCircle size={14} className="text-orange-600" />;
      default: return <Clock size={14} className="text-slate-500" />;
    }
  };

  const getActionBg = (action: string) => {
    switch (action) {
      case 'CREATE': return 'bg-emerald-100';
      case 'UPDATE': return 'bg-blue-100';
      case 'DELETE': return 'bg-red-100';
      case 'APPROVE': return 'bg-purple-100';
      case 'REJECT': return 'bg-orange-100';
      default: return 'bg-slate-100';
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-[1100]">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[80vh] flex flex-col animate-scale-in">
        <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50 rounded-t-2xl">
          <div>
             <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
               <Clock size={20} className="text-slate-400" /> Histórico de Movimentações
             </h3>
             <p className="text-xs text-slate-500 truncate max-w-[300px]">Ref: {itemTitle}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
          {sortedLogs.length === 0 ? (
            <div className="text-center py-10 text-slate-400 italic">
              Nenhuma movimentação registrada para este item.
            </div>
          ) : (
            <div className="relative border-l-2 border-slate-100 ml-3 space-y-8">
               {sortedLogs.map((log) => (
                 <div key={log.id} className="relative pl-8">
                    {/* Timestamp Marker */}
                    <div className={`absolute -left-[9px] top-0 w-4 h-4 rounded-full border-2 border-white shadow-sm ${getActionBg(log.action)} flex items-center justify-center`}>
                      {getActionIcon(log.action)}
                    </div>
                    
                    <div className="flex flex-col gap-1">
                       <div className="flex justify-between items-start">
                          <span className="text-xs font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded uppercase">
                            {log.action === 'CREATE' ? 'Criação' : 
                             log.action === 'UPDATE' ? 'Edição' : 
                             log.action === 'DELETE' ? 'Exclusão' : 
                             log.action === 'APPROVE' ? 'Aprovação' : 
                             log.action === 'REJECT' ? 'Reprovação' : log.action}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {new Date(log.timestamp).toLocaleDateString()} {new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                          </span>
                       </div>
                       
                       <p className="text-sm text-slate-600 leading-snug mt-1">
                         {log.details}
                       </p>

                       <div className="flex items-center gap-2 mt-2">
                          <div className="w-5 h-5 rounded-full bg-slate-200 flex items-center justify-center text-[8px] font-bold text-slate-600">
                              {log.userAvatar}
                          </div>
                          <span className="text-xs text-slate-500">{log.userName}</span>
                       </div>
                    </div>
                 </div>
               ))}
            </div>
          )}
        </div>
        
        <div className="p-4 border-t border-slate-100 bg-slate-50 rounded-b-2xl text-center">
            <button onClick={onClose} className="text-sm text-slate-500 hover:text-slate-700 font-medium">
                Fechar
            </button>
        </div>
      </div>
    </div>
  );
};