
import React, { useState, useRef, useEffect } from 'react';
import { X, Send, User, ChevronDown } from 'lucide-react';
import { getChatResponse } from '../services/geminiService';

interface Message {
  role: 'user' | 'model';
  text: string;
}

// --- Personagem Robozinho (Cassandra Avatar) ---
// Um robô amigável construído com SVG puro e classes Tailwind para animação
const CuteRobot = ({ size = 24, className = "" }: { size?: number, className?: string }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 100 100" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg" 
    className={className}
  >
    {/* Orelha Esquerda */}
    <rect x="10" y="45" width="10" height="20" rx="2" fill="#6366F1" />
    {/* Orelha Direita */}
    <rect x="80" y="45" width="10" height="20" rx="2" fill="#6366F1" />
    
    {/* Antena Haste */}
    <line x1="50" y1="25" x2="50" y2="10" stroke="#475569" strokeWidth="4" strokeLinecap="round" />
    {/* Antena Bola (Piscando) */}
    <circle cx="50" cy="10" r="6" fill="#F43F5E" className="animate-pulse" />
    
    {/* Cabeça */}
    <rect x="20" y="25" width="60" height="55" rx="12" fill="#4F46E5" stroke="#312E81" strokeWidth="2" />
    
    {/* Rosto (Tela Escura) */}
    <rect x="28" y="35" width="44" height="30" rx="6" fill="#1E1B4B" />
    
    {/* Olhos (Brilhantes e Piscando) */}
    <circle cx="40" cy="48" r="4" fill="#22D3EE" className="animate-[bounce_3s_infinite]" />
    <circle cx="60" cy="48" r="4" fill="#22D3EE" className="animate-[bounce_3s_infinite_0.5s]" />
    
    {/* Boca (Sorriso) */}
    <path d="M42 58 Q50 63 58 58" stroke="#22D3EE" strokeWidth="2" strokeLinecap="round" />
    
    {/* Reflexo na Cabeça */}
    <path d="M25 28 H40" stroke="white" strokeWidth="2" strokeOpacity="0.3" strokeLinecap="round" />
  </svg>
);

export const AIChatAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'Olá! Eu sou a Cassandra 🤖. Estou aqui para ajudar você com auditorias, orçamentos e dúvidas sobre o sistema!' }
  ]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage = inputText;
    setInputText('');
    
    // Add user message immediately
    const newHistory = [...messages, { role: 'user', text: userMessage } as Message];
    setMessages(newHistory);
    setIsLoading(true);

    try {
      // Get AI response
      const aiResponseText = await getChatResponse(userMessage, newHistory);
      setMessages(prev => [...prev, { role: 'model', text: aiResponseText }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: 'Minha conexão falhou! ⚡ Tente perguntar novamente.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[2000] font-sans flex flex-col items-end">
      
      {/* Janela do Chat */}
      {isOpen && (
        <div className="bg-white rounded-2xl shadow-2xl w-80 sm:w-96 h-[500px] flex flex-col mb-4 border border-slate-200 animate-scale-in overflow-hidden">
          {/* Header Personalizado */}
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-4 flex justify-between items-center text-white shadow-md relative overflow-hidden">
            {/* Círculos decorativos no fundo */}
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-white/10 rounded-full blur-xl"></div>
            <div className="absolute top-2 right-12 w-16 h-16 bg-emerald-400/20 rounded-full blur-xl"></div>

            <div className="flex items-center gap-3 relative z-10">
              <div className="p-1.5 bg-white/20 rounded-full backdrop-blur-sm border border-white/30 shadow-inner">
                <CuteRobot size={32} />
              </div>
              <div>
                <h3 className="font-bold text-sm tracking-wide">Cassandra AI</h3>
                <p className="text-[10px] text-indigo-100 flex items-center gap-1 font-medium">
                  <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse shadow-[0_0_8px_#34d399]"></span> Online
                </p>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)} 
              className="text-indigo-100 hover:text-white transition-colors bg-white/10 p-1.5 rounded-lg hover:bg-white/20"
            >
              <ChevronDown size={18} />
            </button>
          </div>

          {/* Área de Mensagens */}
          <div className="flex-1 overflow-y-auto p-4 bg-slate-50 space-y-4 custom-scrollbar">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`flex items-end gap-2 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                  
                  {/* Avatar */}
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-sm border-2 border-white
                    ${msg.role === 'user' ? 'bg-slate-200 text-slate-600' : 'bg-indigo-50'}`}>
                    {msg.role === 'user' ? <User size={16} /> : <CuteRobot size={24} />}
                  </div>

                  {/* Balão de Texto */}
                  <div className={`p-3 rounded-2xl text-sm leading-relaxed shadow-sm relative
                    ${msg.role === 'user' 
                      ? 'bg-indigo-600 text-white rounded-tr-none' 
                      : 'bg-white text-slate-700 border border-slate-200 rounded-tl-none'}`}>
                    {msg.text}
                  </div>
                </div>
              </div>
            ))}
            
            {/* Indicador de Digitação (Loading) */}
            {isLoading && (
              <div className="flex justify-start animate-fade-in">
                 <div className="flex items-end gap-2">
                    <div className="w-8 h-8 rounded-full bg-indigo-50 flex items-center justify-center shrink-0 border-2 border-white">
                        <CuteRobot size={24} />
                    </div>
                    <div className="bg-white border border-slate-200 p-3 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-1">
                        <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce"></span>
                        <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce delay-75"></span>
                        <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce delay-150"></span>
                    </div>
                 </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Área de Input */}
          <div className="p-3 bg-white border-t border-slate-100">
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-full px-4 py-2 focus-within:ring-2 focus-within:ring-indigo-500/20 focus-within:border-indigo-500 transition-all shadow-inner">
              <input 
                type="text" 
                className="flex-1 bg-transparent outline-none text-sm text-slate-800 placeholder:text-slate-400"
                placeholder="Pergunte à Cassandra..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                disabled={isLoading}
              />
              <button 
                onClick={handleSendMessage}
                disabled={!inputText.trim() || isLoading}
                className="p-2 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105 active:scale-95 shadow-md shadow-indigo-200"
              >
                <Send size={16} />
              </button>
            </div>
            <div className="text-center mt-2">
                <span className="text-[10px] text-slate-400 font-medium">Powered by Gemini AI 🤖</span>
            </div>
          </div>
        </div>
      )}

      {/* Botão Flutuante (Cabeça do Robô) */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`w-16 h-16 rounded-full shadow-xl shadow-indigo-900/40 flex items-center justify-center transition-all duration-300 transform hover:scale-110 active:scale-95 border-4 border-white relative z-50
          ${isOpen ? 'bg-slate-700 rotate-180' : 'bg-gradient-to-br from-indigo-600 to-purple-600'}`}
      >
        {isOpen ? (
          <X size={28} className="text-white" />
        ) : (
          <div className="relative">
             <CuteRobot size={42} className="text-white drop-shadow-md" />
             {/* Notificação Pulse */}
             <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 border-2 border-white rounded-full flex items-center justify-center">
                <span className="w-full h-full bg-red-500 rounded-full animate-ping opacity-75 absolute"></span>
             </span>
          </div>
        )}
      </button>
    </div>
  );
};
