
import React from 'react';
import { LayoutDashboard, FilePlus, Handshake, Database, Grid3X3, Globe, Users, ShieldCheck, LogOut, ClipboardCheck, Hexagon } from 'lucide-react';
import { ViewState, User, UserRole } from '../types';

interface SidebarProps {
  currentView: ViewState;
  onChangeView: (view: ViewState) => void;
  user: User;
  companyName?: string;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView, user, companyName, onLogout }) => {
  
  const getMenuItems = () => {
    const items = [
      { id: 'DASHBOARD' as ViewState, label: 'Dashboard', icon: LayoutDashboard, allowed: ['ADMIN', 'PLANNER', 'EXECUTOR', 'DEMO'] as UserRole[] },
      { id: 'TRANSPARENCY' as ViewState, label: 'Portal Transparência', icon: Globe, allowed: ['ADMIN', 'PLANNER', 'EXECUTOR', 'DEMO'] as UserRole[] },
      { id: 'PLANNING' as ViewState, label: 'Planejamento', icon: FilePlus, allowed: ['ADMIN', 'PLANNER'] as UserRole[] },
      { id: 'MATRICIAL' as ViewState, label: 'Orç. Matricial', icon: Grid3X3, allowed: ['ADMIN', 'PLANNER', 'EXECUTOR'] as UserRole[] },
      { id: 'NEGOTIATIONS' as ViewState, label: 'Negociações', icon: Handshake, allowed: ['ADMIN', 'EXECUTOR'] as UserRole[] },
      { id: 'PARTNERS' as ViewState, label: 'Parceiros', icon: Users, allowed: ['ADMIN', 'EXECUTOR'] as UserRole[] },
      { id: 'REQUESTS' as ViewState, label: 'Solicitações & Aprovações', icon: ClipboardCheck, allowed: ['ADMIN', 'PLANNER', 'EXECUTOR'] as UserRole[] },
      // History removed from sidebar as requested
      { id: 'SETTINGS' as ViewState, label: 'Cadastros', icon: Database, allowed: ['ADMIN'] as UserRole[] },
    ];

    // Filter items based on user role
    const filteredItems = items.filter(item => item.allowed.includes(user.role));

    // Special handling for DEMO role
    if (user.role === 'DEMO') {
      return filteredItems.filter(item => item.id === 'DASHBOARD' || item.id === 'TRANSPARENCY');
    }

    return filteredItems;
  };

  return (
    <div className="w-64 bg-slate-900 text-white flex flex-col h-screen sticky top-0 left-0 shadow-xl z-20 font-sans">
      <div className="p-6 flex flex-col gap-4 border-b border-slate-800 bg-slate-900">
        
        {/* LOGO VIA CÓDIGO (Sem imagens externas) */}
        <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl shadow-lg shadow-emerald-900/50 text-white">
                <ShieldCheck size={24} strokeWidth={2.5} />
            </div>
            <div className="flex flex-col">
                <h1 className="font-bold text-xl tracking-tighter leading-none text-white">
                    Audit<span className="text-emerald-400">Control</span>
                </h1>
                <span className="text-[9px] text-slate-400 font-bold tracking-widest uppercase mt-0.5">Enterprise</span>
            </div>
        </div>

        <div>
          <span className="text-xs text-slate-400 flex items-center gap-1">
            {user.name.split(' ')[0]} • <span className="text-[10px] uppercase bg-slate-800 border border-slate-700 px-1.5 py-0.5 rounded text-slate-300">{user.role}</span>
          </span>
          {companyName && (
             <div className="text-[10px] text-emerald-500 font-medium mt-1 truncate max-w-[140px] flex items-center gap-1" title={companyName}>
               <Hexagon size={10} className="fill-current" /> {companyName}
             </div>
          )}
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto custom-scrollbar">
        <div className="mb-2 px-4 text-[10px] font-bold text-slate-600 uppercase tracking-wider">
          Navegação
        </div>
        {getMenuItems().map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChangeView(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group relative overflow-hidden ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon size={20} className={`relative z-10 transition-transform duration-200 ${isActive ? 'scale-110' : 'group-hover:scale-110'}`} />
              <span className="font-medium text-sm relative z-10">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800 space-y-2 bg-slate-900">
        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:bg-red-500/10 hover:text-red-400 transition-colors group"
        >
          <LogOut size={20} className="group-hover:-translate-x-1 transition-transform"/>
          <span className="font-medium text-sm">Sair do Sistema</span>
        </button>
        <div className="text-center text-[10px] text-slate-600 mt-2 font-mono opacity-50">
          v4.3.0
        </div>
      </div>
    </div>
  );
};
