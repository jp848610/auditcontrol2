
import React, { useMemo, useState } from 'react';
import { HistoryLog, User } from '../types';
import { Clock, Search, Filter, Trash2, Edit, Plus, User as UserIcon, CheckCircle, XCircle } from 'lucide-react';

interface HistoryLogViewProps {
  logs: HistoryLog[];
  user: User; // Current user
}

export const HistoryLogView: React.FC<HistoryLogViewProps> = ({ logs, user }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLogs = useMemo(() => {
    return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .filter(log => 
        log.target.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.details.toLowerCase().includes(searchTerm.toLowerCase())
      );
  }, [logs, searchTerm]);

  const getActionBadge = (action: string) => {
    switch (action) {
      case 'CREATE': return <span className="flex items-center gap-1 bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase"><Plus size={10} /> Criou</span>;
      case 'UPDATE': return <span className="flex items-center gap-1 bg-blue-100 text-blue-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase"><Edit size={10} /> Editou</span>;
      case 'DELETE': return <span className="flex items-center gap-1 bg-red-100 text-red-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase"><Trash2 size={10} /> Removeu</span>;
      case 'APPROVE': return <span className="flex items-center gap-1 bg-purple-100 text-purple-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase"><CheckCircle size={10} /> Aprovou</span>;
      case 'REJECT': return <span className="flex items-center gap-1 bg-orange-100 text-orange-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase"><XCircle size={10} /> Reprovou</span>;
      default: return <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-[10px] font-bold uppercase">{action}</span>;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-10">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Histórico de Alterações</h2>
          <p className="text-slate-500">Rastreabilidade completa de quem mexeu, o que fez e quando.</p>
        </div>
      </header>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex items-center gap-3">
        <Search className="text-slate-400" size={20} />
        <input 
          type="text" 
          placeholder="Buscar no histórico (usuário, ação, item)..." 
          className="flex-1 outline-none text-slate-700"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <div className="text-xs text-slate-400">Mostrando últimos {filteredLogs.length} registros</div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 border-b border-slate-100">
            <tr>
              <th className="px-6 py-4 font-semibold text-slate-600">Data / Hora</th>
              <th className="px-6 py-4 font-semibold text-slate-600">Usuário</th>
              <th className="px-6 py-4 font-semibold text-slate-600">Ação</th>
              <th className="px-6 py-4 font-semibold text-slate-600">Item Afetado</th>
              <th className="px-6 py-4 font-semibold text-slate-600">Detalhes</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredLogs.length === 0 ? (
              <tr>
                <td colSpan={5} className="text-center py-12 text-slate-500 italic">
                  <Clock className="mx-auto text-slate-300 mb-3" size={48} />
                  Nenhum registro encontrado no histórico.
                </td>
              </tr>
            ) : (
              filteredLogs.map(log => (
                <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-slate-500 font-mono text-xs">
                    {new Date(log.timestamp).toLocaleDateString('pt-BR')} <br/>
                    {new Date(log.timestamp).toLocaleTimeString('pt-BR')}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                       <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-600">
                          {log.userAvatar}
                       </div>
                       <span className="font-medium text-slate-700">{log.userName}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {getActionBadge(log.action)}
                  </td>
                  <td className="px-6 py-4 font-medium text-slate-800">
                    {log.target}
                  </td>
                  <td className="px-6 py-4 text-slate-500 text-xs max-w-xs truncate" title={log.details}>
                    {log.details}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
