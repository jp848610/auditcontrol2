
import React, { useState, useEffect } from 'react';
import { X, CheckCircle, AlertCircle, Info } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'info';

interface ToastMessage {
  id: string;
  message: string;
  type: ToastType;
}

// Simple Event Emitter for decoupled notification
const listeners: ((toast: ToastMessage) => void)[] = [];

export const notify = (message: string, type: ToastType = 'info') => {
  const id = Math.random().toString(36).substr(2, 9);
  const toast = { id, message, type };
  listeners.forEach(l => l(toast));
};

export const ToastContainer: React.FC = () => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  useEffect(() => {
    const handler = (toast: ToastMessage) => {
      setToasts(prev => [...prev, toast]);
      
      // Auto dismiss after 3 seconds
      const timer = setTimeout(() => {
        setToasts(prev => prev.filter(t => t.id !== toast.id));
      }, 3000);

      return () => clearTimeout(timer);
    };

    listeners.push(handler);
    return () => {
      const index = listeners.indexOf(handler);
      if (index > -1) listeners.splice(index, 1);
    };
  }, []);

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  return (
    <div className="fixed top-4 right-4 z-[9999] flex flex-col gap-2 pointer-events-none">
      {toasts.map(toast => (
        <div 
          key={toast.id}
          className={`
            min-w-[300px] max-w-sm p-4 rounded-lg shadow-lg border flex items-start gap-3 pointer-events-auto
            animate-slide-in backdrop-blur-sm
            ${toast.type === 'success' ? 'bg-white/95 border-emerald-100 text-slate-800' : ''}
            ${toast.type === 'error' ? 'bg-white/95 border-red-100 text-slate-800' : ''}
            ${toast.type === 'info' ? 'bg-white/95 border-blue-100 text-slate-800' : ''}
          `}
        >
          <div className={`
             p-1.5 rounded-full shrink-0 mt-0.5
             ${toast.type === 'success' ? 'bg-emerald-100 text-emerald-600' : ''}
             ${toast.type === 'error' ? 'bg-red-100 text-red-600' : ''}
             ${toast.type === 'info' ? 'bg-blue-100 text-blue-600' : ''}
          `}>
             {toast.type === 'success' && <CheckCircle size={18} />}
             {toast.type === 'error' && <AlertCircle size={18} />}
             {toast.type === 'info' && <Info size={18} />}
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium leading-tight">{toast.message}</p>
          </div>
          <button onClick={() => removeToast(toast.id)} className="text-slate-400 hover:text-slate-600 shrink-0">
            <X size={16} />
          </button>
        </div>
      ))}
    </div>
  );
};