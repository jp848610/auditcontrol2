
import React, { useState, useMemo } from 'react';
import { User, Partner, PartnerSegment, PartnerContract, NotifyFn, ActionType, Attachment, HistoryLog } from '../types';
import { Plus, Search, Users, Phone, Mail, FileText, Calendar, DollarSign, Trash2, Edit, X, Layers, Filter, Upload, Paperclip, Info } from 'lucide-react';
import { ItemHistoryModal } from './ItemHistoryModal';

interface PartnersWorkflowProps {
  user: User;
  partners: Partner[];
  setPartners: (data: Partner[] | ((prev: Partner[]) => Partner[])) => void;
  partnerSegments: PartnerSegment[];
  partnerContracts: PartnerContract[];
  setPartnerContracts: (data: PartnerContract[] | ((prev: PartnerContract[]) => PartnerContract[])) => void;
  notify: NotifyFn;
  showConfirmModal: (message: string, onConfirm: () => void) => void;
  logAction: (action: ActionType, target: string, details: string, itemId?: string) => void; 
  historyLogs: HistoryLog[];
}

export const PartnersWorkflow: React.FC<PartnersWorkflowProps> = ({
  user,
  partners,
  setPartners,
  partnerSegments,
  partnerContracts,
  setPartnerContracts,
  notify,
  showConfirmModal,
  logAction,
  historyLogs
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSegmentFilter, setSelectedSegmentFilter] = useState<string>('ALL'); // State for Segment Filter

  const [isPartnerModalOpen, setIsPartnerModalOpen] = useState(false);
  const [isContractModalOpen, setIsContractModalOpen] = useState(false);
  const [currentPartner, setCurrentPartner] = useState<Partial<Partner> | null>(null);
  const [currentContract, setCurrentContract] = useState<Partial<PartnerContract> | null>(null);
  const [selectedPartnerIdForContract, setSelectedPartnerIdForContract] = useState<string | null>(null);

  // History Modal State
  const [historyItemId, setHistoryItemId] = useState<string | null>(null);

  // Filter List by Year (for display only, assuming partners have created dates or just show all for now)
  // The request was "only the year" in partners, likely meaning filtering contracts or just display.
  // I'll add a year filter for contracts view if needed, but for Partners list it's usually all.

  // First, filter by Search Term
  const searchFilteredPartners = useMemo(() => {
    return partners.filter(partner =>
      partner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      partner.contactPerson.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (partnerSegments.find(s => s.id === partner.segmentId)?.name || '').toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [partners, searchTerm, partnerSegments]);

  // Determine which segments to show based on the Filter Tab
  const visibleSegments = useMemo(() => {
    if (selectedSegmentFilter === 'ALL') {
      return partnerSegments;
    }
    return partnerSegments.filter(s => s.id === selectedSegmentFilter);
  }, [partnerSegments, selectedSegmentFilter]);

  const handleOpenPartnerModal = (partner?: Partner) => {
    setCurrentPartner(partner || { name: '', segmentId: partnerSegments[0]?.id || '', contactPerson: '', contactEmail: '', notes: '' });
    setIsPartnerModalOpen(true);
  };

  const handleSavePartner = () => {
    if (!currentPartner?.name || !currentPartner.segmentId || !currentPartner.contactPerson || !currentPartner.contactEmail) {
      notify('Preencha todos os campos obrigatórios do parceiro.', 'error');
      return;
    }

    const partnerToSave: Partner = {
      id: currentPartner.id || `p${Date.now()}`,
      companyId: user.companyId, // Ensure companyId is set
      name: currentPartner.name,
      segmentId: currentPartner.segmentId,
      contactPerson: currentPartner.contactPerson,
      contactEmail: currentPartner.contactEmail,
      notes: currentPartner.notes || '',
    };

    if (currentPartner.id) {
      setPartners(prev => prev.map(p => (p.id === partnerToSave.id ? partnerToSave : p)));
      logAction('UPDATE', `Parceiro: ${partnerToSave.name}`, 'Atualizou dados de cadastro do parceiro.', partnerToSave.id);
      notify('Parceiro atualizado com sucesso!', 'success');
    } else {
      setPartners(prev => [...prev, partnerToSave]);
      logAction('CREATE', `Parceiro: ${partnerToSave.name}`, 'Criou novo parceiro.', partnerToSave.id);
      notify('Parceiro adicionado com sucesso!', 'success');
    }
    setIsPartnerModalOpen(false);
  };

  const handleDeletePartner = (id: string) => {
    const partnerName = partners.find(p => p.id === id)?.name || 'Desconhecido';
    console.log(`[PartnersWorkflow] Attempting to delete partner with ID: ${id}`);
    showConfirmModal('Tem certeza que deseja remover este parceiro e todos os seus contratos?', () => {
      console.log(`[PartnersWorkflow] User confirmed deletion for partner ID: ${id}`);
      setPartners(prev => prev.filter(p => p.id !== id));
      setPartnerContracts(prev => prev.filter(c => c.partnerId !== id)); 
      
      logAction('DELETE', `Parceiro: ${partnerName}`, 'Removeu parceiro e contratos associados.', id);
      notify('Parceiro e seus contratos removidos.', 'info');
    });
  };

  const handleOpenContractModal = (partnerId: string, contract?: PartnerContract) => {
    setSelectedPartnerIdForContract(partnerId);
    setCurrentContract(contract || {
      partnerId: partnerId,
      description: '',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0],
      value: 0,
      itemsPurchased: '',
      attachments: []
    });
    setIsContractModalOpen(true);
  };

  const handleSaveContract = () => {
    if (!currentContract?.description || !currentContract.startDate || !currentContract.endDate || !currentContract.value || !currentContract.itemsPurchased) {
      notify('Preencha todos os campos obrigatórios do contrato.', 'error');
      return;
    }

    const contractToSave: PartnerContract = {
      id: currentContract.id || `pc${Date.now()}`,
      companyId: user.companyId, // Ensure companyId is set
      partnerId: selectedPartnerIdForContract!,
      description: currentContract.description,
      startDate: currentContract.startDate,
      endDate: currentContract.endDate,
      value: currentContract.value,
      itemsPurchased: currentContract.itemsPurchased,
      attachments: currentContract.attachments || []
    };

    const partnerName = partners.find(p => p.id === contractToSave.partnerId)?.name || 'Desconhecido';

    if (currentContract.id) {
      setPartnerContracts(prev => prev.map(c => (c.id === contractToSave.id ? contractToSave : c)));
      logAction('UPDATE', `Contrato: ${contractToSave.description}`, `Atualizou contrato do parceiro ${partnerName}.`, contractToSave.id);
      notify('Contrato atualizado com sucesso!', 'success');
    } else {
      setPartnerContracts(prev => [...prev, contractToSave]);
      logAction('CREATE', `Contrato: ${contractToSave.description}`, `Criou novo contrato para ${partnerName}.`, contractToSave.id);
      notify('Contrato adicionado com sucesso!', 'success');
    }
    setIsContractModalOpen(false);
  };

  const handleDeleteContract = (id: string) => {
    const contract = partnerContracts.find(c => c.id === id);
    console.log(`[PartnersWorkflow] Attempting to delete contract with ID: ${id}`);
    showConfirmModal('Tem certeza que deseja remover este contrato?', () => {
      console.log(`[PartnersWorkflow] User confirmed deletion for contract ID: ${id}`);
      setPartnerContracts(prev => prev.filter(c => c.id !== id));
      logAction('DELETE', `Contrato: ${contract?.description}`, 'Removeu contrato.', id);
      notify('Contrato removido.', 'info');
    });
  };

  const handleContractFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        const newAttachment: Attachment = {
          name: file.name,
          url: base64String,
          type: file.type,
          size: file.size
        };
        setCurrentContract(prev => ({
          ...prev,
          attachments: [...(prev?.attachments || []), newAttachment]
        }));
        notify('Arquivo anexado com sucesso!', 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  const removeContractAttachment = (index: number) => {
    setCurrentContract(prev => ({
      ...prev,
      attachments: prev?.attachments?.filter((_, i) => i !== index)
    }));
  };

  const getPartnerSegmentName = (segmentId: string) => {
    return partnerSegments.find(s => s.id === segmentId)?.name || 'Sem Segmento';
  };

  return (
    <div className="space-y-6 animate-fade-in pb-10">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Gestão de Parceiros</h2>
          <p className="text-slate-500">Cadastre seus parceiros e gerencie os contratos de aquisição.</p>
        </div>
        <button
          onClick={() => handleOpenPartnerModal()}
          className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg shadow transition-colors"
        >
          <Plus size={20} /> Novo Parceiro
        </button>
      </header>

      {/* Search and Filters */}
      <div className="space-y-4">
        {/* Search Bar */}
        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex items-center gap-3">
          <Search className="text-slate-400" size={20} />
          <input
            type="text"
            placeholder="Buscar parceiros por nome, contato..."
            className="flex-1 outline-none text-slate-700 bg-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {/* Segment Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 custom-scrollbar">
          <div className="flex items-center gap-2 pr-2 border-r border-slate-200 mr-2 text-slate-400">
             <Filter size={16} />
             <span className="text-xs font-bold uppercase">Filtrar:</span>
          </div>
          <button
            onClick={() => setSelectedSegmentFilter('ALL')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap
              ${selectedSegmentFilter === 'ALL' 
                ? 'bg-slate-800 text-white shadow-md' 
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'}`}
          >
            Todos
          </button>
          {partnerSegments.map(segment => (
            <button
              key={segment.id}
              onClick={() => setSelectedSegmentFilter(segment.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap
                ${selectedSegmentFilter === segment.id 
                  ? 'bg-purple-600 text-white shadow-md' 
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'}`}
            >
              {segment.name}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area - Grouped by Segment */}
      <div className="space-y-8">
        {searchFilteredPartners.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-dashed border-slate-300">
            <Users className="mx-auto text-slate-300 mb-3" size={48} />
            <p className="text-slate-500">Nenhum parceiro encontrado.</p>
          </div>
        ) : (
          visibleSegments.map(segment => {
             // Filter partners belonging to this segment that also match the search term
             const segmentPartners = searchFilteredPartners.filter(p => p.segmentId === segment.id);
             
             if (segmentPartners.length === 0) return null;

             return (
               <div key={segment.id} className="animate-fade-in">
                  <div className="flex items-center gap-3 mb-4">
                     <Layers size={20} className="text-slate-400"/>
                     <h3 className="font-bold text-slate-700 text-lg">{segment.name}</h3>
                     <span className="bg-slate-100 text-slate-500 text-xs font-bold px-2 py-0.5 rounded-full">
                       {segmentPartners.length}
                     </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {segmentPartners.map(partner => (
                        <div key={partner.id} className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 relative group hover:shadow-md transition-shadow">
                          <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                                onClick={() => setHistoryItemId(partner.id)}
                                className="p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
                                title="Ver Histórico"
                            >
                                <Info size={16} />
                            </button>
                            <button
                              onClick={() => handleOpenPartnerModal(partner)}
                              className="p-2 rounded-full text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                              title="Editar Parceiro"
                            >
                              <Edit size={16} />
                            </button>
                            <button
                              onClick={() => handleDeletePartner(partner.id)}
                              className="p-2 rounded-full text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                              title="Excluir Parceiro"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>

                          <div className="flex items-center gap-4 mb-4">
                            <div className="w-12 h-12 rounded-full bg-purple-50 flex items-center justify-center text-purple-700 font-bold text-lg border border-purple-100">
                              {partner.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <h3 className="text-lg font-bold text-slate-800 leading-tight">{partner.name}</h3>
                              <p className="text-xs text-slate-400 mt-1">ID: {partner.id.slice(0,8)}...</p>
                            </div>
                          </div>

                          <div className="space-y-2 text-sm text-slate-600 mb-4">
                            <div className="flex items-center gap-2">
                              <Users size={16} className="text-slate-400" />
                              <span>{partner.contactPerson}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Mail size={16} className="text-slate-400" />
                              <span className="truncate">{partner.contactEmail}</span>
                            </div>
                            {partner.notes && (
                              <p className="text-xs text-slate-500 italic mt-2 border-l-2 border-slate-200 pl-2 line-clamp-2">
                                {partner.notes}
                              </p>
                            )}
                          </div>

                          <div className="pt-4 border-t border-slate-100">
                            <h4 className="font-semibold text-slate-700 text-sm mb-2 flex items-center justify-between">
                               <span>Contratos Ativos</span>
                               <span className="bg-slate-100 text-slate-500 px-1.5 rounded text-[10px]">{partnerContracts.filter(c => c.partnerId === partner.id).length}</span>
                            </h4>
                            <ul className="space-y-1 text-xs text-slate-600 max-h-24 overflow-y-auto custom-scrollbar pr-2 mb-3">
                              {partnerContracts.filter(c => c.partnerId === partner.id).length === 0 ? (
                                <li className="text-slate-400 italic">Nenhum contrato.</li>
                              ) : (
                                partnerContracts.filter(c => c.partnerId === partner.id).map(contract => (
                                  <li key={contract.id} className="flex justify-between items-center bg-slate-50 rounded-md p-2 group/item">
                                    <div className="flex items-center gap-1.5 overflow-hidden">
                                        {contract.attachments && contract.attachments.length > 0 && (
                                            <Paperclip size={10} className="text-blue-500 shrink-0" />
                                        )}
                                        <span className="truncate flex-1" title={contract.description}>{contract.description}</span>
                                    </div>
                                    <div className="flex items-center gap-1 pl-2">
                                      <span className="font-medium whitespace-nowrap text-emerald-600">R$ {contract.value.toLocaleString()}</span>
                                      <div className="opacity-0 group-hover/item:opacity-100 flex gap-1 transition-opacity">
                                        <button onClick={() => setHistoryItemId(contract.id)} className="text-slate-400 hover:text-slate-600 ml-1">
                                            <Info size={12} />
                                        </button>
                                        <button
                                            onClick={() => handleOpenContractModal(partner.id, contract)}
                                            className="text-slate-400 hover:text-blue-600 ml-1"
                                        >
                                            <Edit size={12} />
                                        </button>
                                        <button
                                            onClick={() => handleDeleteContract(contract.id)}
                                            className="text-slate-400 hover:text-red-600 ml-1"
                                        >
                                            <Trash2 size={12} />
                                        </button>
                                      </div>
                                    </div>
                                  </li>
                                ))
                              )}
                            </ul>
                            <button
                              onClick={() => handleOpenContractModal(partner.id)}
                              className="w-full bg-white hover:bg-slate-50 text-purple-600 border border-purple-200 hover:border-purple-300 py-2 rounded-lg flex items-center justify-center gap-1 text-sm transition-colors font-medium"
                            >
                              <Plus size={16} /> Adicionar Contrato
                            </button>
                          </div>
                        </div>
                    ))}
                  </div>
               </div>
             );
          })
        )}
      </div>

      {/* Item History Modal */}
      <ItemHistoryModal 
        isOpen={!!historyItemId}
        onClose={() => setHistoryItemId(null)}
        itemTitle={
          partners.find(p => p.id === historyItemId)?.name || 
          partnerContracts.find(c => c.id === historyItemId)?.description || 'Item'
        }
        logs={historyLogs.filter(log => log.itemId === historyItemId)}
      />

      {/* Partner Modal */}
      {isPartnerModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md animate-scale-in">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-xl font-bold text-slate-800">
                {currentPartner?.id ? 'Editar Parceiro' : 'Novo Parceiro'}
              </h3>
              <button onClick={() => setIsPartnerModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X size={24} />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Nome do Parceiro</label>
                <input
                  type="text"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500/50 bg-white"
                  value={currentPartner?.name || ''}
                  onChange={e => setCurrentPartner(prev => ({ ...prev!, name: e.target.value }))}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Segmento</label>
                <select
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white focus:ring-2 focus:ring-purple-500/50"
                  value={currentPartner?.segmentId || ''}
                  onChange={e => setCurrentPartner(prev => ({ ...prev!, segmentId: e.target.value }))}
                >
                  <option value="">Selecione...</option>
                  {partnerSegments.map(segment => (
                    <option key={segment.id} value={segment.id}>{segment.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Pessoa de Contato</label>
                <input
                  type="text"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500/50 bg-white"
                  value={currentPartner?.contactPerson || ''}
                  onChange={e => setCurrentPartner(prev => ({ ...prev!, contactPerson: e.target.value }))}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Email de Contato</label>
                <input
                  type="email"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500/50 bg-white"
                  value={currentPartner?.contactEmail || ''}
                  onChange={e => setCurrentPartner(prev => ({ ...prev!, contactEmail: e.target.value }))}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Observações (Opcional)</label>
                <textarea
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500/50 h-20 resize-none bg-white"
                  value={currentPartner?.notes || ''}
                  onChange={e => setCurrentPartner(prev => ({ ...prev!, notes: e.target.value }))}
                ></textarea>
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setIsPartnerModalOpen(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancelar</button>
              <button onClick={handleSavePartner} className="px-6 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg shadow-sm flex items-center gap-2">
                Salvar Parceiro
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Contract Modal */}
      {isContractModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md animate-scale-in max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center sticky top-0 bg-white z-10">
              <h3 className="text-xl font-bold text-slate-800">
                {currentContract?.id ? 'Editar Contrato' : 'Novo Contrato'}
              </h3>
              <button onClick={() => setIsContractModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X size={24} />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Descrição do Contrato</label>
                <input
                  type="text"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-emerald-500/50 bg-white"
                  value={currentContract?.description || ''}
                  onChange={e => setCurrentContract(prev => ({ ...prev!, description: e.target.value }))}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Início</label>
                  <input
                    type="date"
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-emerald-500/50 bg-white"
                    value={currentContract?.startDate || ''}
                    onChange={e => setCurrentContract(prev => ({ ...prev!, startDate: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Fim</label>
                  <input
                    type="date"
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-emerald-500/50 bg-white"
                    value={currentContract?.endDate || ''}
                    onChange={e => setCurrentContract(prev => ({ ...prev!, endDate: e.target.value }))}
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Valor (R$)</label>
                <input
                  type="number"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-emerald-500/50 bg-white"
                  value={currentContract?.value || 0}
                  onChange={e => setCurrentContract(prev => ({ ...prev!, value: parseFloat(e.target.value) || 0 }))}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Itens Comprados / Serviços</label>
                <textarea
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-emerald-500/50 h-20 resize-none bg-white"
                  value={currentContract?.itemsPurchased || ''}
                  onChange={e => setCurrentContract(prev => ({ ...prev!, itemsPurchased: e.target.value }))}
                ></textarea>
              </div>
               <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Anexos (Contrato PDF)</label>
                  <div className="flex gap-2 mb-2">
                       <label className="cursor-pointer bg-slate-100 hover:bg-slate-200 text-slate-600 px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors">
                          <Upload size={16} /> Anexar Arquivo
                          <input type="file" className="hidden" onChange={handleContractFileUpload} />
                       </label>
                  </div>
                  {currentContract?.attachments && currentContract.attachments.length > 0 && (
                      <ul className="space-y-1">
                          {currentContract.attachments.map((file, i) => (
                              <li key={i} className="flex justify-between items-center bg-slate-50 p-2 rounded border border-slate-200 text-sm">
                                  <div className="flex items-center gap-2 truncate">
                                      <FileText size={14} className="text-slate-400"/>
                                      <span className="text-slate-700 truncate max-w-[200px]">{file.name}</span>
                                  </div>
                                  <button onClick={() => removeContractAttachment(i)} className="text-red-400 hover:text-red-600">
                                      <X size={14} />
                                  </button>
                              </li>
                          ))}
                      </ul>
                  )}
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3 sticky bottom-0 bg-white">
              <button onClick={() => setIsContractModalOpen(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancelar</button>
              <button onClick={handleSaveContract} className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-sm">
                Salvar Contrato
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
