
import React, { useState } from 'react';
import { PurchaseRequest, User, Department, CostCenter, RequestStatus, NotifyFn, ActionType, HistoryLog } from '../types';
import { Plus, Check, X, Clock, FileText, DollarSign, Info } from 'lucide-react';
import { ItemHistoryModal } from './ItemHistoryModal';

interface RequestsWorkflowProps {
  user: User;
  requests: PurchaseRequest[];
  setRequests: (data: PurchaseRequest[] | ((prev: PurchaseRequest[]) => PurchaseRequest[])) => void;
  departments: Department[];
  costCenters: CostCenter[];
  notify: NotifyFn;
  logAction: (action: ActionType, target: string, details: string, itemId?: string) => void; 
  historyLogs: HistoryLog[];
}

export const RequestsWorkflow: React.FC<RequestsWorkflowProps> = ({ user, requests, setRequests, departments, costCenters, notify, logAction, historyLogs }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newRequest, setNewRequest] = useState<Partial<PurchaseRequest>>({
    item: '',
    amount: 0,
    department: '',
    costCenter: '',
    justification: ''
  });

  // History Modal State
  const [historyItemId, setHistoryItemId] = useState<string | null>(null);

  // Filter Logic
  const pendingRequests = requests.filter(r => r.status === 'PENDING');
  const myRequests = requests.filter(r => r.requesterId === user.id);
  
  // Admin sees all pending requests. Others see only their own.
  const viewableRequests = user.role === 'ADMIN' ? requests.sort((a, b) => a.status === 'PENDING' ? -1 : 1) : myRequests;

  const handleSubmit = () => {
    if (!newRequest.item || !newRequest.amount || !newRequest.department) return;

    const request: PurchaseRequest = {
      id: `req${Date.now()}`,
      companyId: user.companyId, // Ensure companyId is set
      item: newRequest.item!,
      amount: Number(newRequest.amount),
      department: newRequest.department!,
      costCenter: newRequest.costCenter || 'N/A',
      requesterId: user.id,
      requesterName: user.name,
      date: new Date().toISOString().split('T')[0],
      status: 'PENDING',
      justification: newRequest.justification || ''
    };

    setRequests(prev => [request, ...prev]);
    setIsModalOpen(false);
    setNewRequest({ item: '', amount: 0, department: '', costCenter: '', justification: '' });
    
    // Log Action
    logAction('CREATE', `Solicitação: ${request.item}`, `Nova solicitação de compra no valor de R$ ${request.amount.toLocaleString()}.`, request.id);
    
    notify('Solicitação enviada com sucesso!', 'success');
  };

  const handleApproval = (id: string, approved: boolean) => {
    const targetRequest = requests.find(r => r.id === id);
    setRequests(prev => prev.map(r => 
      r.id === id ? { ...r, status: approved ? 'APPROVED' : 'REJECTED' } : r
    ));
    
    // Log Action
    if (targetRequest) {
        if (approved) {
            logAction('APPROVE', `Solicitação: ${targetRequest.item}`, 'Solicitação aprovada pelo Administrador.', id);
        } else {
            logAction('REJECT', `Solicitação: ${targetRequest.item}`, 'Solicitação reprovada pelo Administrador.', id);
        }
    }

    notify(approved ? 'Solicitação aprovada.' : 'Solicitação reprovada.', approved ? 'success' : 'info');
  };

  const getStatusBadge = (status: RequestStatus) => {
    switch(status) {
      case 'APPROVED': return <span className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1"><Check size={12}/> Aprovado</span>;
      case 'REJECTED': return <span className="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1"><X size={12}/> Reprovado</span>;
      default: return <span className="bg-amber-100 text-amber-700 px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1"><Clock size={12}/> Pendente</span>;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Solicitações de Aquisição</h2>
          <p className="text-slate-500">
            {user.role === 'ADMIN' ? 'Gerencie e aprove solicitações de compra.' : 'Acompanhe suas solicitações e peça novos materiais.'}
          </p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)} 
          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg shadow transition-colors"
        >
          <Plus size={20} /> Nova Solicitação
        </button>
      </header>

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
            <span className="text-xs font-medium text-slate-500 uppercase">Pendentes</span>
            <p className="text-2xl font-bold text-amber-600">{requests.filter(r => r.status === 'PENDING').length}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
            <span className="text-xs font-medium text-slate-500 uppercase">Aprovadas (Mês)</span>
            <p className="text-2xl font-bold text-emerald-600">{requests.filter(r => r.status === 'APPROVED').length}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
            <span className="text-xs font-medium text-slate-500 uppercase">Total Rejeitado</span>
            <p className="text-2xl font-bold text-red-600">{requests.filter(r => r.status === 'REJECTED').length}</p>
        </div>
      </div>

      {/* Request List */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {viewableRequests.map(req => (
          <div key={req.id} className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden flex flex-col relative group">
             {/* History Icon */}
             <button 
                onClick={() => setHistoryItemId(req.id)}
                className="absolute top-4 right-4 text-slate-300 hover:text-slate-600 hover:bg-slate-50 p-1.5 rounded-full transition-colors z-10"
             >
                <Info size={16} />
             </button>

            <div className="p-5 flex-1">
               <div className="flex justify-between items-start mb-3">
                 {getStatusBadge(req.status)}
                 <span className="text-xs text-slate-400">{new Date(req.date).toLocaleDateString('pt-BR')}</span>
               </div>
               <h3 className="font-bold text-slate-800 text-lg mb-1">{req.item}</h3>
               <p className="text-emerald-700 font-bold text-xl mb-4">R$ {req.amount.toLocaleString()}</p>
               
               <div className="space-y-2 text-sm text-slate-600">
                 <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-500">
                        {req.requesterName.charAt(0)}
                    </div>
                    <span>{req.requesterName}</span>
                 </div>
                 <div className="flex items-center gap-2 text-xs">
                   <span className="bg-slate-100 px-2 py-1 rounded">{req.department}</span>
                   <span className="bg-slate-100 px-2 py-1 rounded">{req.costCenter}</span>
                 </div>
                 <p className="italic text-slate-500 text-xs mt-2 bg-slate-50 p-2 rounded border border-slate-100">
                   "{req.justification}"
                 </p>
               </div>
            </div>

            {user.role === 'ADMIN' && req.status === 'PENDING' && (
              <div className="bg-slate-50 p-3 flex gap-2 border-t border-slate-100">
                <button 
                  onClick={() => handleApproval(req.id, false)}
                  className="flex-1 flex items-center justify-center gap-1 bg-white hover:bg-red-50 text-red-600 border border-slate-200 hover:border-red-200 py-2 rounded-lg transition-all font-medium text-sm"
                >
                  <X size={16} /> Reprovar
                </button>
                <button 
                  onClick={() => handleApproval(req.id, true)}
                  className="flex-1 flex items-center justify-center gap-1 bg-emerald-600 hover:bg-emerald-700 text-white py-2 rounded-lg transition-all font-medium text-sm shadow-sm"
                >
                  <Check size={16} /> Aprovar
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Item History Modal */}
      <ItemHistoryModal 
        isOpen={!!historyItemId}
        onClose={() => setHistoryItemId(null)}
        itemTitle={requests.find(r => r.id === historyItemId)?.item || 'Solicitação'}
        logs={historyLogs.filter(log => log.itemId === historyItemId)}
      />

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg p-6 animate-scale-in">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-slate-800">Nova Solicitação</h3>
              <button onClick={() => setIsModalOpen(false)}><X className="text-slate-400" /></button>
            </div>
            
            <div className="space-y-4">
               <div>
                 <label className="text-xs font-medium text-slate-500">Item / Serviço</label>
                 <input 
                   className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500/50 bg-white"
                   value={newRequest.item}
                   onChange={e => setNewRequest({...newRequest, item: e.target.value})}
                   autoFocus
                 />
               </div>
               
               <div>
                 <label className="text-xs font-medium text-slate-500">Valor Estimado (R$)</label>
                 <input 
                   type="number"
                   className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500/50 bg-white"
                   value={newRequest.amount}
                   onChange={e => setNewRequest({...newRequest, amount: Number(e.target.value)})}
                 />
               </div>

               <div className="grid grid-cols-2 gap-4">
                 <div>
                   <label className="text-xs font-medium text-slate-500">Departamento</label>
                   <select 
                     className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white"
                     value={newRequest.department}
                     onChange={e => setNewRequest({...newRequest, department: e.target.value})}
                   >
                      <option value="">Selecione...</option>
                      {departments.map(d => <option key={d.id} value={d.name}>{d.name}</option>)}
                   </select>
                 </div>
                 <div>
                   <label className="text-xs font-medium text-slate-500">Centro de Custo</label>
                   <select 
                     className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none bg-white"
                     value={newRequest.costCenter}
                     onChange={e => setNewRequest({...newRequest, costCenter: e.target.value})}
                   >
                      <option value="">Selecione...</option>
                      {costCenters.map(cc => <option key={cc.id} value={cc.code}>{cc.code} - {cc.name}</option>)}
                   </select>
                 </div>
               </div>

               <div>
                 <label className="text-xs font-medium text-slate-500">Justificativa</label>
                 <textarea 
                   className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none h-20 resize-none bg-white"
                   value={newRequest.justification}
                   onChange={e => setNewRequest({...newRequest, justification: e.target.value})}
                 ></textarea>
               </div>
            </div>

            <button onClick={handleSubmit} className="w-full bg-indigo-600 text-white py-3 rounded-lg mt-6 font-medium hover:bg-indigo-700 transition-colors">
              Enviar Solicitação
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
