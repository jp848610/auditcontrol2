
import { openDB as idbOpenDB, IDBPDatabase } from 'idb';
import { AppData, CryptoKeyJson, EncryptedData } from '../types';
import { MOCK_AUDITS, MOCK_USERS, MOCK_DEPARTMENTS, MOCK_COST_CENTERS, MOCK_REQUESTS, MOCK_COMPLIANCE_RULES, MOCK_MATRIX_ITEMS, MOCK_PARTNER_SEGMENTS, MOCK_PARTNERS, MOCK_PARTNER_CONTRACTS, MOCK_HISTORY, MOCK_COMPANIES } from '../constants';

const DB_NAME = 'audit_control_db';
const STORE_NAME = 'app_data_store';
const DB_VERSION = 8; 
const KEY_STORAGE_NAME = 'audit_control_crypto_key';

let db: IDBPDatabase<unknown>;
let cryptoKey: CryptoKey | null = null;

// --- Utility Functions ---
const stringToArrayBuffer = (str: string): ArrayBuffer => {
    const buf = new ArrayBuffer(str.length);
    const bufView = new Uint8Array(buf);
    for (let i = 0; i < str.length; i++) {
        bufView[i] = str.charCodeAt(i);
    }
    return buf;
};

const arrayBufferToString = (buf: ArrayBuffer): string => {
    return String.fromCharCode.apply(null, Array.from(new Uint8Array(buf)));
};

const arrayBufferToBase64 = (buffer: ArrayBuffer): string => {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
};

const base64ToArrayBuffer = (base64: string): ArrayBuffer => {
    const binary_string = atob(base64);
    const len = binary_string.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binary_string.charCodeAt(i);
    }
    return bytes.buffer;
};

// --- Encryption/Decryption ---
const getCryptoKey = async (): Promise<CryptoKey> => {
    if (cryptoKey) return cryptoKey;

    const storedKey = localStorage.getItem(KEY_STORAGE_NAME);
    if (storedKey) {
        try {
            const exportedKey = JSON.parse(storedKey) as CryptoKeyJson;
            cryptoKey = await crypto.subtle.importKey(
                "jwk",
                exportedKey,
                { name: "AES-GCM", length: 256 },
                true,
                ["encrypt", "decrypt"]
            );
        } catch (error) {
            console.error("Failed to import crypto key, generating new one:", error);
            localStorage.removeItem(KEY_STORAGE_NAME); // Clear corrupted key
            cryptoKey = null; // Ensure new key is generated
            return getCryptoKey(); // Retry
        }
    } else {
        cryptoKey = await crypto.subtle.generateKey(
            { name: "AES-GCM", length: 256 },
            true,
            ["encrypt", "decrypt"]
        );
        const exportedKey = await crypto.subtle.exportKey("jwk", cryptoKey);
        localStorage.setItem(KEY_STORAGE_NAME, JSON.stringify(exportedKey));
    }
    return cryptoKey;
};

export const encryptData = async (data: string): Promise<EncryptedData> => {
    const key = await getCryptoKey();
    const iv = crypto.getRandomValues(new Uint8Array(12)); // GCM recommended IV size
    const encoded = stringToArrayBuffer(data);

    const encrypted = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: iv },
        key,
        encoded
    );

    return {
        iv: arrayBufferToBase64(iv),
        encryptedString: arrayBufferToBase64(encrypted),
    };
};

export const decryptData = async (encryptedData: EncryptedData): Promise<string> => {
    const key = await getCryptoKey();
    const iv = base64ToArrayBuffer(encryptedData.iv);
    const encryptedBuffer = base64ToArrayBuffer(encryptedData.encryptedString);

    const decrypted = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: iv },
        key,
        encryptedBuffer
    );

    return arrayBufferToString(decrypted);
};

// --- IndexedDB Operations ---
export const initDB = async (): Promise<void> => {
    if (db) return; // DB already open

    db = await idbOpenDB(DB_NAME, DB_VERSION, {
        upgrade(db, oldVersion, newVersion, transaction) {
            console.log(`IndexedDB: Upgrading from version ${oldVersion} to ${newVersion}`);
            if (db.objectStoreNames.contains(STORE_NAME)) {
                console.log(`IndexedDB: Deleting existing object store '${STORE_NAME}'.`);
                db.deleteObjectStore(STORE_NAME);
            }
            db.createObjectStore(STORE_NAME);
            console.log(`IndexedDB: Object store '${STORE_NAME}' created.`);
            
            if (oldVersion < newVersion) {
                console.log("IndexedDB: Clearing crypto key from localStorage due to DB upgrade.");
                localStorage.removeItem(KEY_STORAGE_NAME);
                cryptoKey = null; 
            }
        },
    });
    console.log(`IndexedDB: Database '${DB_NAME}' (v${DB_VERSION}) opened successfully.`);
};

export const saveAllData = async (data: AppData): Promise<void> => {
    await initDB(); // Ensure DB is open
    console.log("IndexedDB: Attempting to save all data.");
    const encrypted = await encryptData(JSON.stringify(data));
    await db.put(STORE_NAME, encrypted, 'appData');
    console.log("IndexedDB: Data saved successfully.");
};

export const loadAllData = async (): Promise<AppData | null> => {
    await initDB(); // Ensure DB is open
    console.log("IndexedDB: Attempting to load all data.");
    const encrypted = await db.get(STORE_NAME, 'appData') as EncryptedData;

    if (!encrypted) {
        console.log("IndexedDB: No encrypted data found, returning null.");
        return null;
    }

    try {
        const decryptedString = await decryptData(encrypted);
        const parsedData = JSON.parse(decryptedString) as AppData;
        
        // Ensure data migration for 'status' field in users
        const migratedUsers = (parsedData.users || MOCK_USERS).map(u => ({
            ...u,
            status: u.status || 'APPROVED', // Default old users to APPROVED
            mustChangePassword: u.mustChangePassword || false // Default to false
        }));

        const loadedData: AppData = {
            companies: parsedData.companies !== undefined ? parsedData.companies : MOCK_COMPANIES,
            users: migratedUsers,
            audits: parsedData.audits !== undefined ? parsedData.audits : MOCK_AUDITS,
            departments: parsedData.departments !== undefined ? parsedData.departments : MOCK_DEPARTMENTS,
            costCenters: parsedData.costCenters !== undefined ? parsedData.costCenters : MOCK_COST_CENTERS,
            requests: parsedData.requests !== undefined ? parsedData.requests : MOCK_REQUESTS,
            matrixItems: parsedData.matrixItems !== undefined ? parsedData.matrixItems : MOCK_MATRIX_ITEMS,
            complianceRules: parsedData.complianceRules !== undefined ? parsedData.complianceRules : MOCK_COMPLIANCE_RULES,
            partnerSegments: parsedData.partnerSegments !== undefined ? parsedData.partnerSegments : MOCK_PARTNER_SEGMENTS,
            partners: parsedData.partners !== undefined ? parsedData.partners : MOCK_PARTNERS,
            partnerContracts: parsedData.partnerContracts !== undefined ? parsedData.partnerContracts : MOCK_PARTNER_CONTRACTS,
            historyLogs: parsedData.historyLogs !== undefined ? parsedData.historyLogs : MOCK_HISTORY,
        };
        console.log("IndexedDB: Data loaded and parsed successfully:", loadedData);
        return loadedData;
    } catch (error) {
        console.error("IndexedDB: Failed to decrypt or parse data from IndexedDB, returning null and cleaning up:", error);
        await db.clear(STORE_NAME);
        localStorage.removeItem(KEY_STORAGE_NAME); 
        cryptoKey = null; 
        return null;
    }
};

export const clearAllData = async (): Promise<void> => {
    await initDB();
    console.log("IndexedDB: Clearing all data from store and crypto key from localStorage.");
    await db.clear(STORE_NAME);
    localStorage.removeItem(KEY_STORAGE_NAME);
    cryptoKey = null; 
    console.log("IndexedDB: All data cleared.");
};
