
import { GoogleGenAI, Type } from "@google/genai";
import { Audit, InsightResponse, AuditStatus, Department, CostCenter } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// The `analyzeAudits` function was removed as the "Conferência & Conflitos" tab is deprecated.

export const suggestBudgetAndCategory = async (
  description: string, 
  departments: Department[], 
  costCenters: CostCenter[]
): Promise<{ plannedBudget: number, department: string, costCenter: string } | null> => {
  try {
    const deptNames = departments.map(d => d.name);
    const ccCodes = costCenters.map(cc => `${cc.code} - ${cc.name}`);

    const prompt = `
      Baseado na descrição do item/auditoria "${description}", sugira um orçamento planejado (apenas o número),
      um departamento da lista [${deptNames.join(', ')}] e um centro de custo da lista [${ccCodes.join(', ')}].
      Sua resposta deve ser um JSON exato no formato:
      {"plannedBudget": number, "department": string, "costCenter": string}
      Escolha os valores que melhor se encaixam. Se um centro de custo não se encaixar em um departamento, priorize o centro de custo mais relevante.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            plannedBudget: { type: Type.NUMBER, description: "Orçamento sugerido" },
            department: { type: Type.STRING, description: "Departamento sugerido" },
            costCenter: { type: Type.STRING, description: "Centro de Custo sugerido (código completo)" }
          },
          required: ["plannedBudget", "department", "costCenter"]
        }
      }
    });

    if (response.text) {
      const result = JSON.parse(response.text);
      // Ensure the suggested department/cost center actually exist
      const suggestedDept = departments.find(d => d.name === result.department)?.name || departments[0]?.name || '';
      const suggestedCc = costCenters.find(cc => cc.code === result.costCenter.split(' ')[0])?.code || costCenters[0]?.code || '';

      return {
        plannedBudget: result.plannedBudget,
        department: suggestedDept,
        costCenter: suggestedCc,
      };
    }
    return null;

  } catch (error) {
    console.error("Error suggesting budget and category:", error);
    return null;
  }
};


export const suggestMatrixItemValues = async (
  description: string, 
  costCenters: CostCenter[]
): Promise<{ quantity: number, unitValue: number, category: string } | null> => {
  try {
    const ccCodes = costCenters.map(cc => `${cc.code} - ${cc.name}`);

    const prompt = `
      Baseado na descrição do item matricial "${description}", sugira uma quantidade estimada (apenas o número),
      um valor unitário (apenas o número) e um centro de custo da lista [${ccCodes.join(', ')}].
      Sua resposta deve ser um JSON exato no formato:
      {"quantity": number, "unitValue": number, "category": string}
      Priorize sugestões realistas e coerentes.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            quantity: { type: Type.NUMBER, description: "Quantidade sugerida" },
            unitValue: { type: Type.NUMBER, description: "Valor unitário sugerido" },
            category: { type: Type.STRING, description: "Centro de Custo sugerido (código completo)" }
          },
          required: ["quantity", "unitValue", "category"]
        }
      }
    });

    if (response.text) {
      const result = JSON.parse(response.text);
      const suggestedCc = costCenters.find(cc => cc.code === result.category.split(' ')[0])?.code || costCenters[0]?.code || '';

      return {
        quantity: result.quantity,
        unitValue: result.unitValue,
        category: suggestedCc,
      };
    }
    return null;

  } catch (error) {
    console.error("Error suggesting matrix item values:", error);
    return null;
  }
};

export const analyzeAudits = async (audits: Audit[]): Promise<InsightResponse | null> => {
  try {
    const auditDataSummary = audits.map(audit => ({
      id: audit.id,
      title: audit.title,
      department: audit.department,
      plannedBudget: audit.plannedBudget,
      executedBudget: audit.executedBudget,
      savingAmount: audit.savingAmount, 
      negotiationStatus: audit.negotiationStatus,
      initialQuote: audit.initialQuote,
      finalPrice: audit.finalPrice,
      negotiationSaving: (audit.initialQuote || 0) - (audit.finalPrice || 0), 
      complianceRating: audit.complianceRating,
      status: audit.status,
      date: audit.date,
    }));

    const prompt = `
      Analise os seguintes dados de auditorias e negociações.
      Forneça um resumo geral, identifique a principal economia (topSaving) com detalhes e ofereça uma recomendação acionável.
      Os dados incluem informações de planejamento, execução, negociações (valor original, valor negociado e status) e ratings de compliance (1-5 estrelas).

      Dados das auditorias:
      ${JSON.stringify(auditDataSummary, null, 2)}

      Formato de saída JSON exato:
      {
        "summary": "string",
        "topSaving": "string (ex: 'A auditoria X gerou uma economia de R$ Y,Z (Z% do valor original) devido à negociação ABC.')",
        "recommendation": "string"
      }
      Certifique-se que o topSaving seja a negociação com maior valor economizado (initialQuote - finalPrice).
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING, description: "Resumo geral das auditorias" },
            topSaving: { type: Type.STRING, description: "A principal economia identificada" },
            recommendation: { type: Type.STRING, description: "Uma recomendação acionável" }
          },
          required: ["summary", "topSaving", "recommendation"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as InsightResponse;
    }
    return null;
  } catch (error) {
    console.error("Error analyzing audits with AI:", error);
    return null;
  }
};

export const getChatResponse = async (message: string, history: { role: 'user' | 'model', text: string }[]): Promise<string> => {
  try {
    const formattedHistory = history.map(msg => ({
      role: msg.role,
      parts: [{ text: msg.text }],
    }));

    const systemInstruction = `
      Você é a Cassandra 🤖, o Assistente Virtual Inteligente do sistema 'AuditControl'.
      Sua função é ajudar os usuários com dúvidas sobre o uso do sistema, conceitos de auditoria, orçamento e negociação.
      
      Funcionalidades do Sistema que você conhece:
      1. Dashboard: Visão geral, KPIs, Gráficos de evolução mensal e rateio.
      2. Planejamento: Cadastro de auditorias planejadas, definição de budget anual/mensal.
      3. Negociações: Registro de savings, confronto de Proposta Inicial vs Final, anexos de contratos.
      4. Orçamento Matricial: Gestão detalhada de pacotes de despesas (Pacote x Quantidade x Valor Unitário) com visão anual e mensal.
      5. Parceiros: Gestão de fornecedores, segmentos e contratos.
      6. Solicitações: Workflow de aprovação de compras.
      7. Portal da Transparência: Visão pública de gastos e governança.
      
      Seja educada, profissional e concisa. Responda em Português do Brasil.
      Se o usuário perguntar algo fora do contexto de auditoria/sistema, gentilmente traga o assunto de volta ou responda de forma breve.
    `;

    // Better implementation using chat mode for context:
    const chat = ai.chats.create({
      model: "gemini-2.5-flash",
      config: { systemInstruction },
      history: formattedHistory
    });

    const result = await chat.sendMessage({ message });
    return result.text || "Desculpe, não consegui processar sua solicitação.";

  } catch (error) {
    console.error("Error in AI Chat:", error);
    return "Desculpe, estou enfrentando dificuldades técnicas no momento.";
  }
};
